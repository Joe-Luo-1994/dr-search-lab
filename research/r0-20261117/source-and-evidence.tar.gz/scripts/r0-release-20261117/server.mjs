import http from 'node:http';
import next from 'next';
import * as service from './runtime/service.mjs';
const app=next({dev:false,dir:process.env.NEXT_PROJECT??'/app/project'});
await app.prepare();
const handle=app.getRequestHandler();let bootError=null,draining=false,inflight=0;
const sockets=new Set();
const server=http.createServer((req,res)=>{
 const op=new URL(req.url,'http://localhost').pathname;
 if(op.startsWith('/health/')){
  const h=service.runtimeHealth();const ok=op==='/health/live'||(!draining&&!bootError&&h.ready);
  res.writeHead(ok?200:503,{'content-type':'application/json','cache-control':'no-store'});
  res.end(JSON.stringify({ready:!draining&&!bootError&&h.ready,draining,error:bootError,releaseId:process.env.RELEASE_ID}));return;
 }
 if(draining){res.writeHead(503,{'connection':'close'});res.end('DRAINING');return;}
 inflight++;let ended=false;const end=()=>{if(!ended){ended=true;inflight--;}};res.once('finish',end);res.once('close',end);
 Promise.resolve(handle(req,res)).catch(e=>{if(!res.headersSent){res.statusCode=503;res.end('REQUEST_FAILED');}else res.destroy();console.error(JSON.stringify({event:'request-failed',error:e.message}));});
});
server.on('connection',socket=>{sockets.add(socket);socket.on('close',()=>sockets.delete(socket));});
server.listen(Number(process.env.PORT??3000),process.env.LISTEN_HOST??'0.0.0.0',()=>{
 console.log(JSON.stringify({event:'listening',port:server.address().port,releaseId:process.env.RELEASE_ID}));
 service.initializeRuntime().catch(e=>{bootError=e.message;console.error(JSON.stringify({event:'runtime-start-failed',error:bootError}));});
});
async function shutdown(signal){
 if(draining)return;draining=true;
 console.log(JSON.stringify({event:'drain-start',signal,inflight}));
 const hard=setTimeout(()=>{console.error(JSON.stringify({event:'drain-hard-exit',inflight}));process.exit(1);},15000);
 server.close();server.closeIdleConnections();
 const until=Date.now()+10000;
 while(inflight&&Date.now()<until)await new Promise(resolve=>setTimeout(resolve,50));
 const forced=inflight>0;
 for(const socket of sockets)socket.destroy();
 await service.closeRuntime();clearTimeout(hard);
 console.log(JSON.stringify({event:'drain-end',forced,inflight}));process.exit(forced?1:0);
}
process.on('SIGTERM',()=>void shutdown('SIGTERM'));process.on('SIGINT',()=>void shutdown('SIGINT'));
