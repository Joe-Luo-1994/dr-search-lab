"""Copy selected non-secret preparation evidence to the Windows research directory."""
import pathlib,shutil,json
work=pathlib.Path('/PUBLIC/LINUX_HOME/dr-r0-work')
out=pathlib.Path('/PUBLIC/WINDOWS_HOME/Documents/ChatGPT/Search Playground/evidence/r0-release-20261117/preserved-preparation');out.mkdir(exist_ok=True)
for ident in ('20261117-094213','20261117-095705'):
 src=work/'runs'/ident/'resolved-pod-logs';shutil.copytree(src,out/(ident+'-pod-logs'),dirs_exist_ok=True)
for name in ('profile-reset','profile-reset-20261117-095705'):
 src=work/name
 if src.exists():shutil.copytree(src,out/name,dirs_exist_ok=True)
for v in ('v1','v2'):
 target=out/v;target.mkdir(exist_ok=True)
 for name in ('release.json','pin.json','oracle.json'):shutil.copy2(work/'releases'/v/name,target/name)
shutil.copy2(work/'v2-build-20261117-095006/v2-export/export-receipt.json',out/'v2-export-receipt.json')
print(json.dumps({'output':str(out),'files':sum(p.is_file() for p in out.rglob('*')),'scope':'local evidence only; paths unsanitized, no public upload'}))
