import {readFile,writeFile} from 'node:fs/promises';
import {createReadStream} from 'node:fs';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {remote} from './runtime/storage.mjs';
const root=process.argv[2],receiptPath=process.argv[3];
const pin=JSON.parse(await readFile(path.join(root,'pin.json'),'utf8'));
const uploads=JSON.parse(await readFile(path.join(root,'uploads.json'),'utf8'));
const rows=[],began=performance.now();
async function verify(d){
 const r=await remote('GET',d.key,{signal:AbortSignal.timeout(90000)});if(!r.ok)throw Error('VERIFY_HTTP_'+r.status);
 const h=createHash('sha256');let bytes=0;
 for await(const b of r.body){bytes+=b.length;h.update(b);}
 if(bytes!==d.bytes||h.digest('hex')!==d.sha256)throw Error('PUBLISH_VERIFY:'+d.key);
}
async function put(d){
 const t=performance.now();const head=await remote('HEAD',d.key,{signal:AbortSignal.timeout(5000)});
 if(head.status===404){const r=await remote('PUT',d.key,{body:createReadStream(d.local),bodyHash:d.sha256,bodyBytes:d.bytes,signal:AbortSignal.timeout(90000)});if(!r.ok)throw Error('PUT_HTTP_'+r.status);await r.arrayBuffer();}
 else if(!head.ok)throw Error('HEAD_HTTP_'+head.status);
 await verify(d);rows.push({key:d.key,bytes:d.bytes,elapsedMs:performance.now()-t,reused:head.ok});
}
try{
 const bucket=await remote('PUT','',{signal:AbortSignal.timeout(5000)});if(!bucket.ok&&bucket.status!==409)throw Error('BUCKET_HTTP_'+bucket.status);await bucket.arrayBuffer();
 for(const d of uploads)await put(d);
 const bytes=await readFile(pin.manifestLocal);const sha=createHash('sha256').update(bytes).digest('hex');if(sha!==pin.manifestSha256)throw Error('MANIFEST_CHANGED');
 await put({key:pin.manifestKey,local:pin.manifestLocal,bytes:bytes.length,sha256:sha});
 await writeFile(receiptPath,JSON.stringify({passed:true,releaseId:pin.releaseId,elapsedMs:performance.now()-began,rows},null,2));
 console.log(JSON.stringify({published:pin.releaseId,objects:rows.length,elapsedMs:performance.now()-began}));
}catch(e){await writeFile(receiptPath,JSON.stringify({passed:false,error:e.message,rows},null,2));throw e;}
