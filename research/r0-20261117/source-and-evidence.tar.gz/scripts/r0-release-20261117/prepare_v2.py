"""Windows guarded, offline V2 builder. Dedicated container, frozen inputs read-only."""
import json,pathlib,subprocess,time
from environment_preflight import linux,available
HERE=pathlib.Path(__file__).resolve().parent
OUT=HERE.parents[1]/'evidence/r0-release-20261117'/time.strftime('v2-build-%Y%m%d-%H%M%S')
OUT.mkdir(parents=True)
name='r0-v2-builder-'+OUT.name.split('build-')[1];native='/PUBLIC/LINUX_HOME/dr-r0-work/'+OUT.name
result={'passed':False,'container':name,'scope':'offline central build; not live serving coexistence','limits':{'cpu':4,'memoryGiB':4,'swap':0}};proc=None
try:
 assert available()>=14*1024**3,'HOST_START_GUARD'
 assert linux('docker inspect dr-search-r0 --format {{.State.Running}}')=='false','CLUSTER_MUST_BE_STOPPED'
 assert linux('test ! -e '+native+' && echo absent')=='absent','OUTPUT_EXISTS'
 linux('mkdir '+native)
 command="node /code/scripts/n1-native-20261117/tantivy/export-source.mjs /work/v2-export 1000000 v2 /source/.lab/c-million-20261116/fixture-1000000/v2/manifest.json && /app/bin/n1-tantivy-reader build /work/v2-index /work/v2-export/source.jsonl"
 args=['wsl','-d','Ubuntu','--','docker','run','--name',name,'--cpus=4','--memory=4g','--memory-swap=4g','--network=none','-v','/PUBLIC/WINDOWS_HOME/Documents/ChatGPT/Search Playground:/code:ro','-v','/PUBLIC/LINUX_HOME/dr-search-lab-e1-20261115/repo:/source:ro','-v',native+':/work','r0-reader:build','sh','-c',command]
 result['nativeOutput']=native
 started=time.monotonic()
 with (OUT/'build.log').open('w',encoding='utf8') as log,(OUT/'host.ndjson').open('w') as samples:
  proc=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT)
  while proc.poll() is None:
   free=available();elapsed=time.monotonic()-started;samples.write(json.dumps({'elapsed':elapsed,'available':free})+'\n');samples.flush()
   assert free>=6*1024**3,'HOST_AVAILABLE'
   assert elapsed<900,'BUILD_DEADLINE'
   time.sleep(2)
  result.update(exitCode=proc.returncode,seconds=time.monotonic()-started)
  assert proc.returncode==0,'BUILD_FAILED'
 result['passed']=True
except Exception as e:result['error']=str(e)
finally:
 try:
  if proc:
   info=json.loads(linux('docker inspect '+name))[0]
   if info['State']['Running']:linux('docker stop --time=5 '+name,15)
   info=json.loads(linux('docker inspect '+name))[0]
   result['state']=info['State'];result['hostConfig']=info['HostConfig'];result['imageConfigID']=info['Image']
   result['stopped']=not info['State']['Running'];assert result['stopped'],'BUILDER_STILL_RUNNING'
   h=info['HostConfig'];assert h['NanoCpus']==4000000000 and h['Memory']==4*1024**3 and h['MemorySwap']==4*1024**3,'BUILDER_LIMIT_MISMATCH'
   if proc.poll() is None:proc.wait(timeout=20)
 except Exception as e:result.update(passed=False,cleanupError=str(e))
 (OUT/'result.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps({'out':str(OUT),**result}))
raise SystemExit(0 if result['passed'] else 1)
