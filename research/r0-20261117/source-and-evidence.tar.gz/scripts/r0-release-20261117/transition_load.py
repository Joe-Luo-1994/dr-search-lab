"""Continuous fixed-rate observation during a version transition; immutable per-version oracles."""
import concurrent.futures,hashlib,json,threading,time
from pipeline import http,save
class Window:
 def __init__(self,base,oracles,version,allowed,out,max_seconds=900):
  self.base=base;self.oracles=oracles;self.version=version;self.allowed=set(allowed);self.out=out;self.limit=max_seconds;self.rows=[];self.slots=[];self.stop=threading.Event();self.failure=threading.Event();self.lock=threading.Lock();self.error=None
  save(out.with_suffix('.plan.json'),{'rateEachLane':1,'lanes':['search','page','media'],'maxSeconds':max_seconds,'deadlineSeconds':4,'maxPending':12,'oracleVersions':list(oracles)})
 def set_version(self,v,allowed):
  with self.lock:
   with self.out.with_suffix('.phases.ndjson').open('a') as f:f.write(json.dumps({'at':time.time(),'version':v,'allowed':sorted(allowed)})+'\n');f.flush()
   self.version=v;self.allowed=set(allowed)
 def append(self,row):
  with self.lock:
   try:
    with self.out.with_suffix('.ndjson').open('a') as f:f.write(json.dumps(row)+'\n');f.flush()
   except Exception as e:self.error=str(e);self.failure.set();raise
   self.rows.append(row)
   if not row.get('ok'):self.failure.set()
 def task(self,i,lane,scheduled,version,allowed):
  row={'i':i,'lane':lane,'requestedVersion':version,'scheduled':scheduled-self.start};o=self.oracles[version]
  try:
   sent=time.monotonic();row['sent']=sent-self.start
   if sent-scheduled>=4:raise RuntimeError('MISSED_DEADLINE')
   if lane=='search':route='/api/capi/search?q='+o['query']
   elif lane=='page':route='/api/capi/page?pageId='+o['pageId']+'&version='+version
   else:route='/api/capi/media?pageId='+o['media']['pageId']+'&mediaId='+o['media']['mediaId']+'&version='+version
   s,b,h=http(self.base,route,timeout=max(.1,4-(sent-scheduled)));row.update(status=s,pod=h.get('x-r0-pod'),actualVersion=h.get('x-r0-release'),latencyMs=(time.monotonic()-scheduled)*1000)
   if s==409 and lane!='search' and len(allowed)>1:
    assert json.loads(b)['error']['code']=='VERSION_MISMATCH';assert row['actualVersion'] in allowed and row['actualVersion']!=version;row.update(ok=True,outcome='expected-version-mismatch')
   elif s==200:
    if lane=='search':
     r=json.loads(b);v=r['snapshotId'];assert v in allowed;expected=self.oracles[v];assert r['total']==1 and [x['pageId'] for x in r['hits']]==[expected['pageId']] and r['hits'][0]['title']==expected['title'];assert row['actualVersion']==v
    else:
     assert row['actualVersion']==version;d=o['body'] if lane=='page' else o['media'];assert len(b)==d['bytes'] and hashlib.sha256(b).hexdigest()==d['sha256']
    row.update(ok=True,outcome='ok')
   else:raise RuntimeError('HTTP_'+str(s))
   if row['latencyMs']>4000:raise RuntimeError('DEADLINE')
  except Exception as e:row.update(ok=False,error=str(e))
  self.append(row)
 def run(self):
  self.start=time.monotonic()
  try:
   with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
    futures=[]
    for i in range(self.limit):
     scheduled=self.start+i
     if self.stop.wait(max(0,scheduled-time.monotonic())):break
     with self.lock:version=self.version;allowed=set(self.allowed)
     for lane in ('search','page','media'):
      pending=[]
      for f in futures:
       if f.done():f.result()
       else:pending.append(f)
      futures=pending
      slot={'i':i,'lane':lane,'scheduled':scheduled-self.start}
      with self.out.with_suffix('.slots.ndjson').open('a') as f:f.write(json.dumps(slot)+'\n');f.flush()
      self.slots.append((i,lane))
      if len(futures)>=12:self.append({'i':i,'lane':lane,'ok':False,'error':'MISSED_ADMISSION','scheduled':scheduled-self.start})
      else:futures.append(pool.submit(self.task,i,lane,scheduled,version,allowed))
    else:self.error='WINDOW_DEADLINE'
    for f in futures:f.result()
  except Exception as e:self.error=str(e);self.failure.set()
 def begin(self):self.set_version(self.version,self.allowed);self.thread=threading.Thread(target=self.run);self.thread.start();return self
 def finish(self):
  self.stop.set();self.thread.join(10)
  if self.thread.is_alive():raise RuntimeError('LOADER_LEAK')
  completed=[(x['i'],x['lane']) for x in self.rows]
  complete=len(completed)==len(set(completed)) and sorted(completed)==sorted(self.slots)
  summary={'planned':len(self.slots),'completed':len(self.rows),'complete':complete,'success':sum(x.get('outcome')=='ok' for x in self.rows),'expectedMismatch':sum(x.get('outcome')=='expected-version-mismatch' for x in self.rows),'failed':sum(not x.get('ok') for x in self.rows),'error':self.error}
  save(self.out.with_suffix('.summary.json'),summary)
  if self.error or summary['failed'] or not complete or not self.rows:raise RuntimeError('TRANSITION_LOAD_FAILED')
  return summary
