import json,pathlib,re,subprocess,sys
unit=sys.argv[1]
if not re.fullmatch(r'dr-r0-(?:rebuild-)?\d{8}-\d{6}',unit):raise SystemExit('UNIT_SCOPE')
r=subprocess.run(['systemctl','--user','show',unit,'--property=ActiveState,SubState,MainPID,ControlGroup,LoadState'],capture_output=True,text=True,timeout=5)
if r.returncode:raise RuntimeError(r.stderr)
state=dict(line.split('=',1) for line in r.stdout.splitlines() if '=' in line)
if state.get('ActiveState') not in ('inactive','failed') or state.get('MainPID')!='0':raise RuntimeError('UNIT_STILL_ACTIVE')
cg=state.get('ControlGroup','');pids=[];status='no-cgroup-reference'
if cg:
 root=(pathlib.Path('/sys/fs/cgroup')/cg.lstrip('/')).resolve()
 if not root.is_relative_to('/sys/fs/cgroup'):raise RuntimeError('CGROUP_SCOPE')
 status='removed' if not root.exists() else 'present'
 if root.exists():
  for file in root.rglob('cgroup.procs'):
   try:pids.extend(int(x) for x in file.read_text().split())
   except FileNotFoundError:pass
if pids:raise RuntimeError('UNIT_CHILDREN_REMAIN:'+str(pids))
print(json.dumps({'state':state,'cgroupStatus':status,'remainingPids':pids}))
