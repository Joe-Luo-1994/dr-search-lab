"""Render only; never applies manifests or creates credentials."""
import argparse,json,re
def render(app_image,minio_image,release,manifest_key,manifest_sha,local=False):
    for image in (app_image,minio_image):
        if not (re.fullmatch(r'[a-zA-Z0-9./:_-]+@sha256:[a-f0-9]{64}',image) or (local and re.fullmatch(r'r0-reader:sha256-[a-f0-9]{64}',image))):raise ValueError('IMAGE_DIGEST_REQUIRED')
    if release not in ('v1','v2','v3') or not re.fullmatch(r'[a-f0-9]{64}',manifest_sha):raise ValueError('RELEASE_PIN')
    if not re.fullmatch(r'[a-zA-Z0-9_./-]+',manifest_key) or '..' in manifest_key:raise ValueError('MANIFEST_KEY')
    ns='dr-search-r0'
    def meta(name):return {'name':name,'namespace':ns,'labels':{'study':'r0'}}
    def svc(name,port):return {'apiVersion':'v1','kind':'Service','metadata':meta(name),'spec':{'selector':{'app':name},'ports':[{'port':port,'targetPort':port}]}}
    env=[{'name':k,'value':v} for k,v in {'RELEASE_ID':release,'RELEASE_MANIFEST_KEY':manifest_key,'RELEASE_MANIFEST_SHA256':manifest_sha,'INSTALL_ROOT':'/release','NEXT_PROJECT':'/app/project','CAP_SERVICE_URL':'file:///app/runtime/service.mjs','NEXT_TELEMETRY_DISABLED':'1'}.items()]
    env.append({'name':'HOSTNAME','valueFrom':{'fieldRef':{'fieldPath':'metadata.name'}}})
    mounts=[{'name':'release','mountPath':'/release'},{'name':'bootstrap','mountPath':'/bootstrap','readOnly':True}]
    resources={'requests':{'cpu':'1','memory':'2Gi','ephemeral-storage':'8Gi'},'limits':{'cpu':'4','memory':'8Gi','ephemeral-storage':'10Gi'}}
    def probe(path,period,threshold):return {'httpGet':{'path':path,'port':3000},'periodSeconds':period,'timeoutSeconds':2,'failureThreshold':threshold}
    app={'apiVersion':'apps/v1','kind':'Deployment','metadata':meta('reader'),'spec':{'replicas':1,'progressDeadlineSeconds':120,'minReadySeconds':5,'strategy':{'type':'RollingUpdate','rollingUpdate':{'maxSurge':1,'maxUnavailable':0}},'selector':{'matchLabels':{'app':'reader'}},'template':{'metadata':{'labels':{'app':'reader','study':'r0'},'annotations':{'r0.release':release,'r0.manifest-sha256':manifest_sha}},'spec':{'automountServiceAccountToken':False,'terminationGracePeriodSeconds':20,'initContainers':[{'name':'install','image':app_image,'imagePullPolicy':'Never' if local else 'IfNotPresent','command':['node','/app/installer.mjs'],'env':env+[{'name':'CAP_CONFIG','value':'/bootstrap/config.json'}],'resources':resources,'volumeMounts':mounts}], 'containers':[{'name':'reader','image':app_image,'imagePullPolicy':'Never' if local else 'IfNotPresent','command':['node','/app/server.mjs'],'env':env+[{'name':'CAP_CONFIG','value':'/release/config.json'}],'resources':resources,'volumeMounts':mounts,'ports':[{'containerPort':3000}],'startupProbe':probe('/health/startup',2,20),'readinessProbe':probe('/health/ready',2,1),'livenessProbe':probe('/health/live',5,3)}],'volumes':[{'name':'release','emptyDir':{'sizeLimit':'8Gi'}},{'name':'bootstrap','secret':{'secretName':'r0-bootstrap','defaultMode':384}}]}}}}
    minio={'apiVersion':'apps/v1','kind':'Deployment','metadata':meta('minio'),'spec':{'replicas':1,'strategy':{'type':'Recreate'},'selector':{'matchLabels':{'app':'minio'}},'template':{'metadata':{'labels':{'app':'minio','study':'r0'}},'spec':{'automountServiceAccountToken':False,'containers':[{'name':'minio','image':minio_image,'command':['/app/bin/minio'],'args':['server','/data','--address',':9000'],'envFrom':[{'secretRef':{'name':'r0-minio'}}],'ports':[{'containerPort':9000}],'resources':{'requests':{'cpu':'500m','memory':'512Mi','ephemeral-storage':'12Gi'},'limits':{'cpu':'2','memory':'2Gi','ephemeral-storage':'14Gi'}},'volumeMounts':[{'name':'data','mountPath':'/data'}],'readinessProbe':{'httpGet':{'path':'/minio/health/ready','port':9000},'periodSeconds':2,'timeoutSeconds':2}}],'volumes':[{'name':'data','emptyDir':{'sizeLimit':'12Gi'}}]}}}}
    if local:
        minio['spec']['template']['spec']['containers'][0]['imagePullPolicy']='Never'
    result={'apiVersion':'v1','kind':'List','items':[{'apiVersion':'v1','kind':'Namespace','metadata':{'name':ns,'labels':{'study':'r0'}}},svc('minio',9000),minio,svc('reader',3000),app]}
    if local:
        for obj in result['items']:
            if obj['kind']=='Service':
                obj['spec']['type']='NodePort';obj['spec']['ports'][0]['nodePort']=30900 if obj['metadata']['name']=='minio' else 30080
    return result
if __name__=='__main__':
    p=argparse.ArgumentParser()
    for name in ('app-image','minio-image','release','manifest-key','manifest-sha'):p.add_argument('--'+name,required=True)
    a=p.parse_args();print(json.dumps(render(a.app_image,a.minio_image,a.release,a.manifest_key,a.manifest_sha),indent=2))
