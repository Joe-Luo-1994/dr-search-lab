"""Root-only narrowly scoped host-cgroup write for the dedicated study node."""
import json,pathlib,re,subprocess
def node():return json.loads(subprocess.check_output(['docker','inspect','dr-search-r0'],text=True,timeout=4))[0]
n=node();assert n['Name']=='/dr-search-r0' and n['State']['Running'];pid=n['State']['Pid'];ident=n['Id'];assert re.fullmatch('[a-f0-9]{64}',ident)
raw=pathlib.Path('/proc/'+str(pid)+'/cgroup').read_text().strip()
expected='0::/system.slice/docker-'+ident+'.scope'
assert raw in (expected,expected+'/init.scope'),('CGROUP_IDENTITY',raw,expected)
root=(pathlib.Path('/sys/fs/cgroup')/expected.split('::')[1].lstrip('/')).resolve()
assert root.is_relative_to('/sys/fs/cgroup/system.slice') and root.name=='docker-'+ident+'.scope'
read=lambda f:(root/f).read_text().strip()
assert read('memory.max')==str(12*1024**3) and read('memory.swap.max')=='0' and read('cpu.max')=='1200000 100000','HARD_LIMITS'
before=read('memory.high');again=node();assert again['Id']==ident and again['State']['Pid']==pid and again['State']['Running']
(root/'memory.high').write_text(str(6*1024**3))
after=read('memory.high');again=node();assert again['Id']==ident and again['State']['Pid']==pid and again['State']['Running']
assert after==str(6*1024**3) and read('memory.max')==str(12*1024**3) and read('memory.swap.max')=='0' and read('cpu.max')=='1200000 100000','HIGH_READBACK'
print(json.dumps({'nodeID':ident,'pid':pid,'pidCgroup':raw,'cgroup':str(root),'before':before,'after':after,'hardMax':read('memory.max'),'swapMax':read('memory.swap.max'),'cpuMax':read('cpu.max')}))
