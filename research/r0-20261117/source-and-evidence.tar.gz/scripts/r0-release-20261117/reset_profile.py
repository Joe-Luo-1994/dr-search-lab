"""Remove only verified disposable stopped study profile, after external preservation."""
import hashlib,json,pathlib,subprocess,re,sys
ident=sys.argv[1] if len(sys.argv)>1 else '20261117-094213'
assert re.fullmatch(r'[0-9]{8}-[0-9]{6}',ident)
work=pathlib.Path('/PUBLIC/LINUX_HOME/dr-r0-work');out=work/('profile-reset-'+ident);out.mkdir(exist_ok=False)
def call(args):return subprocess.check_output(args,text=True,timeout=120).strip()
profile=pathlib.Path.home()/'.minikube/profiles/dr-search-r0';config=json.loads((profile/'config.json').read_text());assert config['Name']=='dr-search-r0'
node=json.loads(call(['docker','inspect','dr-search-r0']))[0];assert not node['State']['Running']
assert node['Name']=='/dr-search-r0'
logs=work/'runs'/ident/'resolved-pod-logs';manifest=json.loads((logs/'manifest.json').read_text())
for row in manifest:assert hashlib.sha256((logs/row['file']).read_bytes()).hexdigest()==row['sha256']
names={row['pod'].split('_')[0] for row in manifest};assert names=={'dr-search-r0','kube-system'},names
for p in [work/'releases/v1/release.json',work/'releases/v1/pin.json',work/'image-context/Dockerfile'] :assert p.is_file()
image=call(['docker','image','inspect','r0-reader:build','--format','{{.Id}}']);assert image.startswith('sha256:')
old=call(['docker','inspect','minikube','--format','{{json .State}}'])
(out/'before.json').write_text(json.dumps({'config':config,'nodeID':node['Id'],'imageID':image,'preservedLogs':len(manifest),'oldMinikubeState':json.loads(old)},indent=2))
result=call(['minikube','delete','-p','dr-search-r0']);(out/'delete.log').write_text(result)
assert call(['docker','inspect','minikube','--format','{{json .State}}'])==old,'OTHER_PROFILE_CHANGED'
remaining=call(['docker','ps','-a','--filter','name=^/dr-search-r0$','--format','{{.Names}}']);assert not remaining
(out/'result.json').write_text(json.dumps({'deletedOnly':'dr-search-r0','otherProfileUnchanged':True,'preservedLogs':len(manifest)}));print((out/'result.json').read_text())
