import pathlib,sqlite3,json
r=pathlib.Path('/PUBLIC/LINUX_HOME/dr-search-lab-e1-20261115/repo/.lab/c-million-20261116/fixture-1000000')
for v in ('v1','v2'):
 c=sqlite3.connect(f'file:{r/v/"search.sqlite"}?mode=ro',uri=True);c.row_factory=sqlite3.Row
 row=dict(c.execute("SELECT * FROM pages WHERE pageId='p000003'").fetchone())
 print(json.dumps({'version':v,'page':{k:x for k,x in row.items() if k not in ('content','normalized_content')},'media':[dict(x) for x in c.execute('SELECT * FROM media LIMIT 1')],'schema':[x[0] for x in c.execute("SELECT sql FROM sqlite_master WHERE name IN ('pages','media','metadata')")]}))
 c.close()
