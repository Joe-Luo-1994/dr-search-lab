"""Build release descriptors/oracle from frozen synthetic artifacts, no remote publication."""
import hashlib,json,pathlib,sqlite3,shutil
OLD=pathlib.Path('/PUBLIC/LINUX_HOME/dr-search-lab-e1-20261115/repo')
WORK=pathlib.Path('/PUBLIC/LINUX_HOME/dr-r0-work')
FIX=OLD/'.lab/c-million-20261116/fixture-1000000'
BIN=OLD/'.lab/n1-native-20261117/tantivy-build-attempt2/target/release/n1-tantivy-reader'
def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def desc(p):return {'bytes':p.stat().st_size,'sha256':digest(p)}
def prepare(version,index):
 out=WORK/'releases'/version
 if out.exists() and any(out.iterdir()):raise RuntimeError('RELEASE_ALREADY_EXISTS')
 out.mkdir(parents=True,exist_ok=True)
 c=sqlite3.connect(f'file:{FIX/version/"search.sqlite"}?mode=ro',uri=True);c.row_factory=sqlite3.Row
 manifest={'format':'r0-release-v1','releaseId':version,'nodeVersion':'v22.18.0','icuVersion':'77.1','binary':desc(BIN),'files':[],'remoteObjects':[]}
 uploads=[]
 for name,p in [('search.sqlite',FIX/version/'search.sqlite'),('source.json',FIX/version/'manifest.json')]+[('index/'+p.name,p) for p in sorted(index.iterdir()) if p.is_file()]:
  d={'path':name,'key':f'r0/{version}/artifacts/{name}',**desc(p)};manifest['files'].append(d);uploads.append({'local':str(p),**d})
 for row in c.execute('SELECT bodyKey AS key,bodyBytes AS bytes,bodySha AS sha256 FROM pages WHERE bodyKey IS NOT NULL UNION SELECT key,bytes,sha256 FROM media'):
  d=dict(row);object_key=pathlib.Path(d['key']);p=FIX/version/'objects'/(object_key.parts[-2]+object_key.suffix)
  if desc(p)!={'bytes':d['bytes'],'sha256':d['sha256']}:raise RuntimeError('SOURCE_OBJECT_HASH')
  manifest['remoteObjects'].append(d);uploads.append({'local':str(p),**d})
 # Fixed oracle selected BEFORE observing server output. All results come from frozen source files.
 oracle={'version':version,'query':'uniquep000003','pageId':'p000003','title':'Knowledge page p000003'+(' revised' if version=='v2' else ''),'total':1,'tags':['t3','t4'],'changeQuery':'revisiontwo uniquep000003','changeTotal':1 if version=='v2' else 0,'tagChangedPage':'p000002','tagChangedTags':['t8','t9'] if version=='v2' else ['t2','t3']}
 page=dict(c.execute("SELECT * FROM pages WHERE pageId='p000003'").fetchone());media=dict(c.execute('SELECT * FROM media WHERE mediaId=?',(page['mediaId'],)).fetchone())
 oracle['body']={'bytes':page['bodyBytes'],'sha256':page['bodySha']};oracle['media']={'pageId':page['pageId'],**media};c.close()
 raw=json.dumps(manifest,separators=(',',':')).encode();(out/'release.json').write_bytes(raw)
 pin={'releaseId':version,'manifestKey':f'r0/{version}/release.json','manifestSha256':hashlib.sha256(raw).hexdigest(),'manifestLocal':str(out/'release.json')}
 (out/'pin.json').write_text(json.dumps(pin,indent=2));(out/'uploads.json').write_text(json.dumps(uploads,indent=2));(out/'oracle.json').write_text(json.dumps(oracle,indent=2))
 print(json.dumps({'version':version,'artifacts':len(manifest['files']),'remoteObjects':len(manifest['remoteObjects']),'bytes':sum(x['bytes'] for x in uploads),'pin':pin}))
if __name__=='__main__':
 import sys
 prepare(sys.argv[1],pathlib.Path(sys.argv[2]))
