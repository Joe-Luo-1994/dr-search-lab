import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,copyFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
test('HTTP probe and in-flight SIGTERM contract (stub Next/runtime, Linux)',{skip:process.platform==='win32',timeout:10000},async()=>{
 const dir=await mkdtemp(path.join(tmpdir(),'r0-server-'));let child;let log='';
 try{
  await mkdir(path.join(dir,'runtime'));await mkdir(path.join(dir,'node_modules/next'),{recursive:true});
  await copyFile(new URL('./server.mjs',import.meta.url),path.join(dir,'server.mjs'));
  await writeFile(path.join(dir,'node_modules/next/package.json'),JSON.stringify({type:'module',main:'index.js'}));
  await writeFile(path.join(dir,'node_modules/next/index.js'),`export default ()=>({prepare:async()=>{},getRequestHandler:()=>async(req,res)=>{res.writeHead(200);res.write('started');await new Promise(r=>setTimeout(r,300));res.end('finished');}});`);
  await writeFile(path.join(dir,'runtime/service.mjs'),`let ready=false;export async function initializeRuntime(){await new Promise(r=>setTimeout(r,500));ready=true;}export function runtimeHealth(){return {ready};}export async function closeRuntime(){console.log(JSON.stringify({event:'workers-closed'}));ready=false;}`);
  child=spawn(process.execPath,[path.join(dir,'server.mjs')],{env:{...process.env,PORT:'0',LISTEN_HOST:'127.0.0.1',RELEASE_ID:'v2'},stdio:['ignore','pipe','pipe']});
  child.stdout.on('data',b=>log+=b);child.stderr.on('data',b=>log+=b);
  let port;
  const deadline=Date.now()+3000;
  while(!port&&Date.now()<deadline){for(const line of log.split('\n')){try{const x=JSON.parse(line);if(x.event==='listening')port=x.port;}catch{}}await new Promise(r=>setTimeout(r,10));}
  assert.ok(port,log);const url='http://127.0.0.1:'+port;
  assert.equal((await fetch(url+'/health/live')).status,200);
  assert.equal((await fetch(url+'/health/ready')).status,503);
  await new Promise(r=>setTimeout(r,550));
  assert.equal((await fetch(url+'/health/ready')).status,200);
  const response=await fetch(url+'/hold'); // Headers arrive while body is still in flight.
  const exited=once(child,'exit');child.kill('SIGTERM');
  assert.equal(await response.text(),'startedfinished');
  const [code]=await exited;assert.equal(code,0,log);
  assert.match(log,/workers-closed/);assert.match(log,/"forced":false/);
 }finally{
  if(child&&child.exitCode===null){const exited=once(child,'exit');child.kill('SIGKILL');await exited;}
  await rm(dir,{recursive:true,force:true});
 }
});
