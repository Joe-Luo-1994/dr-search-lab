"""Create an isolated adapter copy, preserving frozen N1 implementation bytes."""
import hashlib,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[2]
SOURCE=ROOT/'scripts/n1-native-20261117/g3a'
DEST=pathlib.Path(__file__).resolve().parent/'runtime'
FILES=('service.mjs','pool.mjs','preloaded.mjs','metadata-worker.mjs','sqlite-worker.mjs','storage.mjs')
def main():
    if DEST.exists():raise RuntimeError('NEW_RUNTIME_DIRECTORY_REQUIRED')
    contents={name:(SOURCE/name).read_text(encoding='utf8') for name in FILES}
    before={name:hashlib.sha256((SOURCE/name).read_bytes()).hexdigest() for name in FILES}
    old="const g=c.g3a;if(!g||g.snapshotId!=='v1')throw Error('G3A_V1_ONLY');"
    new="const g=c.g3a;if(!g||!['v1','v2','v3'].includes(g.snapshotId)||g.snapshotId!==process.env.RELEASE_ID)throw Error('R0_RELEASE_ID_MISMATCH');"
    assert contents['preloaded.mjs'].count(old)==1
    contents['preloaded.mjs']=contents['preloaded.mjs'].replace(old,new)
    old="if(op==='status'){return json(res,200,"
    new="if(op==='status'){return json(res,active.fatal||active.closed?503:200,"
    assert contents['service.mjs'].count(old)==1
    contents['service.mjs']=contents['service.mjs'].replace(old,new)
    contents['service.mjs']=contents['service.mjs'].replace('let active,initializing,updating=false,contentInFlight=0;const retired=[];', 'let active,initializing,updating=false,contentInFlight=0;const retired=[];\nexport const initializeRuntime=()=>init();\nexport const runtimeHealth=()=>({ready:!!active&&!active.closed&&!active.fatal});\nexport const closeRuntime=async()=>{if(active)await active.close();};')
    old="await init();const c=await config();const url=new URL(req.url,'http://localhost');"
    new="await init();res.setHeader('x-r0-release',active.version);res.setHeader('x-r0-pod',process.env.HOSTNAME??'local');const c=await config();const url=new URL(req.url,'http://localhost');"
    assert contents['service.mjs'].count(old)==1
    contents['service.mjs']=contents['service.mjs'].replace(old,new)
    DEST.mkdir()
    for name,text in contents.items():
        if name in ('service.mjs','preloaded.mjs'):(DEST/name).write_text(text,encoding='utf8',newline='\n')
        else:(DEST/name).write_bytes((SOURCE/name).read_bytes())
    receipt={'scope':'offline adapter only; no deployment or R0 acceptance','sourceSha256':before,'adapterSha256':{name:hashlib.sha256((DEST/name).read_bytes()).hexdigest() for name in FILES},'changes':['Tantivy v1/v2 must equal pinned RELEASE_ID','status responds 503 for fatal or closed pool','release/pod response metadata for experimental observation'],'unchanged':['2+2 worker roles','queue/deadline/fatal policy','E search contract','SQLite metadata schema','storage adapter'],'remaining':['artifact installer','deployment/probes','termination handling','release/oracle generation','controlled capacity gate']}
    (DEST.parent/'runtime-receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf8')
    print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
