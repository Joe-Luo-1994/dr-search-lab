import hashlib,json,os,pathlib,re,subprocess,sys
ident=sys.argv[1] if len(sys.argv)>1 else '20261117-094213'
assert re.fullmatch(r'[0-9]{8}-[0-9]{6}',ident)
root=pathlib.Path('/PUBLIC/LINUX_HOME/dr-r0-work/runs')/ident
dest=root/'resolved-pod-logs';dest.mkdir(exist_ok=False);rows=[]
for p in (root/'stopped-pod-logs').rglob('*.log'):
 if not p.is_symlink():continue
 target=os.readlink(p)
 assert re.fullmatch(r'/var/lib/docker/containers/[a-f0-9]{64}/[a-f0-9]{64}-json.log',target)
 local=dest/(p.parent.parent.name+'-'+p.parent.name+'-'+p.name)
 subprocess.run(['docker','cp','dr-search-r0:'+target,str(local)],check=True,timeout=30)
 rows.append({'pod':p.parent.parent.name,'container':p.parent.name,'file':local.name,'bytes':local.stat().st_size,'sha256':hashlib.sha256(local.read_bytes()).hexdigest()})
assert len(rows)>=1
(dest/'manifest.json').write_text(json.dumps(rows,indent=2));print(json.dumps({'saved':len(rows),'bytes':sum(x['bytes'] for x in rows)}))
