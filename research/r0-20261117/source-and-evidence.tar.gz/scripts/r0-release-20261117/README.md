# R0 fixed-release adapter (not a deployed solution)

Original N1 files remain frozen. `runtime/` is a separate copy; only service/preloaded adapters change. `prepare_runtime.py` refuses an existing destination. `runtime-receipt.json` records original and current hashes.

## Artifact contract

`installer.mjs` expects a SHA256-pinned JSON manifest (`r0-release-v1`): `releaseId`, exact `nodeVersion` and `icuVersion`, `binary` bytes/sha256 matching the image binary, `files` with relative path/S3 key/bytes/sha256, and `remoteObjects` descriptors. Required local paths: `search.sqlite`, `source.json`, `index/meta.json`, `index/n1-manifest.json`; all index files must be listed. Maximum manifest 1MiB, local artifacts 6GiB. Downloader streams to `.part`, fsyncs, verifies, renames, then checks existing source/index lineage. `/release/config.json` appears only after successful verification.

Existing experimental SigV4 storage adapter is reused, not claimed production S3 compatibility. Bootstrap Secret is supplied separately; never commit credentials. Remote object descriptors are validated structurally but object completeness/membership must be established by the release publisher; installer success is not content-backup acceptance. Binary path is fixed by the image, not trusted from manifest.

One installer attempt per Pod volume: failed staging is not reused. Init retries retain the first error in `install-first-error.json` and repeat it in logs; operator fixes the artifact and replaces the failed Pod. No silent recovery/state machine is added. CLI total deadline is60s including local verification, not only network timeout. Synthetic tests call the library directly and do not test this hard process deadline.

## Serving and operations

`server.mjs` wraps Next. `/health/live` reports process responsiveness; startup/readiness require verified runtime and no fatal/closed pool. Readiness does not probe remote MinIO each time. Pool fatal has no new respawn: operator diagnosis and Pod replacement remain necessary. SIGTERM stops admission, waits up to10s for HTTP responses, closes workers, and exits by15s; Pod grace20s. Forced drain is logged as failure. This is not infinite-download continuity or cross-request version routing.

`deployment.py` renders JSON only. Requires digest-pinned app/MinIO images, `r0-bootstrap` Secret with `config.json`, and `r0-minio` Secret with test credentials. Never apply placeholders. Dedicated namespace `dr-search-r0`, app replicas1/surge1/unavailable0. Installer60s + app startup probe40s + minReady5s leaves15s within progressDeadline120s for scheduling and remaining overhead; this is a budget, not a guarantee. Images must be preloaded before the measured run. Slow legitimate startup may still fail the research gate; do not extend it mid-run.

MinIO `emptyDir` is a rebuildable laboratory fixture, NOT the proposed durable DR source. Replacing its Pod loses artifacts; this experiment must not claim MinIO-failure recovery. Formal deployment uses the existing remote persistent MinIO service. No need to restart MinIO between reader versions.

## Validation boundaries

Run `node --test installer.test.mjs runtime-contract.test.mjs server-contract.test.mjs` on Linux Node22.18.0. Installer uses in-memory fake responses and synthetic bytes; HTTP/drain test substitutes Next/runtime and is Linux-only. These prove bounded adapter contracts, not real Next/Rust/S3/Kubernetes behavior. Deployment is not applied, image not built, remote release not published. Real image startup, child-process cleanup, cancellation, resources, and complete oracle remain gates before R0.
