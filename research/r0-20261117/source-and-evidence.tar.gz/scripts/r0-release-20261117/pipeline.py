"""Linux controlled integration stages. Windows guard owns outer resource monitoring/lifetime."""
import argparse,concurrent.futures,hashlib,json,os,pathlib,secrets,subprocess,time,threading,urllib.request,urllib.error
from deployment import render
WORK=pathlib.Path('/PUBLIC/LINUX_HOME/dr-r0-work');HERE=pathlib.Path(__file__).resolve().parent
NODE='/PUBLIC/LINUX_HOME/.nvm/versions/node/v22.18.0/bin/node'
ENV=dict(os.environ,KUBECONFIG='/PUBLIC/LINUX_HOME/.minikube/profiles/dr-search-r0/r0.kubeconfig')
K=['kubectl','--context=dr-search-r0','--request-timeout=10s','-n','dr-search-r0']
def cmd(args,timeout=30,data=None,check=True):
 r=subprocess.run(args,input=data,capture_output=True,text=True,env=ENV,timeout=timeout)
 if check and r.returncode:raise RuntimeError(json.dumps({'command':args[:4],'exit':r.returncode,'stderr':r.stderr}))
 return r.stdout
def k(*args,**kw):return cmd(K+list(args),**kw)
def save(p,v):p.write_text(json.dumps(v,indent=2))
def apply(value):return k('apply','-f','-',data=json.dumps(value))
def http(base,route,identity='all',timeout=4):
 req=urllib.request.Request(base+route,headers={'x-cap-identity':identity})
 try:
  with urllib.request.urlopen(req,timeout=timeout) as r:return r.status,r.read(),dict(r.headers)
 except urllib.error.HTTPError as e:return e.code,e.read(),dict(e.headers)
def assert_read(base,o):
 for route,expected in [('/api/capi/page?pageId='+o['pageId']+'&version='+o['version'],o['body']),('/api/capi/media?pageId='+o['media']['pageId']+'&mediaId='+o['media']['mediaId']+'&version='+o['version'],o['media'])]:
  status,b,h=http(base,route);assert status==200,(status,b[:300]);assert len(b)==expected['bytes'] and hashlib.sha256(b).hexdigest()==expected['sha256'],'CONTENT_ORACLE'
def smoke(base,o):
 status,b,_=http(base,'/api/capi/search?q='+o['query']);r=json.loads(b)
 assert status==200 and r['snapshotId']==o['version'] and r['total']==1 and [h['pageId'] for h in r['hits']]==[o['pageId']] and r['hits'][0]['title']==o['title'],'SEARCH_ORACLE'
 assert_read(base,o)
 status,b,_=http(base,'/docs/'+o['pageId']+'?version='+o['version']);assert status==200 and o['title'].encode() in b and ('data-pageid="'+o['pageId']+'"').encode() in b and ('data-version="'+o['version']+'"').encode() in b and ('revisiontwo' if o['version']=='v2' else 'revisionone').encode() in b,'SSR_ORACLE'
 status,b,_=http(base,'/api/capi/status');r=json.loads(b)
 assert status==200 and not r['fatal'] and sorted(x['role'] for x in r['workerDetails'])==['metadata','metadata','search','search'] and len(set(r['workers']))==4,'WORKER_TOPOLOGY'
 return r
def verify_images(expected):
 pods=json.loads(k('get','pods','-o','json'));rows=[]
 for p in pods['items']:
  for c in p['status'].get('initContainerStatuses',[])+p['status'].get('containerStatuses',[]):
   image=c.get('imageID','')
   if image:
    observed=image.removeprefix('docker://').removeprefix('docker-pullable://')
    actual=cmd(['docker','exec','dr-search-r0','docker','image','inspect',observed,'--format','{{.Id}}']).strip()
    assert actual==expected,'IMAGE_ID_MISMATCH';rows.append({'pod':p['metadata']['name'],'container':c['name'],'reportedImageID':image,'resolvedConfigID':actual})
 return rows
def load(base,o,seconds,out):
 start=time.monotonic();rows=[];lock=threading.Lock()
 save(out.with_suffix('.planned.json'),{'seconds':seconds,'planned':seconds*3,'lanes':['search','page','media'],'deadlineSeconds':4,'maxPending':12})
 def record(row):
  with lock:
   rows.append(row)
   with out.with_suffix('.ndjson').open('a') as f:f.write(json.dumps(row)+'\n');f.flush()
  return row
 def task(i,lane,scheduled):
  before=time.monotonic();row={'i':i,'lane':lane,'scheduled':scheduled-start,'sent':before-start}
  if before-scheduled>=4:return record({**row,'ok':False,'error':'MISSED_DEADLINE'})
  try:
   if lane=='search':route='/api/capi/search?q='+o['query']
   elif lane=='page':route='/api/capi/page?pageId='+o['pageId']+'&version='+o['version']
   else:route='/api/capi/media?pageId='+o['media']['pageId']+'&mediaId='+o['media']['mediaId']+'&version='+o['version']
   s,b,h=http(base,route,timeout=max(.1,4-(before-scheduled)));row.update(status=s,latencyMs=(time.monotonic()-scheduled)*1000,pod=h.get('x-r0-pod'),release=h.get('x-r0-release'))
   if s!=200:raise RuntimeError('HTTP_'+str(s))
   if lane=='search':
    r=json.loads(b);assert r['snapshotId']==o['version'] and r['total']==1 and r['hits'][0]['title']==o['title']
   else:
    d=o['body'] if lane=='page' else o['media'];assert len(b)==d['bytes'] and hashlib.sha256(b).hexdigest()==d['sha256']
   if row['latencyMs']>4000:raise RuntimeError('DEADLINE')
   row['ok']=True
  except Exception as e:row.update(ok=False,error=str(e))
  return record(row)
 with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
  futures=[]
  for i in range(seconds):
   scheduled=start+i;time.sleep(max(0,scheduled-time.monotonic()))
   for lane in ('search','page','media'):
    futures=[f for f in futures if not f.done()]
    if len(futures)>=12:record({'i':i,'lane':lane,'scheduled':scheduled-start,'ok':False,'error':'MISSED_ADMISSION'})
    else:futures.append(pool.submit(task,i,lane,scheduled))
  for f in futures:f.result()
 save(out,rows);assert len(rows)==seconds*3 and all(x.get('ok') for x in rows),'MIXED_LOAD_FAILED'
 return {'planned':len(rows),'passed':len(rows),'maxLatencyMs':max(x['latencyMs'] for x in rows)}
def pod_probes():
 pods=json.loads(k('get','pods','-l','app=reader','-o','json'));rows=[]
 js="const fs=require('fs');(async()=>{const s=await(await fetch('http://127.0.0.1:3000/api/capi/status')).json();const workers=[];for(const p of fs.readdirSync('/proc').filter(x=>/^\\d+$/.test(x))){try{if(+p===process.pid)continue;const c=fs.readFileSync('/proc/'+p+'/cmdline','utf8');if(c.includes('/runtime/metadata-worker.mjs')||c.includes('/app/bin/n1-tantivy-reader\\u0000serve'))workers.push({pid:+p,role:c.includes('metadata-worker')?'metadata':'search'});}catch{}}console.log(JSON.stringify({status:s,workers,cpu:fs.readFileSync('/sys/fs/cgroup/cpu.max','utf8').trim(),memory:fs.readFileSync('/sys/fs/cgroup/memory.max','utf8').trim(),swap:fs.readFileSync('/sys/fs/cgroup/memory.swap.max','utf8').trim()}));})();"
 for pod in pods['items']:
  name=pod['metadata']['name'];data=json.loads(k('exec',name,'-c','reader','--','node','-e',js))
  assert data['cpu']=='400000 100000' and data['memory']==str(8*1024**3) and data['swap']=='0','POD_LIMITS'
  assert sorted(x['role'] for x in data['workers'])==['metadata','metadata','search','search'],'OS_WORKER_TOPOLOGY'
  assert {x['pid'] for x in data['workers']}==set(data['status']['workers']),'DUPLICATE_RUNTIME_POOL'
  rows.append({'pod':name,**data})
 assert rows,'NO_READER_PODS'
 return rows
def main():
 p=argparse.ArgumentParser();p.add_argument('--run',required=True);p.add_argument('--stage',choices=['preflight','recreate','high-single','recreate-high'],default='preflight');a=p.parse_args();run=pathlib.Path(a.run);run.mkdir(parents=True,exist_ok=False)
 begun=time.monotonic();result={'passed':False,'stage':a.stage};owned_uid=None
 try:
  existing=json.loads(k('get','namespace','dr-search-r0','--ignore-not-found','-o','json') or '{}');assert not existing,'NAMESPACE_EXISTS'
  iid=cmd(['docker','image','inspect','r0-reader:build','--format','{{.Id}}']).strip();tag='r0-reader:sha256-'+iid.split(':')[1]
  prior=cmd(['docker','image','inspect',tag,'--format','{{.Id}}'],check=False).strip()
  if prior:assert prior==iid,'IMMUTABLE_TAG_CONFLICT'
  else:cmd(['docker','tag',iid,tag])
  # Stream the archive rather than minikube CLI buffering under the 1GiB controller budget.
  save_error=(run/'image-save.stderr').open('wb')
  producer=subprocess.Popen(['docker','save',tag],stdout=subprocess.PIPE,stderr=save_error,env=ENV)
  consumer=subprocess.Popen(['docker','exec','-i','dr-search-r0','docker','load'],stdin=producer.stdout,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=ENV)
  producer.stdout.close()
  try:
   stdout,stderr=consumer.communicate(timeout=180);producer.wait(timeout=10)
   (run/'image-load.log').write_bytes(stdout+stderr)
   assert producer.returncode==0 and consumer.returncode==0,'IMAGE_STREAM_LOAD'
  finally:
   for process in (producer,consumer):
    if process.poll() is None:process.kill();process.wait(timeout=5)
   save_error.close()
  imported=cmd(['docker','exec','dr-search-r0','docker','image','inspect',tag,'--format','{{.Id}}']).strip();assert imported==iid,'PRELOAD_ID'
  save(run/'image.json',{'tag':tag,'hostConfigID':iid,'nodeConfigID':imported,'scope':'local Never tag plus runtime identity verification; not production digest enforcement'})
  ip=cmd(['minikube','-p','dr-search-r0','ip']).strip();base='http://'+ip+':30080'
  pin=json.loads((WORK/'releases/v1/pin.json').read_text());o=json.loads((WORK/'releases/v1/oracle.json').read_text())
  docs=render(tag,tag,'v1',pin['manifestKey'],pin['manifestSha256'],local=True)
  if a.stage in ('recreate','high-single','recreate-high'):docs['items'][4]['spec']['strategy']={'type':'Recreate'}
  docs['items'][0]['metadata']['labels']['r0-run']=run.name
  created=json.loads(k('create','-f','-','-o','json',data=json.dumps(docs['items'][0])));owned_uid=created['metadata']['uid']
  save(run/'namespace-owner.json',{'uid':owned_uid,'run':run.name})
  user='r0'+secrets.token_hex(6);password=secrets.token_hex(24)
  bootstrap={'endpoint':'http://minio:9000','bucket':'r0-lab','accessKey':user,'secretKey':password}
  apply({'apiVersion':'v1','kind':'Secret','metadata':{'name':'r0-bootstrap','namespace':'dr-search-r0'},'stringData':{'config.json':json.dumps(bootstrap)}})
  apply({'apiVersion':'v1','kind':'Secret','metadata':{'name':'r0-minio','namespace':'dr-search-r0'},'stringData':{'MINIO_ROOT_USER':user,'MINIO_ROOT_PASSWORD':password}})
  for d in docs['items'][1:4]:apply(d)
  k('rollout','status','deployment/minio','--timeout=90s',timeout=100)
  endpoint_checks=[];endpoint_deadline=time.monotonic()+30
  while time.monotonic()<endpoint_deadline:
   try:
    status,_,_=http('http://'+ip+':30900','/minio/health/ready',timeout=2)
    endpoint_checks.append({'at':time.time(),'status':status})
    if status==200:break
   except Exception as e:endpoint_checks.append({'at':time.time(),'error':str(e)})
   time.sleep(1)
  else:
   save(run/'minio-endpoint.json',endpoint_checks);raise RuntimeError('MINIO_ENDPOINT_NOT_READY')
  save(run/'minio-endpoint.json',endpoint_checks)
  private=WORK/'private';private.mkdir(exist_ok=True);config=private/'publish.json';config.write_text(json.dumps({**bootstrap,'endpoint':'http://'+ip+':30900'}));config.chmod(0o600)
  env=dict(ENV,CAP_CONFIG=str(config));r=subprocess.run([NODE,str(HERE/'publish.mjs'),str(WORK/'releases/v1'),str(run/'publish-v1.json')],capture_output=True,text=True,env=env,timeout=240)
  (run/'publisher.log').write_text(r.stdout+r.stderr);assert r.returncode==0,'PUBLISH_FAILED'
  t=time.monotonic();apply(docs['items'][4]);k('rollout','status','deployment/reader','--timeout=120s',timeout=130);save(run/'startup.json',{'seconds':time.monotonic()-t})
  save(run/'smoke-single.json',smoke(base,o))
  if a.stage=='high-single':
   save(run/'images.json',verify_images(iid));save(run/'per-pod-probes.json',pod_probes())
   save(run/'single-load-summary.json',load(base,o,60,run/'single-load.json'))
   result.update(passed=True,elapsedSeconds=time.monotonic()-begun,scope='memory.high 6GiB single-reader cold installation and 60s synthetic steady diagnostic only; no rollout')
  elif a.stage in ('recreate','recreate-high'):
   save(run/'images.json',verify_images(iid));save(run/'per-pod-probes.json',pod_probes())
   from formal_recreate import run as formal_run
   result['formal']=formal_run(base,tag,iid,run,ENV,config)
   result.update(passed=True,elapsedSeconds=time.monotonic()-begun,scope='single-reader Recreate synthetic release lifecycle; transition outage is measured, not transparent availability')
  else:
   save(run/'single-load-summary.json',load(base,o,30,run/'single-load.json'))
   k('scale','deployment/reader','--replicas=2');k('rollout','status','deployment/reader','--timeout=120s',timeout=130)
   save(run/'images.json',verify_images(iid));save(run/'per-pod-probes.json',pod_probes());save(run/'double-load-summary.json',load(base,o,60,run/'double-load.json'));save(run/'smoke-double.json',smoke(base,o))
   pods=json.loads(k('get','pods','-l','app=reader','-o','json'));victim=pods['items'][0]['metadata']['name']
   # SIGTERM real PID1; inspect previous-container logs after kubelet restarts it.
   before=next(c['restartCount'] for c in pods['items'][0]['status']['containerStatuses'] if c['name']=='reader')
   k('exec',victim,'-c','reader','--','sh','-c','kill -TERM 1')
   end=time.monotonic()+60
   while time.monotonic()<end:
    pod=json.loads(k('get','pod',victim,'-o','json'));statuses=pod['status'].get('containerStatuses',[])
    if any(c['name']=='reader' and c['restartCount']>before and c.get('ready') for c in statuses):break
    time.sleep(1)
   else:raise RuntimeError('RESTART_AFTER_SIGTERM_TIMEOUT')
   previous=k('logs',victim,'-c','reader','--previous');(run/'sigterm-previous.log').write_text(previous)
   assert '"event":"drain-end"' in previous and '"forced":false' in previous,'GRACEFUL_DRAIN'
   smoke(base,o)
   k('scale','deployment/reader','--replicas=1');k('rollout','status','deployment/reader','--timeout=60s',timeout=70)
   result.update(passed=True,elapsedSeconds=time.monotonic()-begun,scope='real V1 installation/SSR/search/read/download and two-reader synthetic preflight; idle SIGTERM only, not in-flight drain or R0 rollout')
 except Exception as e:result['error']=str(e)
 finally:
  if owned_uid:
   try:
    current=json.loads(k('get','namespace','dr-search-r0','-o','json'))
    assert current['metadata']['uid']==owned_uid and current['metadata']['labels'].get('r0-run')==run.name,'NAMESPACE_OWNERSHIP_CHANGED'
    for name,args in [('pods',['get','pods','-o','json']),('events',['get','events','-o','json']),('deployments',['get','deployments','-o','json'])]:
     try:(run/(name+'.json')).write_text(k(*args))
     except Exception as e:save(run/(name+'-error.json'),str(e))
    pods=json.loads(k('get','pods','-o','json'))
    for pod in pods['items']:
     for c in pod['spec'].get('initContainers',[])+pod['spec'].get('containers',[]):
      (run/(pod['metadata']['name']+'-'+c['name']+'.log')).write_text(k('logs',pod['metadata']['name'],'-c',c['name'],check=False))
    k('delete','namespace','dr-search-r0','--wait=true','--timeout=45s',timeout=55)
   except Exception as e:result['cleanupError']=str(e);result['passed']=False
  else:result['namespaceCleanup']='not-owned; no namespace read/delete performed'
  save(run/'result.json',result);print(json.dumps(result))
 return 0 if result['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
