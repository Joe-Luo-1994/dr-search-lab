"""Fetch an official Docker Hub image through IPv4, verify blobs, load local Docker archive."""
import argparse,hashlib,json,pathlib,subprocess,tarfile,time
def main():
 p=argparse.ArgumentParser();p.add_argument('repository');p.add_argument('tag');p.add_argument('out');a=p.parse_args()
 out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=False)
 def curl(url,headers=()):
  cmd=['curl','-4','--fail','--silent','--show-error','--location','--connect-timeout','10','--max-time','120',url]
  for h in headers:cmd+=['-H',h]
  return subprocess.run(cmd,check=True,capture_output=True).stdout
 token=json.loads(curl('https://auth.docker.io/token?service=registry.docker.io&scope=repository:'+a.repository+':pull'))['token']
 headers=['Authorization: Bearer '+token,'Accept: application/vnd.oci.image.index.v1+json, application/vnd.docker.distribution.manifest.list.v2+json, application/vnd.docker.distribution.manifest.v2+json, application/vnd.oci.image.manifest.v1+json']
 base='https://registry-1.docker.io/v2/'+a.repository
 raw=curl(base+'/manifests/'+a.tag,headers);m=json.loads(raw)
 if 'manifests' in m:
  chosen=next(x for x in m['manifests'] if x.get('platform',{}).get('architecture')=='amd64' and x['platform']['os']=='linux')
  raw=curl(base+'/manifests/'+chosen['digest'],headers)
  if 'sha256:'+hashlib.sha256(raw).hexdigest()!=chosen['digest']:raise RuntimeError('MANIFEST_DIGEST')
  m=json.loads(raw)
 manifest_sha='sha256:'+hashlib.sha256(raw).hexdigest();(out/'registry-manifest.json').write_bytes(raw)
 files=[]
 for d in [m['config']]+m['layers']:
  raw=curl(base+'/blobs/'+d['digest'],headers)
  if len(raw)!=d['size'] or 'sha256:'+hashlib.sha256(raw).hexdigest()!=d['digest']:raise RuntimeError('BLOB_DIGEST')
  name=d['digest'].split(':')[1]+'.blob';(out/name).write_bytes(raw);files.append(name)
 archive_manifest=[{'Config':files[0],'RepoTags':[a.repository+':'+a.tag],'Layers':files[1:]}]
 (out/'manifest.json').write_text(json.dumps(archive_manifest))
 with tarfile.open(out/'image.tar','w') as tf:
  for name in files+['manifest.json']:tf.add(out/name,arcname=name)
 subprocess.run(['docker','load','-i',str(out/'image.tar')],check=True)
 receipt={'repository':a.repository,'tag':a.tag,'manifestDigest':manifest_sha,'configDigest':m['config']['digest'],'verifiedBlobs':len(files),'scope':'official registry via IPv4; local archive load; no push'}
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
if __name__=='__main__':main()
