param([switch]$Execute)
throw 'Superseded unexecuted draft. Use reviewer-approved environment_preflight.py instead.'
$ErrorActionPreference='Stop'
if(-not $Execute){throw 'Explicit -Execute required'}
$root=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$out=Join-Path $root ('evidence/r0-release-20261117/environment-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $out -Force | Out-Null
$timer=[Diagnostics.Stopwatch]::StartNew()
$started=$false
function Linux([string]$command,[int]$timeout=8000){
  $info=[Diagnostics.ProcessStartInfo]::new('wsl.exe')
  $info.UseShellExecute=$false;$info.CreateNoWindow=$true
  $info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
  foreach($arg in @('-d','Ubuntu','--','bash','-lc',$command)){$info.ArgumentList.Add($arg)}
  $proc=[Diagnostics.Process]::Start($info)
  $stdout=$proc.StandardOutput.ReadToEndAsync();$stderr=$proc.StandardError.ReadToEndAsync()
  if(-not $proc.WaitForExit($timeout)){$proc.Kill();throw 'WSL_CALL_TIMEOUT'}
  $output=$stdout.GetAwaiter().GetResult();$errorText=$stderr.GetAwaiter().GetResult()
  if($proc.ExitCode -ne 0){throw $errorText}
  return $output
}
try {
  $available=(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory*1KB
  if($available -lt 14GB){throw "HOST_START_GUARD available=$available"}
  $running=Linux 'docker inspect dr-search-r0 --format {{.State.Running}}'
  if($running.Trim() -ne 'false'){throw 'PROFILE_ALREADY_RUNNING'}
  Linux 'docker update --cpus=12 --memory=12g --memory-swap=12g dr-search-r0' | Out-File (Join-Path $out 'update.txt')
  $started=$true
  Linux 'docker start dr-search-r0' | Out-File (Join-Path $out 'start.txt')
  $ready=$false
  while($timer.Elapsed.TotalSeconds -lt 240){
    $available=(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory*1KB
    if($available -lt 6GB){throw 'HOST_AVAILABLE_GUARD'}
    $raw=Linux 'docker exec dr-search-r0 sh -c ''for f in cpu.max memory.max memory.swap.max memory.current memory.swap.current memory.events; do echo $f; cat /sys/fs/cgroup/$f; done'''
    @{elapsed=$timer.Elapsed.TotalSeconds;hostAvailable=$available;cgroup=$raw}|ConvertTo-Json -Compress|Add-Content (Join-Path $out 'samples.ndjson')
    if($raw -notmatch 'cpu.max\s+1200000 100000' -or $raw -notmatch 'memory.max\s+12884901888' -or $raw -notmatch 'memory.swap.max\s+0'){throw 'CGROUP_LIMIT_MISMATCH'}
    if($raw -match 'memory.current\s+(\d+)' -and [long]$Matches[1] -gt 10GB){throw 'CLUSTER_MEMORY_GUARD'}
    if($raw -notmatch 'memory.swap.current\s+0'){throw 'SWAP_USED'}
    if($raw -match '(?m)^oom(?:_kill)? [1-9]'){throw 'OOM_EVENT'}
    $state=Linux 'kubectl --context=dr-search-r0 --request-timeout=3s get nodes --no-headers 2>/dev/null || true'
    if($state -match '\sReady\s'){$ready=$true;break}
    Start-Sleep -Seconds 2
  }
  if(-not $ready){throw 'NODE_READY_DEADLINE'}
  Linux 'kubectl --context=dr-search-r0 --request-timeout=5s get pods -A -o json' | Out-File (Join-Path $out 'pods.json')
  @{status='node-ready-limits-verified';elapsed=$timer.Elapsed.TotalSeconds;scope='empty cluster only; no research workloads'}|ConvertTo-Json|Out-File (Join-Path $out 'result.json')
} catch {
  @{status='failed';error=$_.Exception.Message;elapsed=$timer.Elapsed.TotalSeconds}|ConvertTo-Json|Out-File (Join-Path $out 'result.json')
  throw
} finally {
  if($started){Linux 'docker stop --time=10 dr-search-r0' 20000 | Out-File (Join-Path $out 'stop.txt')}
  Write-Output $out
}
