"""Rebuild only disposable study profile, independent host guard, stop after preparation."""
import json,pathlib,subprocess,time
from environment_preflight import linux,available
out=pathlib.Path(__file__).resolve().parents[2]/'evidence/r0-release-20261117'/time.strftime('profile-rebuild-%Y%m%d-%H%M%S');out.mkdir(parents=True)
result={'passed':False};proc=None;unit='dr-r0-rebuild-'+time.strftime('%Y%m%d-%H%M%S')
try:
 assert available()>=14*1024**3,'HOST_START_GUARD'
 assert linux("docker ps -a --filter 'name=^/dr-search-r0$' --format '{{.Names}}'")=='','PROFILE_EXISTS'
 command=['wsl','-d','Ubuntu','--','systemd-run','--user','--unit='+unit,'--wait','--pipe','--setenv=KUBECONFIG=/PUBLIC/LINUX_HOME/dr-r0-work/private/rebuilt.kubeconfig','-p','RuntimeMaxSec=300','-p','TimeoutStopSec=5','-p','KillMode=control-group','minikube','start','-p','dr-search-r0','--driver=docker','--container-runtime=docker','--kubernetes-version=v1.31.0','--cpus=4','--memory=6144','--keep-context','--wait=apiserver,system_pods','--wait-timeout=180s']
 started=time.monotonic()
 with (out/'create.log').open('w',encoding='utf8') as log,(out/'host.ndjson').open('w') as f:
  proc=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
  while proc.poll() is None:
   free=available();elapsed=time.monotonic()-started;f.write(json.dumps({'elapsed':elapsed,'available':free})+'\n');f.flush()
   assert free>=6*1024**3,'HOST_AVAILABLE'
   assert elapsed<300,'REBUILD_DEADLINE'
   time.sleep(2)
  assert proc.returncode==0,'PROFILE_BUILD_FAILED'
 linux('cp /PUBLIC/LINUX_HOME/dr-r0-work/private/rebuilt.kubeconfig /PUBLIC/LINUX_HOME/.minikube/profiles/dr-search-r0/r0.kubeconfig')
 linux('chmod 600 /PUBLIC/LINUX_HOME/.minikube/profiles/dr-search-r0/r0.kubeconfig')
 result.update(passed=True,seconds=time.monotonic()-started)
except Exception as e:result['error']=str(e)
finally:
 try:
  if proc:
   try:linux('systemctl --user stop '+unit,20)
   except Exception as e:result['unitStopObservation']=str(e)
   result['unitCleanup']=json.loads(linux('python3 "/PUBLIC/WINDOWS_HOME/Documents/ChatGPT/Search Playground/scripts/r0-release-20261117/unit_state.py" '+unit))
   if proc.poll() is None:proc.wait(timeout=10)
 except Exception as e:result.update(passed=False,unitCleanupError=str(e))
 try:
  if proc:
   linux('docker stop --time=10 dr-search-r0',20)
   result['stopped']=linux('docker inspect dr-search-r0 --format {{.State.Running}}')=='false';assert result['stopped']
 except Exception as e:result.update(passed=False,cleanupError=str(e))
 (out/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps({'out':str(out),**result}))
raise SystemExit(0 if result['passed'] else 1)
