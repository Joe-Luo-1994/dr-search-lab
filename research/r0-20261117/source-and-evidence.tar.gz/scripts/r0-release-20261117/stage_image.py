import hashlib,json,pathlib,shutil
HERE=pathlib.Path(__file__).resolve().parent
OLD=pathlib.Path('/PUBLIC/LINUX_HOME/dr-search-lab-e1-20261115/repo')
OUT=pathlib.Path('/PUBLIC/LINUX_HOME/dr-r0-work/image-context')
if OUT.exists():raise SystemExit('NEW_IMAGE_CONTEXT_REQUIRED')
OUT.mkdir(parents=True);(OUT/'project').mkdir();(OUT/'bin').mkdir()
project=OLD/'.lab/c-million-20261116/project'
for name in ('package.json','package-lock.json'):shutil.copy2(project/name,OUT/'project'/name)
shutil.copytree(project/'.next',OUT/'project/.next',symlinks=True)
shutil.copytree((project/'node_modules').resolve(),OUT/'project/node_modules',symlinks=True)
(OUT/'node_modules').symlink_to('project/node_modules')
shutil.copytree(HERE/'runtime',OUT/'runtime')
for name in ('server.mjs','installer.mjs'):shutil.copy2(HERE/name,OUT/name)
binary=OLD/'.lab/n1-native-20261117/tantivy-build-attempt2/target/release/n1-tantivy-reader'
shutil.copy2(binary,OUT/'bin/n1-tantivy-reader');(OUT/'bin/n1-tantivy-reader').chmod(0o755)
shutil.copy2(OLD/'work/minio-official-build/bin/minio',OUT/'bin/minio');(OUT/'bin/minio').chmod(0o755)
(OUT/'Dockerfile').write_text('FROM node:22.18.0-bookworm-slim\nWORKDIR /app\nCOPY . /app/\nENV NEXT_TELEMETRY_DISABLED=1\nCMD ["node", "/app/server.mjs"]\n')
receipt={'binarySha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'scope':'frozen N1 Next build and dependencies plus isolated R0 adapter; same image contains lab MinIO binary'}
(OUT.parent/'stage-image.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
