import {createHash} from 'node:crypto';
import {mkdir,open,rename,statfs,writeFile,readFile} from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {mkdirSync,writeFileSync,readFileSync} from 'node:fs';
import {verifyPreloaded} from './runtime/preloaded.mjs';
const hash=b=>createHash('sha256').update(b).digest('hex');
const descriptor=d=>d&&Number.isSafeInteger(d.bytes)&&d.bytes>=0&&/^[a-f0-9]{64}$/.test(d.sha256);
const key=k=>typeof k==='string'&&/^[a-zA-Z0-9_./-]+$/.test(k)&&!k.includes('..');
export function validateManifest(m,releaseId){
 if(m?.format!=='r0-release-v1'||m.releaseId!==releaseId||!['v1','v2','v3'].includes(releaseId))throw Error('RELEASE_PIN');
 if(m.nodeVersion!==process.version||m.icuVersion!==process.versions.icu)throw Error('TOKEN_RUNTIME_MISMATCH');
 if(!descriptor(m.binary)||!Array.isArray(m.files)||m.files.length<4||m.files.length>4096)throw Error('MANIFEST_SCHEMA');
 const names=new Set();let bytes=0;
 for(const d of m.files){
  if(!descriptor(d)||!key(d.key)||typeof d.path!=='string'||!(/^(search\.sqlite|source\.json|index\/[a-zA-Z0-9_.-]+)$/.test(d.path))||d.path.includes('..')||names.has(d.path))throw Error('FILE_DESCRIPTOR');
  names.add(d.path);bytes+=d.bytes;
 }
 if(!['search.sqlite','source.json','index/meta.json','index/n1-manifest.json'].every(x=>names.has(x))||bytes>6*1024**3)throw Error('ARTIFACT_BUDGET_OR_SET');
 if(!Array.isArray(m.remoteObjects)||m.remoteObjects.length>10000)throw Error('CONTENT_MANIFEST');
 const keys=new Set();
 for(const d of m.remoteObjects){if(!descriptor(d)||!key(d.key)||keys.has(d.key))throw Error('CONTENT_DESCRIPTOR');keys.add(d.key);}
 return bytes;
}
export async function install({releaseId,manifestKey,manifestSha256,root,binaryPath,bootstrap,get}){
 if(!key(manifestKey)||!/^[a-f0-9]{64}$/.test(manifestSha256))throw Error('MANIFEST_PIN');
 const started=performance.now();const signal=AbortSignal.timeout(60000);
 const response=await get(manifestKey,signal);if(!response.ok)throw Error('MANIFEST_HTTP_'+response.status);
 const chunks=[];let n=0;
 for await(const chunk of response.body){n+=chunk.length;if(n>1024**2)throw Error('MANIFEST_SIZE');chunks.push(chunk);}
 const raw=Buffer.concat(chunks);if(hash(raw)!==manifestSha256)throw Error('MANIFEST_HASH');
 const m=JSON.parse(raw);const total=validateManifest(m,releaseId);
 await mkdir(root,{recursive:true});
 const disk=await statfs(root);if(Number(disk.bavail)*Number(disk.bsize)<total+1024**3)throw Error('DISK_HEADROOM');
 // One attempt per Pod volume. A failed staging directory requires Pod replacement, not silent reuse.
 const staging=path.join(root,'staging');await mkdir(staging);await mkdir(path.join(staging,'index'));
 const receipts=[];
 for(const d of m.files){
  const target=path.join(staging,d.path),began=performance.now();
  const r=await get(d.key,signal);if(!r.ok)throw Error('ARTIFACT_HTTP_'+r.status+':'+d.path);
  const f=await open(target+'.part','wx',0o600);const digest=createHash('sha256');let bytes=0;
  try{for await(const b of r.body){bytes+=b.length;if(bytes>d.bytes)throw Error('ARTIFACT_SIZE:'+d.path);digest.update(b);await f.writeFile(b);}await f.sync();}finally{await f.close();}
  if(bytes!==d.bytes||digest.digest('hex')!==d.sha256)throw Error('ARTIFACT_HASH:'+d.path);
  await rename(target+'.part',target);receipts.push({path:d.path,bytes,elapsedMs:performance.now()-began});
 }
 const local=name=>{const d=m.files.find(x=>x.path===name);return {path:path.join(staging,name),bytes:d.bytes,sha256:d.sha256};};
 const config={...bootstrap,eventLog:path.join(root,'events.ndjson'),testHooks:false,g3a:{engine:'T1',snapshotId:releaseId,metadata:local('search.sqlite'),sourceManifest:local('source.json'),binary:{path:binaryPath,bytes:m.binary.bytes,sha256:m.binary.sha256},indexDir:path.join(staging,'index'),indexFiles:m.files.filter(x=>x.path.startsWith('index/')).map(x=>({path:path.basename(x.path),bytes:x.bytes,sha256:x.sha256}))}};
 // Reuse lineage/schema manifest checks; actual database and reader startup belong to app readiness.
 await verifyPreloaded(config);
 const receipt={releaseId,manifestSha256,installedBytes:total,elapsedMs:performance.now()-started,files:receipts,remoteObjectCount:m.remoteObjects.length,remoteContentVerified:false};
 await writeFile(path.join(root,'install-receipt.json'),JSON.stringify(receipt),{flag:'wx',mode:0o600});
 await writeFile(path.join(root,'config.json.part'),JSON.stringify(config),{flag:'wx',mode:0o600});
 await rename(path.join(root,'config.json.part'),path.join(root,'config.json'));
 return receipt;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href){
 const root=process.env.INSTALL_ROOT??'/release';
 function failure(error){
  const current={event:'install-failed',releaseId:process.env.RELEASE_ID,error};let first=current;
  try{mkdirSync(root,{recursive:true});writeFileSync(path.join(root,'install-first-error.json'),JSON.stringify(current),{flag:'wx',mode:0o600});}catch{}
  try{first=JSON.parse(readFileSync(path.join(root,'install-first-error.json'),'utf8'));}catch{}
  console.error(JSON.stringify({...current,firstError:first.error}));
 }
 const hard=setTimeout(()=>{failure('INSTALL_TOTAL_DEADLINE_60S');process.exit(1);},60000);
 try{
  const {remote}=await import('./runtime/storage.mjs');
  let bootstrap;try{bootstrap=JSON.parse(await readFile(process.env.CAP_CONFIG,'utf8'));}catch{throw Error('BOOTSTRAP_CONFIG_INVALID');}
  const receipt=await install({releaseId:process.env.RELEASE_ID,manifestKey:process.env.RELEASE_MANIFEST_KEY,manifestSha256:process.env.RELEASE_MANIFEST_SHA256,root,binaryPath:'/app/bin/n1-tantivy-reader',bootstrap,get:(k,signal)=>remote('GET',k,{signal})});
  console.log(JSON.stringify({event:'installed',...receipt}));
 }catch(e){failure(e.message);process.exitCode=1;}finally{clearTimeout(hard);}
}
