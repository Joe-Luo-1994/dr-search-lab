"""Windows host guard for an EMPTY, dedicated minikube container; no workload launch."""
import argparse, ctypes, datetime, json, pathlib, subprocess, threading, time

class Memory(ctypes.Structure):
    _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(x,ctypes.c_ulonglong) for x in ('total','available','page_total','page_available','virtual_total','virtual_available','extended')]

def available():
    m=Memory();m.length=ctypes.sizeof(m)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):raise RuntimeError('HOST_METRIC')
    return m.available

def linux(cmd,timeout=8):
    prefix='export KUBECONFIG=/PUBLIC/LINUX_HOME/.minikube/profiles/dr-search-r0/r0.kubeconfig; '
    try:
        p=subprocess.run(['wsl','-d','Ubuntu','--','bash','-lc',prefix+cmd],capture_output=True,text=True,timeout=timeout)
    except subprocess.TimeoutExpired as e:
        def decode(v):return v.decode('utf8',errors='replace') if isinstance(v,bytes) else v
        raise RuntimeError(json.dumps({'type':'TimeoutExpired','timeout':timeout,'stdout':decode(e.stdout),'stderr':decode(e.stderr)})) from e
    if p.returncode:raise RuntimeError(json.dumps({'exitCode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}))
    return p.stdout.strip()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');args=ap.parse_args()
    if not args.execute:raise SystemExit('Explicit --execute required')
    out=pathlib.Path(__file__).resolve().parents[2]/'evidence/r0-release-20261117'/time.strftime('environment-%Y%m%d-%H%M%S')
    out.mkdir(parents=True,exist_ok=False)
    started=time.monotonic();done=threading.Event();abort=threading.Event();reason=[];heartbeat=[None];lifecycle=threading.Lock()
    def save(name,value):(out/name).write_text(json.dumps(value,indent=2),encoding='utf8')
    def watchdog():
        try:
            with (out/'host.ndjson').open('w',encoding='utf8') as f:
                while not done.is_set():
                    now=time.monotonic();free=available()
                    f.write(json.dumps({'elapsed':now-started,'available':free})+'\n');f.flush()
                    if free<6*1024**3:raise RuntimeError('HOST_AVAILABLE_GUARD')
                    if now-started>300:raise RuntimeError('TOTAL_DEADLINE')
                    if heartbeat[0] is not None and now-heartbeat[0]>10:raise RuntimeError('METRIC_GAP')
                    done.wait(2)
        except Exception as e:
            reason.append(str(e));abort.set()
            try:
                with lifecycle:linux('docker stop --time=10 dr-search-r0',20)
            except Exception as cleanup:save('watchdog-cleanup-error.json',str(cleanup))
    thread=None;touched=False;result={'status':'failed'}
    try:
        if available()<14*1024**3:raise RuntimeError('HOST_START_GUARD')
        thread=threading.Thread(target=watchdog,daemon=True);thread.start()
        if linux('docker inspect dr-search-r0 --format {{.State.Running}}')!='false':raise RuntimeError('PROFILE_ALREADY_RUNNING')
        save('update.json',linux('docker update --cpus=12 --memory=12g --memory-swap=12g dr-search-r0'))
        with lifecycle:
            if abort.is_set():raise RuntimeError(';'.join(reason))
            touched=True
            boot_wall=time.time()
            save('start.json',{'output':linux('docker start dr-search-r0'),'wallTime':boot_wall})
        if abort.is_set():raise RuntimeError(';'.join(reason))
        ip=linux('minikube -p dr-search-r0 ip')
        import ipaddress
        ipaddress.IPv4Address(ip)
        # docker recreates container /etc/hosts on restart; restore minikube's local API alias.
        linux("docker exec dr-search-r0 sh -c 'echo "+ip+" control-plane.minikube.internal >> /etc/hosts'")
        aliases=linux('docker exec dr-search-r0 getent hosts control-plane.minikube.internal')
        save('api-alias.json',aliases)
        if {line.split()[0] for line in aliases.splitlines()}!={ip}:raise RuntimeError('API_ALIAS_MISMATCH')
        linux('kubectl config set-cluster dr-search-r0 --server=https://'+ip+':8443 --certificate-authority=/PUBLIC/LINUX_HOME/.minikube/ca.crt')
        linux('kubectl config set-credentials dr-search-r0 --client-certificate=/PUBLIC/LINUX_HOME/.minikube/profiles/dr-search-r0/client.crt --client-key=/PUBLIC/LINUX_HOME/.minikube/profiles/dr-search-r0/client.key')
        linux('kubectl config set-context dr-search-r0 --cluster=dr-search-r0 --user=dr-search-r0')
        if abort.is_set():raise RuntimeError(';'.join(reason))
        linux('docker exec dr-search-r0 systemctl start kubelet')
        heartbeat[0]=time.monotonic();base=None;ready_at=None
        with (out/'cgroup.ndjson').open('w',encoding='utf8') as f:
            while time.monotonic()-started<240:
                if abort.is_set():raise RuntimeError(';'.join(reason))
                # Avoid variable expansion across Windows/WSL/bash/sh quoting layers.
                metric_names=('cpu.max','memory.max','memory.swap.max','memory.current','memory.swap.current','memory.events')
                metric_command='; '.join('echo @'+name+'; cat /sys/fs/cgroup/'+name for name in metric_names)
                raw=linux("docker exec dr-search-r0 sh -c '"+metric_command+"'")
                rows={}
                for block in raw.split('@')[1:]:
                    key,value=block.split('\n',1);rows[key]=value.strip()
                required={'cpu.max','memory.max','memory.swap.max','memory.current','memory.swap.current','memory.events'}
                if set(rows)!=required:raise RuntimeError('CGROUP_METRICS_MISSING')
                if rows['cpu.max']!='1200000 100000' or rows['memory.max']!=str(12*1024**3) or rows['memory.swap.max']!='0':raise RuntimeError('LIMIT_MISMATCH')
                events=dict(line.split() for line in rows['memory.events'].splitlines())
                if not {'oom','oom_kill'}<=events.keys():raise RuntimeError('OOM_METRICS_MISSING')
                counts={k:int(events[k]) for k in ('oom','oom_kill')}
                if base is None:
                    base=counts.copy()
                    # Reject prior events conservatively too; preserve baseline, never reset counters.
                    if any(base.values()):raise RuntimeError('PREEXISTING_OOM_EVENT')
                if any(counts[k]>base[k] for k in base):raise RuntimeError('OOM_DELTA')
                if int(rows['memory.current'])>10*1024**3:raise RuntimeError('CLUSTER_MEMORY_GUARD')
                if int(rows['memory.swap.current']):raise RuntimeError('SWAP_USED')
                heartbeat[0]=time.monotonic()
                f.write(json.dumps({'elapsed':heartbeat[0]-started,'metrics':rows})+'\n');f.flush()
                # 3s API deadline plus 8s outer bound; watchdog independently enforces metric gap.
                try:
                    state=linux('kubectl --context=dr-search-r0 --request-timeout=3s get nodes -o json')
                except Exception as e:
                    with (out/'node-observations.ndjson').open('a',encoding='utf8') as nf:
                        nf.write(json.dumps({'elapsed':time.monotonic()-started,'error':str(e)})+'\n')
                    if ready_at is not None:raise RuntimeError('NODE_OBSERVATION_FAILED_AFTER_READY') from e
                    abort.wait(2);continue
                with (out/'node-observations.ndjson').open('a',encoding='utf8') as nf:
                    nf.write(json.dumps({'elapsed':time.monotonic()-started,'response':state})+'\n')
                try:
                    nodes=json.loads(state)['items'];ready=bool(nodes) and all(any(c['type']=='Ready' and c['status']=='True' for c in n['status']['conditions']) for n in nodes)
                except Exception as e:raise RuntimeError('NODE_RESPONSE_INVALID') from e
                # Require this boot's lease before counting an old persisted Ready condition.
                lease_raw=linux('kubectl --context=dr-search-r0 --request-timeout=3s -n kube-node-lease get lease dr-search-r0 -o json')
                with (out/'lease-observations.ndjson').open('a',encoding='utf8') as lf:
                    lf.write(json.dumps({'elapsed':time.monotonic()-started,'response':lease_raw})+'\n')
                lease=json.loads(lease_raw)
                renewal=datetime.datetime.fromisoformat(lease['spec']['renewTime'].replace('Z','+00:00')).timestamp()
                fresh=renewal>=boot_wall and 0<=time.time()-renewal<=40
                if ready and fresh and ready_at is None:ready_at=time.monotonic()
                if ready_at is not None and not ready:raise RuntimeError('NODE_LOST_READY')
                if ready_at is not None and not fresh:raise RuntimeError('NODE_LEASE_STALE')
                if ready_at is not None and time.monotonic()-ready_at>=60:break
                abort.wait(2)
            else:raise RuntimeError('READY_WINDOW_DEADLINE')
        if abort.is_set():raise RuntimeError(';'.join(reason))
        pods=json.loads(linux('kubectl --context=dr-search-r0 --request-timeout=3s get pods -A -o json'))
        save('pods.json',pods)
        for p in pods['items']:
            if p['metadata']['namespace']!='kube-system':raise RuntimeError('UNEXPECTED_WORKLOAD')
            if not any(c['type']=='Ready' and c['status']=='True' for c in p['status'].get('conditions',[])):raise RuntimeError('SYSTEM_POD_NOT_READY')
        result={'status':'passed','scope':'empty cluster only; no workload capacity claim','elapsed':time.monotonic()-started}
    except Exception as e:result['error']=str(e)
    finally:
        # Stop main sampling but keep independent host guard until cleanup has finished.
        heartbeat[0]=None
        try:
            if touched:save('stop.json',linux('docker stop --time=10 dr-search-r0',20))
            stopped=linux('docker inspect dr-search-r0 --format {{.State.Running}}')=='false'
            save('cleanup.json',{'stopped':stopped})
            if not stopped:raise RuntimeError('CONTAINER_STILL_RUNNING')
        except Exception as e:result.update(status='failed',cleanupError=str(e))
        done.set()
        if thread:thread.join(22)
        if abort.is_set():result.update(status='failed',watchdogReasons=reason)
        save('result.json',result);print(json.dumps({'out':str(out),**result}))
    return 0 if result['status']=='passed' else 1

if __name__=='__main__':raise SystemExit(main())
