"""Bounded Recreate release experiment. Import is inert; cleanup belongs to pipeline.
Transition outage is measured, never classified as a successful request.
"""
import concurrent.futures, hashlib, http.client, json, pathlib, socket, subprocess, threading, time
from urllib.parse import urlencode, urlsplit
from deployment import render
WORK=pathlib.Path('/PUBLIC/LINUX_HOME/dr-r0-work')
HERE=pathlib.Path(__file__).resolve().parent
NODE='/PUBLIC/LINUX_HOME/.nvm/versions/node/v22.18.0/bin/node'
K=['kubectl','--context=dr-search-r0','--request-timeout=10s','-n','dr-search-r0']
LANES=('search','page','media')
def save(p,v):p.write_text(json.dumps(v,indent=2))
def digest(b):return hashlib.sha256(b).hexdigest()
def request(base,route,deadline,limit):
 u=urlsplit(base);assert u.scheme=='http' and not u.username and not u.password
 conn=http.client.HTTPConnection(u.hostname,u.port,timeout=max(.001,deadline-time.monotonic()))
 response=[None]
 def expire():
  r=response[0];sock=conn.sock or getattr(getattr(getattr(r,'fp',None),'raw',None),'_sock',None)
  if sock:
   try:sock.shutdown(socket.SHUT_RDWR)
   except OSError:pass
  conn.close()
 timer=threading.Timer(max(0,deadline-time.monotonic()),expire);timer.daemon=True;timer.start()
 try:
  conn.request('GET',u.path+route,headers={'x-cap-identity':'all'});r=conn.getresponse();response[0]=r;chunks=[];size=0
  while True:
   remaining=deadline-time.monotonic()
   if remaining<=0:raise TimeoutError('REQUEST_DEADLINE')
   # HTTPResponse may own the socket after a Connection: close header.
   sock=conn.sock or getattr(getattr(r.fp,'raw',None),'_sock',None)
   if sock:sock.settimeout(remaining)
   b=r.read1(min(65536,limit+1-size))
   if not b:break
   size+=len(b)
   if size>limit:raise AssertionError('BODY_SIZE_LIMIT')
   chunks.append(b)
  if time.monotonic()>deadline:raise TimeoutError('REQUEST_DEADLINE')
  return r.status,b''.join(chunks),{k.lower():v for k,v in r.getheaders()}
 except Exception as e:
  if time.monotonic()>=deadline and not isinstance(e,AssertionError):raise TimeoutError('REQUEST_DEADLINE') from e
  raise
 finally:timer.cancel();conn.close()
class Observe:
 def __init__(self,base,oracles,out,version,transition=False,allowed=None):
  self.base=base;self.oracles=oracles;self.out=out;self.version=version;self.transition=transition;self.allowed=set(allowed or [version]);self.lock=threading.Lock();self.stop=threading.Event();self.fatal=threading.Event();self.rows=[];self.slots=[];self.error=None;self.segment='transition' if transition else 'steady';self.started=time.monotonic()
  save(out.with_suffix('.plan.json'),{'lanes':LANES,'rateEachLane':1,'deadlineSeconds':4,'maxPending':12,'maxSeconds':900,'outageAllowedOnlyDuringTransition':True})
 def log(self,suffix,row):
  with self.lock:
   with self.out.with_suffix(suffix).open('a') as f:f.write(json.dumps(row)+'\n');f.flush()
 def set_steady(self,v):
  with self.lock:self.version=v;self.allowed={v};self.transition=False;self.segment='steady';self.steady_start=time.monotonic()
  self.log('.phases.ndjson',{'at':time.time(),'version':v,'segment':'steady'})
 def set_transition(self,allowed):
  with self.lock:self.allowed=set(allowed);self.transition=True;self.segment='transition'
  self.log('.phases.ndjson',{'at':time.time(),'version':self.version,'segment':'transition','allowed':sorted(allowed),'reason':'issuing Recreate deployment'})
 def record(self,row):
  self.log('.ndjson',row)
  with self.lock:self.rows.append(row)
  if row['outcome'] in ('invalid','missed') or (row['outcome']=='outage' and not row['transition']):self.fatal.set()
 def task(self,slot):
  row=dict(slot);o=self.oracles[row['requestedVersion']];scheduled=self.started+row['scheduled'];deadline=scheduled+4
  row['sent']=time.monotonic()-self.started
  try:
   if time.monotonic()>=deadline:raise TimeoutError('QUEUE_DEADLINE')
   if row['lane']=='search':route='/api/capi/search?'+urlencode({'q':o['query']});limit=1024**2
   elif row['lane']=='page':route='/api/capi/page?'+urlencode({'pageId':o['pageId'],'version':o['version']});limit=max(o['body']['bytes'],1024**2)
   else:route='/api/capi/media?'+urlencode({'pageId':o['media']['pageId'],'mediaId':o['media']['mediaId'],'version':o['version']});limit=max(o['media']['bytes'],1024**2)
   status,body,headers=request(self.base,route,deadline,limit);actual=headers.get('x-r0-release');row.update(status=status,pod=headers.get('x-r0-pod'),actualVersion=actual,bytes=len(body),sha256=digest(body))
   if status>=500:row.update(outcome='outage',error='HTTP_'+str(status))
   elif status==409 and row['lane']!='search' and row['transition']:
    assert json.loads(body)['error']['code']=='VERSION_MISMATCH' and actual in row['allowed'] and actual!=o['version'],'INVALID_409'
    row['outcome']='version-mismatch'
   else:
    assert status==200,'UNEXPECTED_HTTP_'+str(status);assert row['pod'],'MISSING_POD_HEADER'
    if row['lane']=='search':
     r=json.loads(body);v=r['snapshotId'];assert v in row['allowed'] and actual==v,'SEARCH_VERSION';expected=self.oracles[v]
     assert r['total']==1 and len(r['hits'])==1 and r['hits'][0]['pageId']==expected['pageId'] and r['hits'][0]['title']==expected['title'],'SEARCH_ORACLE'
     assert 'dataAsOf' in r and r['dataAsOf'] is None,'DATA_AS_OF'
    else:
     expected=o['body'] if row['lane']=='page' else o['media'];assert actual==o['version'],'CONTENT_VERSION';assert len(body)==expected['bytes'] and digest(body)==expected['sha256'],'CONTENT_ORACLE'
    row['outcome']='ok'
  except (OSError,TimeoutError,http.client.HTTPException) as e:row.update(outcome='outage',error=type(e).__name__+':'+str(e))
  except Exception as e:row.update(outcome='invalid',error=type(e).__name__+':'+str(e))
  row['completed']=time.monotonic()-self.started;row['latencyMs']=(row['completed']-row['scheduled'])*1000
  if row['latencyMs']>4000 and row['outcome']=='ok':row.update(outcome='outage',error='VALIDATION_DEADLINE')
  self.record(row)
 def loop(self):
  try:
   with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
    pending=[]
    for i in range(900):
     scheduled=self.started+i
     if self.stop.wait(max(0,scheduled-time.monotonic())):break
     for lane in LANES:
      with self.lock:slot={'i':i,'lane':lane,'scheduled':i,'scheduledEpoch':self.epoch+i,'requestedVersion':self.version,'allowed':sorted(self.allowed),'transition':self.transition,'segment':self.segment}
      self.log('.slots.ndjson',slot);self.slots.append((i,lane));still_pending=[]
      for f in pending:
       if f.done():f.result()
       else:still_pending.append(f)
      pending=still_pending
      if time.monotonic()>=scheduled+1 or len(pending)>=12:
       self.record({**slot,'outcome':'missed','error':'NO_CATCHUP_OR_ADMISSION','completed':time.monotonic()-self.started});continue
      pending.append(pool.submit(self.task,slot))
     if self.fatal.is_set():break
    else:self.error='PHASE_OBSERVER_DEADLINE';self.fatal.set()
    for future in pending:future.result()
  except Exception as e:self.error=str(e);self.fatal.set()
 def begin(self):
  self.epoch=time.time();self.thread=threading.Thread(target=self.loop,daemon=True);self.thread.start();return self
 def check(self):
  if self.fatal.is_set():raise RuntimeError('OBSERVER_FAILURE:'+str(self.error or next((r for r in self.rows if r['outcome'] in ('invalid','missed') or (r['outcome']=='outage' and not r['transition'])),'unknown')))
 def finish(self):
  self.stop.set();self.thread.join(6)
  if self.thread.is_alive():raise RuntimeError('OBSERVER_LEAK')
  keys=[(r['i'],r['lane']) for r in self.rows];complete=len(keys)==len(set(keys)) and sorted(keys)==sorted(self.slots)
  lanes={}
  for lane in LANES:
   rows=sorted((r for r in self.rows if r['lane']==lane),key=lambda r:r['scheduled']);outages=[r for r in rows if r['outcome']=='outage'];longest=0;first=last=None
   for r in rows:
    if r['outcome']=='outage':
     if first is None:first=r['scheduled']
     last=r['scheduled'];longest=max(longest,last-first+1)
    else:first=last=None
   lanes[lane]={'planned':sum(x[1]==lane for x in self.slots),'completed':len(rows),'successful':sum(r['outcome']=='ok' for r in rows),'outage':len(outages),'versionMismatch':sum(r['outcome']=='version-mismatch' for r in rows),'missed':sum(r['outcome']=='missed' for r in rows),'invalid':sum(r['outcome']=='invalid' for r in rows),'steadySamples':sum(r['segment']=='steady' for r in rows),'steadyErrors':sum(r['segment']=='steady' and r['outcome']!='ok' for r in rows),'longestConsecutiveOutageSampleSpanSeconds':longest,'firstOutageScheduled':outages[0]['scheduled'] if outages else None,'lastOutageCompleted':outages[-1]['completed'] if outages else None}
  result={'complete':complete,'error':self.error,'lanes':lanes,'outageMeaning':'sampled 1/s failed requests; not exact continuous availability duration','passed':complete and not self.fatal.is_set() and not self.error and all(v['steadySamples']>=60 and not v['steadyErrors'] for v in lanes.values())}
  save(self.out.with_suffix('.summary.json'),result)
  return result

def run(base,tag,iid,run,env,privateConfig):
 run=pathlib.Path(run);began=time.monotonic();results={'passed':False,'mode':'Recreate','scope':'synthetic release mechanism and measured interruption, not transparent availability or capacity','phases':{}};phase_started=began;observer=None
 def check():
  if time.monotonic()-began>=3000:raise RuntimeError('ACTIVE_DEADLINE_50M')
  if time.monotonic()-phase_started>=900:raise RuntimeError('PHASE_DEADLINE_15M')
  if observer:observer.check()
 def command(args,timeout=20,data=None,check_exit=True):
  check();remaining=min(timeout,3000-(time.monotonic()-began),900-(time.monotonic()-phase_started));r=subprocess.run(args,input=data,capture_output=True,text=True,env=env,timeout=remaining)
  check()
  if check_exit and r.returncode:raise RuntimeError('COMMAND_FAILED:'+r.stderr[:2000])
  return r.stdout
 def k(*args,**kwargs):return command(K+list(args),**kwargs)
 def publish(version):
  log=(run/('publisher-'+version+'.log')).open('w');args=[NODE,str(HERE/'publish.mjs'),str(WORK/'releases'/version),str(run/('publish-'+version+'.json'))]
  proc=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,env={**env,'CAP_CONFIG':str(privateConfig)})
  try:
   while proc.poll() is None:check();time.sleep(.2)
   assert proc.returncode==0,'PUBLISH_FAILED';receipt=json.loads((run/('publish-'+version+'.json')).read_text());pin=pins[version]
   assert receipt['passed'] and receipt['releaseId']==version and receipt['rows'][-1]['key']==pin['manifestKey'],'PUBLISH_MANIFEST_LAST'
  finally:
   if proc.poll() is None:proc.terminate()
   try:proc.wait(timeout=3)
   except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=3)
   log.close()
 def deploy(version):
  pin=pins[version];d=render(tag,tag,version,pin['manifestKey'],pin['manifestSha256'],local=True)['items'][4];d['spec']['strategy']={'type':'Recreate'}
  save(run/('deployment-'+version+'-'+str(time.time_ns())+'.json'),d)
  observer.set_transition(set(observer.allowed)|({version} if version!='v3' else set()))
  started=time.monotonic();k('apply','-f','-',data=json.dumps(d));return started
 def state(label):
  d=json.loads(k('get','deployment','reader','-o','json'));pods=json.loads(k('get','pods','-l','app=reader','-o','json'))
  with (run/'recreate-state.ndjson').open('a') as f:f.write(json.dumps({'at':time.time(),'label':label,'deployment':d,'pods':pods})+'\n')
  return d,pods['items']
 def capture_pod(pod,version,installed=True):
  name=pod['metadata']['name'];uid=pod['metadata']['uid'];images=[]
  statuses=pod.get('status',{}).get('initContainerStatuses',[])+pod.get('status',{}).get('containerStatuses',[])
  for status in statuses:
   reported=status.get('imageID','')
   if not reported:continue
   observed=reported.removeprefix('docker://').removeprefix('docker-pullable://')
   actual=command(['docker','exec','dr-search-r0','docker','image','inspect',observed,'--format','{{.Id}}']).strip()
   assert actual==iid,'RUNTIME_IMAGE_ID_MISMATCH';images.append({'container':status['name'],'reportedImageID':reported,'resolvedConfigID':actual})
  required={'install','reader'} if installed else {'install'}
  assert required.issubset({r['container'] for r in images}),'MISSING_RUNTIME_IMAGE_ID'
  logs=k('logs',name,'-c','install');(run/(name+'-'+uid+'-install.log')).write_text(logs);records=[]
  for line in logs.splitlines():
   try:records.append(json.loads(line))
   except ValueError:pass
  if installed:
   receipts=[r for r in records if r.get('event')=='installed'];assert len(receipts)==1,'INSTALL_RECEIPT_MISSING'
   assert receipts[0]['releaseId']==version and receipts[0]['manifestSha256']==pins[version]['manifestSha256'],'INSTALL_RECEIPT_PIN'
  else:assert any(r.get('releaseId')==version and 'ARTIFACT_HASH:search.sqlite' in str(r.get('firstError',r.get('error',''))) for r in records),'BAD_V3_FIRST_CAUSE'
  save(run/(name+'-'+uid+'-installation.json'),{'pod':name,'uid':uid,'version':version,'images':images,'installerRecords':records,'installed':installed})
 def ready(version):
  while True:
   check();d,pods=state('wait-'+version);s=d.get('status',{});healthy=s.get('observedGeneration',0)>=d['metadata']['generation'] and s.get('updatedReplicas',0)==1 and s.get('availableReplicas',0)==1 and len(pods)==1
   if healthy and all(p['metadata'].get('annotations',{}).get('r0.release')==version and not p['metadata'].get('deletionTimestamp') and any(c['type']=='Ready' and c['status']=='True' for c in p.get('status',{}).get('conditions',[])) for p in pods):
    capture_pod(pods[0],version);return
   time.sleep(1)
 def stable(version):
  observer.set_steady(version);start=time.monotonic()
  while time.monotonic()-start<60:check();time.sleep(.2)
  check()
 def query(params):
  check();s,b,h=request(base,'/api/capi/search?'+urlencode(params,doseq=True),time.monotonic()+4,1024**2);assert s==200,'QUERY_HTTP';return json.loads(b),h
 def semantic(version):
  o=oracles[version];r,h=query({'q':o['changeQuery']});assert r['snapshotId']==version and h.get('x-r0-release')==version and r['total']==o['changeTotal'] and len(r['hits'])==o['changeTotal'],'CHANGED_QUERY'
  if o['changeTotal']:assert r['hits'][0]['pageId']==o['pageId'],'CHANGED_QUERY_ID'
  for tags,total in [(o['tagChangedTags'],1),(['t2','t3'] if version=='v2' else ['t8','t9'],0)]:
   r,h=query({'q':'uniquep000002','tagId':tags});assert r['snapshotId']==version and h.get('x-r0-release')==version and r['total']==total and len(r['hits'])==total,'TAG_AND_CHANGE'
   if total:assert r['hits'][0]['pageId']=='p000002','TAG_ID'
  save(run/('semantics-'+version+'-'+str(time.time_ns())+'.json'),{'passed':True,'version':version,'changeQuery':o['changeQuery'],'tagChangedTags':o['tagChangedTags']})
 def phase(name,version,transition,allowed,action):
  nonlocal phase_started,observer
  phase_started=time.monotonic();observer=Observe(base,oracles,run/(name+'-load'),version,transition,allowed).begin();error=None
  try:action()
  except BaseException as e:error=e
  finally:
   summary=observer.finish();results['phases'][name]={'seconds':time.monotonic()-phase_started,'load':summary,'error':str(error) if error else None};observer=None;save(run/'formal-recreate-progress.json',results)
  if error:raise error
  assert summary['passed'],'PHASE_OBSERVER_GATE'
 pins={v:json.loads((WORK/'releases'/v/'pin.json').read_text()) for v in ('v1','v2')};oracles={v:json.loads((WORK/'releases'/v/'oracle.json').read_text()) for v in ('v1','v2')}
 try:
  assert env.get('KUBECONFIG'),'EXPLICIT_KUBECONFIG_REQUIRED';assert tag=='r0-reader:sha256-'+iid.removeprefix('sha256:'),'IMAGE_PIN'
  ready('v1')
  phase('P1','v1',False,{'v1'},lambda:(semantic('v1'),stable('v1')))
  def p2():
   publish('v2');start=deploy('v2');ready('v2');save(run/'v2-recreate-ready.json',{'seconds':time.monotonic()-start});semantic('v2')
   s,b,h=request(base,'/api/capi/page?'+urlencode({'pageId':oracles['v1']['pageId'],'version':'v1'}),time.monotonic()+4,1024**2)
   assert s==409 and json.loads(b)['error']['code']=='VERSION_MISMATCH' and h.get('x-r0-release')=='v2','OLD_URL_409';save(run/'old-url.json',{'status':s,'error':json.loads(b),'actualVersion':h.get('x-r0-release')});stable('v2')
  phase('P2','v1',False,{'v1'},p2)
  def p3():
   out=WORK/'releases/v3';out.mkdir(exist_ok=False);manifest=json.loads((WORK/'releases/v2/release.json').read_text());uploads=json.loads((WORK/'releases/v2/uploads.json').read_text());manifest['releaseId']='v3'
   bad=next(d for d in manifest['files'] if d['path']=='search.sqlite');assert manifest['files'][0] is bad
   # P2 already verified and published immutable V2 objects. Only the faulty
   # metadata object gets a new key; rebuilding/copying all index bytes adds no evidence.
   uploads=[next(d for d in uploads if d['key']==bad['key'])]
   bad['key']='r0/v3/artifacts/search.sqlite';uploads[0]['key']=bad['key'];actual=uploads[0]['sha256'];bad['sha256']='0'*64 if actual!='0'*64 else '1'*64
   raw=json.dumps(manifest,separators=(',',':')).encode();(out/'release.json').write_bytes(raw);pins['v3']={'releaseId':'v3','manifestKey':'r0/v3/release.json','manifestSha256':digest(raw),'manifestLocal':str(out/'release.json')};save(out/'pin.json',pins['v3']);save(out/'uploads.json',uploads)
   save(run/'bad-v3-injection.json',{'descriptorSha256':bad['sha256'],'actualUploadSha256':actual,'manifestPin':pins['v3']['manifestSha256'],'fault':'search.sqlite descriptor only; upload byte hash remains real'})
   publish('v3');start=deploy('v3');found_hash=False;found_progress=False;captured_bad=set()
   while time.monotonic()-start<180:
    check();d,pods=state('reject-v3')
    for p in pods:
     if p['metadata'].get('annotations',{}).get('r0.release')!='v3':continue
     assert not any(c['type']=='Ready' and c['status']=='True' for c in p.get('status',{}).get('conditions',[])),'BAD_V3_READY'
     logs=k('logs',p['metadata']['name'],'-c','install',check_exit=False);(run/(p['metadata']['name']+'-install.log')).write_text(logs)
     if 'ARTIFACT_HASH:search.sqlite' in logs:
      found_hash=True
      if p['metadata']['uid'] not in captured_bad:capture_pod(p,'v3',False);captured_bad.add(p['metadata']['uid'])
    found_progress=d.get('status',{}).get('observedGeneration',0)>=d['metadata']['generation'] and any(c.get('type')=='Progressing' and c.get('status')=='False' and c.get('reason')=='ProgressDeadlineExceeded' for c in d.get('status',{}).get('conditions',[]))
    if found_hash and found_progress:break
    time.sleep(2)
   elapsed=time.monotonic()-start;save(run/'bad-v3-rejection.json',{'artifactHashRejected':found_hash,'progressDeadlineExceeded':found_progress,'seconds':elapsed});assert found_hash and found_progress and elapsed<=180,'BAD_RELEASE_REJECTION_GATE'
   start=deploy('v2');ready('v2');save(run/'restore-v2.json',{'seconds':time.monotonic()-start});semantic('v2');stable('v2')
  phase('P3','v2',False,{'v2'},p3)
  def p4():
   start=deploy('v1');ready('v1');save(run/'rollback-v1.json',{'seconds':time.monotonic()-start});semantic('v1');stable('v1')
  phase('P4','v2',False,{'v2'},p4)
  results['passed']=True
 except BaseException as e:results['error']=type(e).__name__+':'+str(e)
 finally:results['elapsedSeconds']=time.monotonic()-began;save(run/'formal-recreate-result.json',results)
 if not results['passed']:raise RuntimeError('FORMAL_RECREATE_FAILED:'+results.get('error','unknown'))
 return results
