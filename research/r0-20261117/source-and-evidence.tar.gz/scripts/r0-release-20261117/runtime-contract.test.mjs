import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,writeFile,mkdir,rm,readFile} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {verifyPreloaded} from './runtime/preloaded.mjs';
const hash=b=>createHash('sha256').update(b).digest('hex');
test('fixed release validates pin, bytes and cross-artifact lineage',async()=>{
 const root=await mkdtemp(path.join(os.tmpdir(),'r0-contract-'));
 const prior=process.env.RELEASE_ID;
 try{
  const put=async(name,value)=>{const bytes=Buffer.from(typeof value==='string'?value:JSON.stringify(value));const p=path.join(root,name);await writeFile(p,bytes);return {path:p,bytes:bytes.length,sha256:hash(bytes)};};
  const metadata=await put('metadata','synthetic bytes, not a SQLite database');
  const binary=await put('reader','synthetic bytes, not an executable');
  const sourceSha256=hash('synthetic-source');
  const sourceManifest=await put('source.json',{snapshotId:'v2',sourceSha256,count:1,db:{bytes:metadata.bytes,sha256:metadata.sha256}});
  await mkdir(path.join(root,'index'));
  const im=await put('index/n1-manifest.json',{snapshotId:'v2',protocol:'n1-tantivy-v1',tantivy:'0.27.0',sourceSha256,referenceManifestSha256:sourceManifest.sha256,count:1});
  const meta=await put('index/meta.json',{});
  const g={snapshotId:'v2',metadata,binary,sourceManifest,indexDir:path.join(root,'index'),indexFiles:[im,meta].map(x=>({...x,path:path.basename(x.path)}))};
  process.env.RELEASE_ID='v2';
  assert.equal((await verifyPreloaded({g3a:g})).version,'v2');
  process.env.RELEASE_ID='v1';
  await assert.rejects(verifyPreloaded({g3a:g}),/R0_RELEASE_ID_MISMATCH/);
  process.env.RELEASE_ID='v2';
  process.env.RELEASE_ID='v3';
  await assert.rejects(verifyPreloaded({g3a:{...g,snapshotId:'v3'}}),/METADATA_SOURCE_MISMATCH/);
  process.env.RELEASE_ID='v2';
  const original=await readFile(metadata.path);
  await writeFile(metadata.path,Buffer.alloc(original.length,42));
  await assert.rejects(verifyPreloaded({g3a:g}),/ARTIFACT_HASH/);
  await writeFile(metadata.path,original);
  const other=await put('other-source.json',{snapshotId:'v1',sourceSha256,count:1,db:{bytes:metadata.bytes,sha256:metadata.sha256}});
  await assert.rejects(verifyPreloaded({g3a:{...g,sourceManifest:other}}),/METADATA_SOURCE_MISMATCH/);
  await put('index/unlisted','unexpected');
  await assert.rejects(verifyPreloaded({g3a:g}),/INDEX_UNLISTED_FILE/);
 } finally {
  if(prior===undefined)delete process.env.RELEASE_ID;else process.env.RELEASE_ID=prior;
  await rm(root,{recursive:true,force:true});
 }
});
