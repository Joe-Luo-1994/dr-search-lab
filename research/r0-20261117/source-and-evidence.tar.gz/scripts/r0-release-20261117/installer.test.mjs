import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,writeFile,readFile,access,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {install} from './installer.mjs';
const sha=b=>createHash('sha256').update(b).digest('hex');
test('installer rejects untrusted/corrupt releases before activating config',async t=>{
 const dir=await mkdtemp(path.join(tmpdir(),'r0-install-'));const prior=process.env.RELEASE_ID;
 try{
  const objects=new Map();const desc=(name,bytes)=>{const b=Buffer.from(typeof bytes==='string'?bytes:JSON.stringify(bytes));objects.set(name,b);return {key:name,bytes:b.length,sha256:sha(b)};};
  const db=desc('db','synthetic metadata bytes');const binary=Buffer.from('synthetic image binary');const binaryPath=path.join(dir,'binary');await writeFile(binaryPath,binary);
  const source=desc('source',{snapshotId:'v2',db:{bytes:db.bytes,sha256:db.sha256},sourceSha256:sha('source'),count:1});
  const im=desc('im',{snapshotId:'v2',protocol:'n1-tantivy-v1',tantivy:'0.27.0',sourceSha256:sha('source'),referenceManifestSha256:source.sha256,count:1});
  const meta=desc('meta',{});
  const manifest={format:'r0-release-v1',releaseId:'v2',nodeVersion:process.version,icuVersion:process.versions.icu,binary:{bytes:binary.length,sha256:sha(binary),path:'/must/not/override'},files:[{path:'search.sqlite',...db},{path:'source.json',...source},{path:'index/n1-manifest.json',...im},{path:'index/meta.json',...meta}],remoteObjects:[]};
  const get=async k=>objects.has(k)?new Response(objects.get(k)):new Response('',{status:404});
  async function run(name,m=manifest,expected){
   const encoded=Buffer.from(JSON.stringify(m));objects.set('release',encoded);process.env.RELEASE_ID=m.releaseId;
   const root=path.join(dir,name);const work=install({releaseId:m.releaseId,manifestKey:'release',manifestSha256:expected??sha(encoded),root,binaryPath,bootstrap:{endpoint:'http://example.invalid',secretKey:'synthetic-only'},get});
   return {root,work};
  }
  await t.test('valid pinned install publishes config after all checks',async()=>{const {root,work}=await run('ok');const receipt=await work;assert.equal(receipt.releaseId,'v2');const c=JSON.parse(await readFile(path.join(root,'config.json')));assert.equal(c.g3a.binary.path,binaryPath);assert.equal(receipt.remoteContentVerified,false);});
  await t.test('manifest digest mismatch publishes nothing',async()=>{const {root,work}=await run('bad-manifest',manifest,'0'.repeat(64));await assert.rejects(work,/MANIFEST_HASH/);await assert.rejects(access(path.join(root,'config.json')));});
  await t.test('path traversal rejected before installation',async()=>{const m=structuredClone(manifest);m.files[0].path='../escape';const {root,work}=await run('bad-path',m);await assert.rejects(work,/FILE_DESCRIPTOR/);await assert.rejects(access(path.join(root,'config.json')));});
  await t.test('bad v3 reaches hash validation, never activates',async()=>{const m=structuredClone(manifest);m.releaseId='v3';const old=objects.get('db');objects.set('db',Buffer.alloc(old.length,42));const {root,work}=await run('bad-v3',m);await assert.rejects(work,/ARTIFACT_HASH:search.sqlite/);await assert.rejects(access(path.join(root,'config.json')));objects.set('db',old);});
  await t.test('token runtime mismatch is rejected',async()=>{const m=structuredClone(manifest);m.icuVersion='wrong';const {work}=await run('bad-token',m);await assert.rejects(work,/TOKEN_RUNTIME_MISMATCH/);});
 }finally{if(prior===undefined)delete process.env.RELEASE_ID;else process.env.RELEASE_ID=prior;await rm(dir,{recursive:true,force:true});}
});
