"""Windows resource watchdog + dedicated Linux systemd pipeline unit. No unrelated shutdown."""
import argparse,datetime,ipaddress,json,pathlib,subprocess,threading,time
from environment_preflight import linux,available
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=['preflight','recreate','high-single','recreate-high'],required=True);a=ap.parse_args()
 ident=time.strftime('%Y%m%d-%H%M%S');unit='dr-r0-'+ident;native='/PUBLIC/LINUX_HOME/dr-r0-work/runs/'+ident
 out=pathlib.Path(__file__).resolve().parents[2]/'evidence/r0-release-20261117'/('integration-'+ident);out.mkdir(parents=True)
 start=time.monotonic();abort=threading.Event();done=threading.Event();heartbeat=[None];reasons=[];lock=threading.Lock();proc=None;touched=False;result={'passed':False,'nativeRun':native,'stage':a.stage}
 def save(name,obj):(out/name).write_text(json.dumps(obj,indent=2),encoding='utf8')
 def stop():
  try:linux('systemctl --user stop '+unit,20)
  finally:
   with lock:linux('docker stop --time=10 dr-search-r0',20)
 def watch():
  try:
   with (out/'host.ndjson').open('w') as f:
    while not done.is_set():
     now=time.monotonic();free=available();f.write(json.dumps({'elapsed':now-start,'available':free})+'\n');f.flush()
     if free<6*1024**3:raise RuntimeError('HOST_AVAILABLE')
     if now-start>(3600 if a.stage.startswith('recreate') else 900):raise RuntimeError('TOTAL_DEADLINE')
     if heartbeat[0] and now-heartbeat[0]>10:raise RuntimeError('METRIC_GAP')
     done.wait(2)
  except Exception as e:
   reasons.append(str(e));abort.set()
   try:stop()
   except Exception as e:save('watchdog-stop-error.json',str(e))
 thread=None
 try:
  if available()<14*1024**3:raise RuntimeError('HOST_START_GUARD')
  thread=threading.Thread(target=watch,daemon=True);thread.start()
  if linux('docker inspect dr-search-r0 --format {{.State.Running}}')!='false':raise RuntimeError('PROFILE_RUNNING')
  linux('docker update --cpus=12 --memory=12g --memory-swap=12g dr-search-r0')
  with lock:
   if abort.is_set():raise RuntimeError('ABORT_BEFORE_START')
   touched=True;boot_wall=time.time();linux('docker start dr-search-r0')
  if a.stage in ('high-single','recreate-high'):
   setting=subprocess.run(['wsl','-d','Ubuntu','-u','root','--','python3','/PUBLIC/WINDOWS_HOME/Documents/ChatGPT/Search Playground/scripts/r0-release-20261117/set_memory_high.py'],capture_output=True,text=True,timeout=10)
   save('memory-high-setting.json',{'exit':setting.returncode,'stdout':setting.stdout,'stderr':setting.stderr})
   assert setting.returncode==0,'MEMORY_HIGH_SETTING_FAILED'
   high=linux('docker exec dr-search-r0 cat /sys/fs/cgroup/memory.high')
   save('memory-high-readback.json',{'raw':high,'expected':'6442450944'})
   assert high=='6442450944','MEMORY_HIGH_READBACK:'+repr(high);save('memory-high.json',{'bytes':int(high),'scope':'dedicated cluster only; hard limit unchanged'})
  ip=linux('minikube -p dr-search-r0 ip');ipaddress.IPv4Address(ip)
  linux("docker exec dr-search-r0 sh -c 'echo "+ip+" control-plane.minikube.internal >> /etc/hosts'")
  alias=linux('docker exec dr-search-r0 getent hosts control-plane.minikube.internal');assert {s.split()[0] for s in alias.splitlines()}=={ip}
  linux('docker exec dr-search-r0 systemctl start kubelet')
  # Private kubeconfig was validated in empty preflight; never touch global current-context.
  attempts=[];until=time.monotonic()+60
  while time.monotonic()<until:
   if abort.is_set():raise RuntimeError('ABORT_DURING_BOOT')
   try:
    nodes=json.loads(linux('kubectl --context=dr-search-r0 --request-timeout=2s get nodes -o json'))
    lease=json.loads(linux('kubectl --context=dr-search-r0 --request-timeout=2s -n kube-node-lease get lease dr-search-r0 -o json'))
    renewal=datetime.datetime.fromisoformat(lease['spec']['renewTime'].replace('Z','+00:00')).timestamp()
    ready=bool(nodes['items']) and all(any(c['type']=='Ready' and c['status']=='True' for c in n['status']['conditions']) for n in nodes['items'])
    attempts.append({'elapsed':time.monotonic()-start,'ready':ready,'renewal':renewal})
    if ready and renewal>=boot_wall:break
   except Exception as e:attempts.append({'elapsed':time.monotonic()-start,'error':str(e)})
   save('bootstrap.json',attempts);time.sleep(1)
  else:raise RuntimeError('BOOT_READY_DEADLINE')
  save('bootstrap.json',attempts)
  first=linux("docker exec dr-search-r0 sh -c 'cat /sys/fs/cgroup/cpu.max; cat /sys/fs/cgroup/memory.max; cat /sys/fs/cgroup/memory.swap.max'")
  assert first.splitlines()==['1200000 100000',str(12*1024**3),'0'],'PREWORK_LIMITS'
  save('prework-limits.json',first)
  script='/PUBLIC/WINDOWS_HOME/Documents/ChatGPT/Search Playground/scripts/r0-release-20261117/pipeline.py'
  command=['wsl','-d','Ubuntu','--','systemd-run','--user','--unit='+unit,'--wait','--pipe','-p','RuntimeMaxSec='+('3000' if a.stage.startswith('recreate') else '780'),'-p','TimeoutStopSec=5','-p','KillMode=control-group','-p','MemoryMax=1G','-p','MemorySwapMax=0','-p','CPUQuota=200%','python3',script,'--run',native,'--stage',a.stage]
  with lock:
   if abort.is_set():raise RuntimeError('ABORT_BEFORE_PIPELINE')
   log=(out/'pipeline.log').open('w');proc=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
  heartbeat[0]=time.monotonic()
  with (out/'cluster.ndjson').open('w') as f:
   while proc.poll() is None:
    if abort.is_set():raise RuntimeError(';'.join(reasons))
    raw=linux("docker exec dr-search-r0 sh -c 'cat /sys/fs/cgroup/cpu.max; cat /sys/fs/cgroup/memory.max; cat /sys/fs/cgroup/memory.swap.max; cat /sys/fs/cgroup/memory.current; cat /sys/fs/cgroup/memory.swap.current; cat /sys/fs/cgroup/memory.events; cat /sys/fs/cgroup/memory.stat; cat /sys/fs/cgroup/cpu.stat; sed \"s/^/high_limit /\" /sys/fs/cgroup/memory.high; sed \"s/^/local_/\" /sys/fs/cgroup/memory.events.local; sed \"s/^/psi_/\" /sys/fs/cgroup/memory.pressure'")
    lines=raw.splitlines();assert len(lines)>=7,'MISSING_METRICS'
    assert lines[:3]==['1200000 100000',str(12*1024**3),'0'],'LIMIT_MISMATCH'
    assert int(lines[3])<10*1024**3 and int(lines[4])==0,'MEMORY_OR_SWAP_GUARD'
    events=dict(s.split(maxsplit=1) for s in lines[5:]);assert events.get('oom')=='0' and events.get('oom_kill')=='0','OOM_GUARD'
    if a.stage in ('high-single','recreate-high'):assert events.get('high_limit')=='6442450944','MEMORY_HIGH_DRIFT'
    heartbeat[0]=time.monotonic();f.write(json.dumps({'elapsed':heartbeat[0]-start,'cgroup':raw})+'\n');f.flush();done.wait(2)
  log.close();result['pipelineExit']=proc.returncode;result['passed']=proc.returncode==0
 except Exception as e:result['error']=str(e)
 finally:
  heartbeat[0]=None
  try:
   linux('systemctl --user stop '+unit,20)
  except Exception as e:save('unit-stop.json',str(e))
  try:
   state=linux('python3 "/PUBLIC/WINDOWS_HOME/Documents/ChatGPT/Search Playground/scripts/r0-release-20261117/unit_state.py" '+unit)
   save('unit-cleanup.json',json.loads(state))
  except Exception as e:result.update(passed=False,unitCleanupError=str(e))
  try:
   if touched:linux('docker stop --time=10 dr-search-r0',20)
   stopped=linux('docker inspect dr-search-r0 --format {{.State.Running}}')=='false';save('cleanup.json',{'clusterStopped':stopped});assert stopped
  except Exception as e:result.update(passed=False,cleanupError=str(e))
  done.set()
  if thread:thread.join(45)
  if abort.is_set():result.update(passed=False,watchdog=reasons)
  # Native receipts contain no bootstrap config; private secrets stay under WORK/private.
  try:
   windows='/mnt/'+str(out.resolve()).replace('\\','/')[0].lower()+str(out.resolve()).replace('\\','/')[2:]
   linux("cp -r '"+native+"' '"+windows+"/native'",20)
  except Exception as e:result['collectionError']=str(e)
  save('result.json',result);print(json.dumps({'out':str(out),**result}))
 return 0 if result['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
