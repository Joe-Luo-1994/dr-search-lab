import {createHash} from 'node:crypto';
import {createReadStream} from 'node:fs';
import {lstat,readFile,realpath,readdir} from 'node:fs/promises';
import path from 'node:path';
async function verify(file,descriptor){
 if(!Number.isSafeInteger(descriptor?.bytes)||descriptor.bytes<0||!/^[a-f0-9]{64}$/.test(descriptor.sha256??''))throw Error('ARTIFACT_DESCRIPTOR');
 const s=await lstat(file);if(!s.isFile()||s.isSymbolicLink()||s.size!==descriptor.bytes)throw Error('ARTIFACT_SIZE_OR_TYPE');
 const h=createHash('sha256');for await(const chunk of createReadStream(file))h.update(chunk);
 if(h.digest('hex')!==descriptor.sha256)throw Error('ARTIFACT_HASH');
}
export async function verifyPreloaded(c){
 if(c.g3a?.engine==='S1')return verifySqlitePreloaded(c);
 const g=c.g3a;if(!g||!['v1','v2','v3'].includes(g.snapshotId)||g.snapshotId!==process.env.RELEASE_ID)throw Error('R0_RELEASE_ID_MISMATCH');
 const began=performance.now();let totalBytes=0;
 for(const descriptor of [g.metadata,g.sourceManifest,g.binary]){await verify(descriptor.path,descriptor);totalBytes+=descriptor.bytes;}
 const source=JSON.parse(await readFile(g.sourceManifest.path,'utf8'));
 if(source.snapshotId!==g.snapshotId||source.db.sha256!==g.metadata.sha256||source.db.bytes!==g.metadata.bytes)throw Error('METADATA_SOURCE_MISMATCH');
 const root=await realpath(g.indexDir);const seen=new Set();
 for(const file of g.indexFiles??[]){
  if(typeof file.path!=='string'||!file.path||path.isAbsolute(file.path)||/[\\/]/.test(file.path)||file.path==='..'||file.path==='.'||seen.has(file.path))throw Error('INDEX_PATH');
  seen.add(file.path);const target=path.join(root,file.path),resolved=await realpath(target);
  if(!resolved.startsWith(root+path.sep))throw Error('INDEX_PATH_ESCAPE');
  await verify(target,file);totalBytes+=file.bytes;
 }
 if(!seen.has('meta.json')||!seen.has('n1-manifest.json'))throw Error('INDEX_MANIFEST_MISSING');
 const actual=await readdir(root);if(actual.length!==seen.size||actual.some(name=>!seen.has(name)))throw Error('INDEX_UNLISTED_FILE');
 const manifest=JSON.parse(await readFile(path.join(root,'n1-manifest.json'),'utf8'));
 if(manifest.snapshotId!==g.snapshotId||manifest.protocol!=='n1-tantivy-v1'||manifest.tantivy!=='0.27.0'||manifest.sourceSha256!==source.sourceSha256||manifest.referenceManifestSha256!==g.sourceManifest.sha256||manifest.count!==source.count)throw Error('RELEASE_LINEAGE_MISMATCH');
 return {metadata:g.metadata.path,binary:g.binary.path,indexDir:root,version:g.snapshotId,count:source.count,
  receipt:{mode:'preloaded-no-update',verifiedBytes:totalBytes,verifyMs:performance.now()-began,sourceSha256:source.sourceSha256,metadataSha256:g.metadata.sha256,indexFiles:seen.size}};
}

async function verifySqlitePreloaded(c){
 const g=c.g3a;if(g.snapshotId!=='v1')throw Error('G3A_V1_ONLY');
 const began=performance.now();
 for(const d of [g.metadata,g.sourceManifest])await verify(d.path,d);
 const source=JSON.parse(await readFile(g.sourceManifest.path,'utf8'));
 if(source.snapshotId!==g.snapshotId||source.db.sha256!==g.metadata.sha256||source.db.bytes!==g.metadata.bytes)throw Error('METADATA_SOURCE_MISMATCH');
 return {engine:'S1',metadata:g.metadata.path,version:g.snapshotId,count:source.count,
 receipt:{mode:'preloaded-no-update',engine:'S1',verifiedBytes:g.metadata.bytes+g.sourceManifest.bytes,verifyMs:performance.now()-began,sourceSha256:source.sourceSha256,metadataSha256:g.metadata.sha256}};
}
