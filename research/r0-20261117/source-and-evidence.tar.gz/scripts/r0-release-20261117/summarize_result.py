"""Read-only result reduction; raw records remain authoritative."""
import collections,json,pathlib,sys
p=pathlib.Path(sys.argv[1]);native=p/'native'
read=lambda name:json.loads((native/name).read_text())
rows=lambda name:[json.loads(x) for x in (p/name).read_text().splitlines()]
host=rows('host.ndjson');cluster=rows('cluster.ndjson');stats=[dict(line.split(maxsplit=1) for line in r['cgroup'].splitlines()[5:]) for r in cluster]
r={'controller':json.loads((p/'result.json').read_text()),'pipeline':read('result.json'),'startup':read('startup.json'),'phases':{},'installations':[],'resources':{'hostMinGiB':min(x['available'] for x in host)/2**30,'clusterMaxSampleGiB':max(int(x['cgroup'].splitlines()[3]) for x in cluster)/2**30,'highEventsMax':max(int(x.get('local_high',0)) for x in stats),'outerMaxEventsMax':max(int(x.get('local_max',0)) for x in stats),'hierarchicalMaxEventsMax':max(int(x['max']) for x in stats),'oomMax':max(int(x['oom']) for x in stats),'lastPSIsome':stats[-1].get('psi_some'),'lastPSIfull':stats[-1].get('psi_full')},'cleanup':json.loads((p/'cleanup.json').read_text()),'unitCleanup':json.loads((p/'unit-cleanup.json').read_text())}
for phase in ('P1','P2','P3','P4'):
 f=native/(phase+'-load.summary.json')
 if not f.exists():continue
 summary=json.loads(f.read_text());actual=[json.loads(x) for x in (native/(phase+'-load.ndjson')).read_text().splitlines()];slots=[json.loads(x) for x in (native/(phase+'-load.slots.ndjson')).read_text().splitlines()]
 keys=lambda values:sorted((x['i'],x['lane']) for x in values)
 assert keys(actual)==keys(slots) and len(set(keys(actual)))==len(actual),'DENOMINATOR'
 r['phases'][phase]={'summary':summary,'outcomes':dict(collections.Counter(x['outcome'] for x in actual)),'scheduled':len(slots)}
for f in native.glob('*-installation.json'):
 data=json.loads(f.read_text());data['file']=f.name
 for receipt in data['installerRecords']:
  if receipt.get('event')=='installed':r['installations'].append({'version':data['version'],'pod':data['pod'],'uid':data['uid'],'installedBytes':receipt['installedBytes'],'installMs':receipt['elapsedMs'],'manifestSha256':receipt['manifestSha256']})
for name in ('v2-recreate-ready.json','bad-v3-rejection.json','restore-v2.json','rollback-v1.json'):
 if (native/name).exists():r[name]=read(name)
(p/'review-summary.json').write_text(json.dumps(r,indent=2));print(json.dumps({'output':str(p/'review-summary.json'),'phases':r['phases'],'resources':r['resources'],'installations':r['installations']},indent=2))
