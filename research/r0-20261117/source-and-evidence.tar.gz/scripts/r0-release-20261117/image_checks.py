import json,pathlib,subprocess
out=pathlib.Path('/PUBLIC/LINUX_HOME/dr-r0-work/image-checks.json')
prefix=['docker','run','--rm','--network=none','--memory=256m','--memory-swap=256m','--cpus=1','r0-reader:build']
commands=[['node','-p','JSON.stringify(process.versions)'],['/app/bin/n1-tantivy-reader'],['/app/bin/minio','--version'],['node','-p',"require.resolve('next')"]]
rows=[]
for command in commands:
 r=subprocess.run(prefix+command,capture_output=True,text=True,timeout=20);rows.append({'command':command,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
out.write_text(json.dumps(rows,indent=2));print(json.dumps(rows))
assert all(x['exit']==0 for i,x in enumerate(rows) if i!=1)
assert 'Usage' in rows[1]['stderr'] or 'usage' in rows[1]['stderr']
