from pathlib import Path
import subprocess,json,time,shutil,hashlib
BASE=Path('/PUBLIC/WORKSPACE')
OUT=BASE/'evidence/h2-snippet-20261117/attempt1';OUT.mkdir(parents=True,exist_ok=False)
WORK=Path('/PUBLIC/HOME/dr-h2-snippet-20261117');WORK.mkdir(exist_ok=False)
OLD=Path('/PUBLIC/HOME/dr-search-lab-e1-20261115/repo/.lab')
binary=OLD/'n1-native-20261117/tantivy-build-attempt2/target/release/n1-tantivy-reader'
db=OLD/'c-million-20261116/fixture-1000000/v1/search.sqlite'
node='/PUBLIC/HOME/.nvm/versions/node/v22.18.0/bin/node'
ps='/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
def available():return int(subprocess.check_output([ps,'-NoProfile','-Command','[long](Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory * 1024'],text=True,timeout=10).strip())
def save(name,x):(OUT/name).write_text(json.dumps(x,indent=2),encoding='utf8')
free=available();save('preflight.json',{'windowsAvailable':free,'diskFree':shutil.disk_usage(WORK).free,'binarySha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'frozenDbStat':{'size':db.stat().st_size,'mtimeNs':db.stat().st_mtime_ns},'sourceHashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (BASE/'scripts/h2-snippet-20261117').iterdir() if p.is_file()}})
if free<8*1024**3:raise RuntimeError('HOST_PREFLIGHT')
unit='dr-h2-spike-20261117'
cmd=['systemd-run','--user','--wait','--pipe','--unit='+unit,'-p','CPUQuota=100%','-p','MemoryMax=512M','-p','MemorySwapMax=0','-p','TasksMax=128','-p','RuntimeMaxSec=180',node,str(BASE/'scripts/h2-snippet-20261117/spike.mjs'),str(BASE),str(OUT),str(WORK),str(binary),str(db)]
start=time.monotonic();samples=[];stop=None;last=0
with (OUT/'stdout.log').open('w') as stdout,(OUT/'stderr.log').open('w') as stderr:
 p=subprocess.Popen(cmd,stdout=stdout,stderr=stderr)
 try:
  while p.poll() is None:
   now=time.monotonic()
   if now-last>5:free=available();last=now
   s={'seconds':now-start,'windowsAvailable':free};cg=subprocess.run(['systemctl','--user','show',unit,'--property=ControlGroup','--value'],capture_output=True,text=True).stdout.strip()
   if cg:
    for k in ['memory.current','memory.peak','memory.events','memory.swap.current','cpu.stat']:
     try:s[k]=Path('/sys/fs/cgroup'+cg+'/'+k).read_text()
     except FileNotFoundError:pass
   samples.append(s)
   if free<6*1024**3:stop='HOST_AVAILABLE';break
   if now-start>195:stop='DEADLINE';break
   time.sleep(.5)
 finally:
  if p.poll() is None:subprocess.run(['systemctl','--user','stop',unit],capture_output=True)
  p.wait(timeout=20)
state=subprocess.run(['systemctl','--user','show',unit,'--property=ActiveState,MainPID,SubState'],capture_output=True,text=True).stdout
save('resources.json',samples);save('execution.json',{'exitCode':p.returncode,'stop':stop,'seconds':time.monotonic()-start,'unit':state,'frozenDbStatAfter':{'size':db.stat().st_size,'mtimeNs':db.stat().st_mtime_ns},'scope':'synthetic isolated correctness and incremental cost, not product integration'})
print(json.dumps({'code':p.returncode,'stop':stop,'unit':state}));raise SystemExit(p.returncode or bool(stop))
