// Research-only; no product import. Match N1 normalization including mixed-script edge behavior.
const words=new Intl.Segmenter('zh-Hant',{granularity:'word'});
const graphemes=new Intl.Segmenter('zh-Hant',{granularity:'grapheme'});
export function mappedTokens(source){
 let normalized='',map=[],last=0;
 const append=(str,start)=>{normalized+=str;for(let j=0;j<str.length;j++)map.push(start+j);};
 for(const run of source.matchAll(/\p{Script=Han}+/gu)){
  append(source.slice(last,run.index),last);let first=true;
  for(const seg of words.segment(run[0])){if(!first){normalized+=' ';map.push(null);}first=false;append(seg.segment,run.index+seg.index);}
  last=run.index+run[0].length;
 }
 append(source.slice(last),last);
 const tokens=[...normalized.matchAll(/[\p{L}\p{N}\p{M}]+/gu)].map(m=>({term:m[0].toLowerCase(),start:map[m.index],end:map[m.index+m[0].length-1]+1}));
 for(const t of tokens)if(source.slice(t.start,t.end).toLowerCase()!==t.term)throw Error('UNMAPPABLE');
 return {normalized,tokens};
}
export function contextual(source,terms){
 const {tokens}=mappedTokens(source),wanted=new Set(terms),matches=tokens.filter(t=>wanted.has(t.term));
 if(!matches.length)return null;
 const boundaries=[...graphemes.segment(source)].map(s=>s.index);boundaries.push(source.length);
 const first=matches[0];let anchor=boundaries.findIndex((x,i)=>x<=first.start && boundaries[i+1]>first.start);
 let begin=Math.max(0,anchor-40),end=Math.min(boundaries.length-1,begin+160);begin=Math.max(0,end-160);
 const start=boundaries[begin],stop=boundaries[end];
 // Never split a token and falsely suggest a partial match; unusually long tokens fall back.
 if(first.end>stop)return null;
 const text=source.slice(start,stop),ranges=matches.filter(t=>t.start>=start&&t.end<=stop).map(t=>({start:t.start-start,end:t.end-start}));
 return {text,ranges,unit:'utf16',sourceStart:start,sourceEnd:stop,truncatedBefore:start>0,truncatedAfter:stop<source.length};
}
export const limits={perSource:65536,perBatch:262144,top:10};
export function decorate(db,hits,terms,ctx){
 const metrics={metadataAuthMs:0,sourceMs:0,snippetMs:0,sourceReads:0,sourceBytes:0},out=[];
 const meta=db.prepare('SELECT pageId,spaceId,mediaId FROM pages WHERE pageId=?');
 const size=db.prepare('SELECT length(CAST(content AS BLOB)) AS bytes FROM pages WHERE pageId=?');
 const source=db.prepare('SELECT content FROM pages WHERE pageId=?');
 for(const h of hits.slice(0,limits.top)){
  const started=performance.now();let preview=null,reason=null;const p=meta.get(h.pageId);
  if(ctx.indexVersion!==ctx.sourceVersion)reason='VERSION_MISMATCH';
  else if(!p || !ctx.allow(p))reason='DENIED_OR_UNKNOWN';
  else if(p.mediaId&&!ctx.member(p))reason='MEDIA_MEMBERSHIP';
  metrics.metadataAuthMs+=performance.now()-started;
  if(reason){out.push({...h,preview:null,previewReason:reason});continue;}
  const fallback=why=>({...h,preview:{text:h.snippet,ranges:[],unit:'utf16'},previewReason:why});
  const began=performance.now();
  const n=size.get(h.pageId)?.bytes;
  if(n===null||n===undefined){metrics.sourceMs+=performance.now()-began;out.push(fallback('SOURCE_MISSING'));continue;}
  if(n>limits.perSource||metrics.sourceBytes+n>limits.perBatch){metrics.sourceMs+=performance.now()-began;out.push(fallback('SOURCE_LIMIT'));continue;}
  let text;try{text=source.get(h.pageId)?.content;}catch{metrics.sourceMs+=performance.now()-began;out.push(fallback('SOURCE_UNAVAILABLE'));continue;}
  metrics.sourceReads++;metrics.sourceBytes+=n;metrics.sourceMs+=performance.now()-began;
  if(typeof text!=='string'){out.push(fallback('SOURCE_MISSING'));continue;}
  const t=performance.now();try{preview=contextual(text,terms);}catch{reason='UNMAPPABLE';}metrics.snippetMs+=performance.now()-t;
  out.push(preview?{...h,preview,previewReason:'MATCH'}:fallback(reason??'NO_MAPPABLE_MATCH'));
 }
 return {hits:out,metrics};
}
