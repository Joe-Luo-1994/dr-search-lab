from pathlib import Path
import json,math,html
ROOT=Path(__file__).resolve().parents[2]; E=ROOT/'evidence/h2-snippet-20261117/attempt2'
read=lambda p:json.loads((E/p).read_text(encoding='utf8'))
r=read('correctness.json');assert r['passed'];assert len(r['results'])==34
rows=[json.loads(l) for l in (E/'cost.ndjson').read_text().splitlines()];assert len(rows)==150
assert len({(x['profile'],x['block'],x['iteration']) for x in rows})==150
stats=[]
for profile in sorted({x['profile'] for x in rows}):
 for block in range(3):
  group=[x for x in rows if x['profile']==profile and x['block']==block and not x['warm']];assert len(group)==20
  s={'profile':profile,'block':block,'n':20,'reasons':sorted(set(y for x in group for y in x['reasons'])),'sourceBytes':sorted(set(x['sourceBytes'] for x in group))}
  for key in ['totalMs','metadataAuthMs','sourceMs','snippetMs','formatMs']:
   a=sorted(x[key] for x in group);s[key]={'p50':a[9],'p95':a[18],'max':a[-1]}
  stats.append(s)
pre=read('preflight.json');post=read('execution.json');assert pre['frozenDbStat']==post['frozenDbStatAfter'];assert post['exitCode']==0 and post['stop'] is None;assert 'MainPID=0' in post['unit']
summary={'correctnessChecks':34,'h1FailedCasesNowPassed':['zh-word','zh-title','zh-mixed','combining'],'lateMatches':[{ 'id':x['id'],'sourceStart':x['output']['hits'][0]['preview']['sourceStart']} for x in r['results'] if '5000' in x['id']], 'attempt1':'original assertion pass invalidated by self-review: retained prefix on trust failure; preserved, corrected in attempt2','cost':stats,'formalBatches':120,'warmBatches':30,'frozenDbSizeMtimeUnchanged':True,'scope':'isolated synthetic source-offset spike; not runtime feature/API/ReBAC/RPS proof'}
(E/'analysis.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
doc=['# H2 實際結果卡片對照','','僅搜尋結果卡片，非文件／PDF viewer。全部為合成資料。標粗由文字與UTF16 ranges安全escape後產生，非任意innerHTML。原文／期待值見fixture；attempt1安全缺口與原碼保留。','']
for x in r['results']:
 doc+=['## '+x['id'],'','結果：PASS（attempt2）','']
 if 'output' not in x:doc+=['```json',json.dumps(x,ensure_ascii=False),'```',''];continue
 if not x['output']['hits']:doc+=['無結果／已抑制，不輸出原prefix。',''];continue
 for h in x['output']['hits']:
  for label,p in [('正文',h.get('preview')),('標題',x.get('title'))]:
   if not p:continue
   # JS UTF16 offsets to Python strings using UTF16 encoded slices.
   text=p['text'];b=text.encode('utf-16-le');parts=[];pos=0
   for ran in p['ranges']:
    a,z=ran['start']*2,ran['end']*2;parts += [html.escape(b[pos:a].decode('utf-16-le')),'<b>'+html.escape(b[a:z].decode('utf-16-le'))+'</b>'];pos=z
   parts.append(html.escape(b[pos:].decode('utf-16-le')))
   doc += ['**'+label+'**：原文起點 '+str(p.get('sourceStart','fallback'))+'（UTF16）；'+str(h.get('previewReason','')),'','> '+''.join(parts).replace('\n','<br>'),'']
(E/'CASES.md').write_text('\n'.join(doc),encoding='utf8')
print(json.dumps({k:v for k,v in summary.items() if k!='cost'},ensure_ascii=False))
for p in sorted({x['profile'] for x in stats}):
 print(p)
 for k in ['totalMs','metadataAuthMs','sourceMs','snippetMs','formatMs']:
  vals=[x[k]['p95'] for x in stats if x['profile']==p];print(k,min(vals),max(vals))
 print('reasons',[x['reasons'] for x in stats if x['profile']==p])
