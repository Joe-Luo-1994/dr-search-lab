import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {DatabaseSync} from 'node:sqlite';
import {spawn,spawnSync} from 'node:child_process';
import {createInterface} from 'node:readline';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {normalize} from '../n1-native-20261117/sqlite/adapter.mjs';
import {mappedTokens,contextual,decorate,limits} from './adapter.mjs';
const [root,out,work,binary,oldDb]=process.argv.slice(2);await mkdir(work,{recursive:true});
const h1=JSON.parse(await readFile(root+'/evidence/h1-highlight-20261117/fixture.json','utf8'));
const tokens=s=>(normalize(s).match(/[\p{L}\p{N}\p{M}]+/gu)??[]).map(x=>x.toLowerCase());
const cases=structuredClone(h1.cases);
function add(id,body,q,expect,extra={}){cases.push({id,title:'Guide',body,q,denied:false,expected:{hit:true,titleTerms:[],bodyTerms:expect},...extra});}
add('zh-5000','一般說明。'.repeat(1000)+' 此處提供備份操作。','備份',['備份']);
add('en-5000','ordinary text. '.repeat(400)+' backup instructions.','backup',['backup']);
add('unicode-5000','😀一般說明。'.repeat(800)+' cafe\u0301 backup 指南。','cafe\u0301 backup',['cafe\u0301','backup']);
add('distant-and','backup first. '+'ordinary text. '.repeat(400)+' recovery last.','backup recovery',['backup'],{distant:true});
add('mixed-edge','使用MinIO保存 備份資料。','使用MinIO保存',['使用minio保存']);
add('oversize','ordinary '.repeat(8000)+' backup','backup',[],{fallback:'SOURCE_LIMIT'});
add('source-missing','backup content','backup',[],{fallback:'SOURCE_MISSING'});
add('version-mismatch','backup content','backup',[],{fallback:'VERSION_MISMATCH',suppress:true});
add('media-mismatch','backup content','backup',[],{fallback:'MEDIA_MEMBERSHIP',suppress:true});
const db=new DatabaseSync(work+'/fixture.sqlite');db.exec('CREATE TABLE pages(pageId TEXT PRIMARY KEY,spaceId TEXT,title TEXT,content TEXT,mediaId TEXT)');
let pages=cases.map((c,i)=>({pageId:c.id,spaceId:c.id,title:c.title,content:c.body,tags:[],mediaId:c.id==='media-mismatch'?'m-test':null}));
pages.push(...[{pageId:'rank1',title:'backup backup',content:'procedure'},{pageId:'rank2',title:'Guide',content:'backup procedure'},{pageId:'rank3',title:'Guide',content:'backup procedure'}].map(p=>({...p,spaceId:'ranking',tags:[],mediaId:null})));
pages.push(...Array.from({length:10},(_,i)=>({pageId:'cost'+String(i).padStart(2,'0'),spaceId:'cost',title:'Guide',content:cases.find(c=>c.id==='zh-5000').body,tags:[],mediaId:null})));
const sorted=pages.map(p=>p.pageId).sort();const manifest={kind:'manifest',protocol:'n1-tantivy-v1',tantivy:'0.27.0',snapshotId:'h2-v1',dataAsOf:'synthetic',count:pages.length};
for(const p of pages)db.prepare('INSERT INTO pages VALUES(?,?,?,?,?)').run(p.pageId,p.spaceId,p.title,p.pageId==='source-missing'?null:p.content,p.mediaId);
const records=pages.map(p=>({kind:'page',page:p,lexRank:sorted.indexOf(p.pageId),titleTokens:tokens(p.title),bodyTokens:tokens(p.content)}));
await writeFile(work+'/input.jsonl',[manifest,...records].map(x=>JSON.stringify(x)).join('\n')+'\n');
await writeFile(out+'/fixture.json',JSON.stringify({node:process.version,icu:process.versions.icu,manifest,cases},null,2));
const built=spawnSync(binary,['build',work+'/index',work+'/input.jsonl'],{encoding:'utf8',timeout:30000});await writeFile(out+'/build.json',JSON.stringify({status:built.status,stdout:built.stdout,stderr:built.stderr},null,2));assert.equal(built.status,0);
const child=spawn(binary,['serve',work+'/index']);let pending;const lines=createInterface({input:child.stdout});let readyResolve;const ready=new Promise(r=>readyResolve=r);let stderr='';child.stderr.on('data',b=>stderr+=b);lines.on('line',l=>{const v=JSON.parse(l);if(v.ready)readyResolve(v);else{pending?.(v);pending=null;}});
const exited=new Promise(r=>child.on('close',(code,signal)=>r({code,signal})));let seq=0;
async function search(q,space,identity='all'){const p=new Promise(r=>pending=r);child.stdin.write(JSON.stringify({id:++seq,input:{q,spaceId:space,tags:[],identity,contract:'E'},tokens:tokens(q)})+'\n');return p;}
const guard=setTimeout(()=>child.kill('SIGKILL'),90000);
const results=[];let failure=null;
try{
 await ready;
 for(const c of cases){
  for(const text of [c.title,c.body,c.q]){const m=mappedTokens(text);assert.equal(m.normalized,normalize(text));assert.deepEqual(m.tokens.map(t=>t.term),tokens(text));}
  const r=await search(c.q,c.id,c.denied?'none':'all');assert.equal(r.error,undefined);assert.equal(r.value.total,c.expected.hit?1:0,c.id+' membership');
  const original=JSON.stringify(r.value);const ctx={indexVersion:'h2-v1',sourceVersion:c.id==='version-mismatch'?'wrong':'h2-v1',allow:p=>!c.denied&&p.spaceId===c.id,member:p=>p.mediaId!=='m-test'};
  const d=decorate(db,r.value.hits,tokens(c.q),ctx);assert.equal(JSON.stringify(r.value),original,'retrieval mutated');
  if(c.suppress){assert.deepEqual(d.hits,[]);assert.equal(d.metrics.sourceReads,0);assert.equal(d.metrics.omitted,1);}
  else assert.deepEqual(d.hits.map(x=>x.pageId),r.value.hits.map(x=>x.pageId));
  let title=null;
  if(c.expected.hit&&!c.suppress){const h=d.hits[0];
   if(c.fallback){assert.equal(h.previewReason,c.fallback,c.id);if(c.suppress)assert.equal(h.preview,null);else{assert.deepEqual(h.preview.ranges,[]);assert.equal(h.preview.text,r.value.hits[0].snippet);}}
   else{
    title=contextual(c.title,tokens(c.q));
    for(const [field,preview]of [['body',h.preview],['title',title]]){
     const expected=c.expected[field+'Terms'];const text=c[field];let marked=[];
     if(preview?.sourceStart!==undefined){assert.equal(preview.text,text.slice(preview.sourceStart,preview.sourceEnd));assert.ok([...new Intl.Segmenter('zh-Hant',{granularity:'grapheme'}).segment(preview.text)].length<=160);
      for(const range of preview.ranges){const hit=preview.text.slice(range.start,range.end);const a=Buffer.byteLength(preview.text.slice(0,range.start)),b=Buffer.byteLength(preview.text.slice(0,range.end));assert.equal(new TextDecoder('utf8',{fatal:true}).decode(Buffer.from(preview.text).subarray(a,b)),hit);assert.ok(tokens(c.q).includes(hit.toLowerCase()));marked.push(hit.toLowerCase());}
     }
     for(const term of expected)assert.ok(marked.includes(term.toLowerCase()),c.id+' '+field+' missing '+term);
     if(!expected.length)assert.equal(marked.length,0);
    }
    if(c.id.includes('5000'))assert.ok(h.preview.sourceStart>4500,c.id+' not contextual');
   }
  }
  results.push({id:c.id,passed:true,total:r.value.total,queryTokens:tokens(c.q),output:d,title});
 }
 const rank=await search('backup','ranking');assert.equal(rank.value.total,3);assert.deepEqual(rank.value.hits.map(h=>h.pageId),['rank1','rank2','rank3']);const before=JSON.stringify(rank.value);const ranked=decorate(db,rank.value.hits,['backup'],{indexVersion:'h2-v1',sourceVersion:'h2-v1',allow:()=>true,member:()=>true});assert.equal(JSON.stringify(rank.value),before);assert.deepEqual(ranked.hits.map(h=>h.pageId),rank.value.hits.map(h=>h.pageId));
 results.push({id:'ranking-total-tie',passed:true,ids:rank.value.hits.map(h=>h.pageId),scores:rank.value.diagnostic.nativeScores});
 // Trust-boundary tests must prevent source reads even for a malicious/stale hit list.
 for(const [name,ctx] of [['denied',{allow:()=>false}],['unknown',{allow:()=>undefined}],['version',{sourceVersion:'wrong'}],['media',{member:()=>false}]]){
  const hit={pageId:'media-mismatch',title:'SECRET',snippet:'SECRET backup'};const d=decorate(db,[hit],['backup'],{indexVersion:'h2-v1',sourceVersion:'h2-v1',allow:()=>true,member:()=>true,...ctx});assert.equal(d.metrics.sourceReads,0);assert.deepEqual(d.hits,[]);assert.equal(JSON.stringify(d).includes('SECRET'),false);results.push({id:'boundary-'+name,passed:true,sourceReads:0});
 }
 await writeFile(out+'/correctness.json',JSON.stringify({passed:true,results},null,2));
 // Small cost check only after all correctness assertions. Existing database is READ ONLY.
 const real=new DatabaseSync(oldDb,{readOnly:true});real.exec('PRAGMA query_only=ON; PRAGMA cache_size=-8192; PRAGMA mmap_size=0;');
 const version=real.prepare('SELECT snapshotId FROM metadata').get().snapshotId;
 const sampled=real.prepare('SELECT pageId,spaceId,title,substr(content,1,160) snippet,length(CAST(content AS BLOB)) bytes,bodyKey,mediaId FROM pages LIMIT 10').all();
 const audit={schema:real.prepare('PRAGMA table_info(pages)').all(),snapshotId:version,sampleCount:sampled.length,rows:sampled.map(p=>({pageId:p.pageId,spaceId:p.spaceId,bytes:p.bytes,hasRemoteBody:!!p.bodyKey,hasMedia:!!p.mediaId})),pdfLineage:'unknown; synthetic source only'};await writeFile(out+'/source-audit.json',JSON.stringify(audit,null,2));
 const cost=[];
 const costHits=(await search('備份','cost')).value.hits;assert.equal(costHits.length,10);
 for(const [name,conn,hits,query,ver] of [['existing-local',real,sampled,['backup'],version],['late-local',db,costHits,['備份'],'h2-v1']]){
  for(let block=0;block<3;block++)for(let i=0;i<25;i++){
   const t=performance.now();const d=decorate(conn,hits,query,{indexVersion:ver,sourceVersion:ver,allow:()=>true,member:()=>true});const f=performance.now();const bytes=Buffer.byteLength(JSON.stringify(d.hits));const end=performance.now();cost.push({profile:name,block,iteration:i,warm:i<5,totalMs:end-t,formatMs:end-f,...d.metrics,outputBytes:bytes,reasons:d.hits.map(h=>h.previewReason)});
  }
  const values=cost.filter(x=>x.profile===name&&!x.warm).map(x=>x.totalMs).sort((a,b)=>a-b);if(values[Math.ceil(.95*values.length)-1]>100){await writeFile(out+'/cost-budget-stop.json',JSON.stringify({profile:name,p95:values[Math.ceil(.95*values.length)-1]}));break;}
 }
 real.close();await writeFile(out+'/cost.ndjson',cost.map(x=>JSON.stringify(x)).join('\n')+'\n');
}catch(e){failure={message:e.message,stack:e.stack};await writeFile(out+'/correctness.json',JSON.stringify({passed:false,results,failure},null,2));}
finally{clearTimeout(guard);child.stdin.end();const timer=setTimeout(()=>child.kill('SIGKILL'),3000);const exit=await exited;clearTimeout(timer);db.close();await writeFile(out+'/reader-exit.json',JSON.stringify({exit,stderr}));}
if(failure){console.error(failure);process.exitCode=1;}else console.log(JSON.stringify({passed:true,checks:results.length}));
