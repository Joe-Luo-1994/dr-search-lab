#!/bin/bash
set -eu
task_root=/PUBLIC/LINUX_HOME/dr-search-lab-e1-20261115/repo/.lab/n1-native-20261117
export CARGO_HOME="$task_root/toolchain/cargo"
export RUSTUP_HOME="$task_root/toolchain/rustup"
"$CARGO_HOME/bin/rustup" toolchain install 1.90.0 --profile minimal
