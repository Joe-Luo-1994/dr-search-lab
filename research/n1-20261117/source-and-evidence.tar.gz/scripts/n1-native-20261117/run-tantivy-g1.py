from pathlib import Path
import subprocess,json,time,hashlib
base=Path('/PUBLIC/WINDOWS_WORKSPACE')
run=Path('/PUBLIC/LINUX_HOME/dr-search-lab-e1-20261115/repo/.lab/n1-native-20261117')
out=base/'evidence/n1-native-20261117/tantivy-g1-attempt1';out.mkdir()
work=run/'tantivy-g1-attempt1';work.mkdir()
node='/PUBLIC/LINUX_HOME/.nvm/versions/node/v22.18.0/bin/node'
binary=run/'tantivy-build-attempt2/target/release/n1-tantivy-reader'
source=base/'scripts/n1-native-20261117/tantivy'
steps=[('export',[node,str(source/'export-golden.mjs'),str(work/'export')]),('index',[str(binary),'build',str(work/'index'),str(work/'export/source.jsonl')]),('golden',[node,str(source/'golden.mjs'),str(binary),str(work/'index'),str(work/'export/fixture.json'),str(out/'golden')])]
receipts=[]
for name,args in steps:
 unit='dr-n1-tantivy-g1-'+name+'-20261117';start=time.time()
 cmd=['systemd-run','--user','--wait','--pipe','--unit='+unit,'-p','CPUQuota=400%','-p','MemoryMax=8G','-p','MemorySwapMax=0','-p','TasksMax=128','-p','RuntimeMaxSec=120']+args
 try:r=subprocess.run(cmd,capture_output=True,text=True,timeout=150)
 except subprocess.TimeoutExpired as e:r=subprocess.CompletedProcess(cmd,124,str(e.stdout or ''),'CONTROLLER_TIMEOUT '+str(e.stderr or ''))
 finally:subprocess.run(['systemctl','--user','stop',unit],capture_output=True)
 state=subprocess.run(['systemctl','--user','show',unit,'-p','MainPID,ActiveState,Result,ExecMainStatus'],capture_output=True,text=True).stdout
 receipts.append({'step':name,'seconds':time.time()-start,'code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'finalState':state})
 (out/'controller.json').write_text(json.dumps(receipts,indent=2))
 if r.returncode:print(json.dumps({'failedStep':name,'receipt':receipts[-1]}));raise SystemExit(r.returncode)
meta=(work/'index/meta.json').read_bytes();j=json.loads(meta)
(out/'segments.json').write_text(json.dumps({'sha256':hashlib.sha256(meta).hexdigest(),'segmentCount':len(j['segments']),'segments':j['segments'],'scope':'No forced multi-segment fixture'},indent=2))
print(json.dumps({'passed':True,'steps':len(receipts),'segments':len(j['segments'])}))
