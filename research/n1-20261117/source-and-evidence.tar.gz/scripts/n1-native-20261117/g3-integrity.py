"""After service shutdown, verify prepared artifact hashes and frozen loader sources."""
import hashlib, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
NATIVE=Path('/PUBLIC/LINUX_HOME/dr-search-lab-e1-20261115/repo/.lab/n1-native-20261117/g3a')
def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
rows=[]
for name in ('sqlite-attempt3','tantivy-attempt1'):
    prepared=json.loads((NATIVE/name/'prepared.json').read_text())['artifacts']
    items=[prepared['metadata'],prepared['sourceManifest']]
    if 'binary' in prepared:items.append(prepared['binary'])
    items += [{**d,'path':str(Path(prepared['indexDir'])/d['path'])} for d in prepared.get('indexFiles',[])]
    for d in items:
        p=Path(d['path']);rows.append({'attempt':name,'file':p.name,'bytes':p.stat().st_size,
          'passed':p.stat().st_size==d['bytes'] and digest(p)==d['sha256']})
folder=ROOT/'scripts/n1-native-20261117/g3-load'
for d in json.loads((folder/'freeze.json').read_text())['files']:
    rows.append({'attempt':'loader-freeze','file':d['path'],'passed':digest(folder/d['path'])==d['sha256']})
report={'passed':all(r['passed'] for r in rows),'checks':rows,'scope':'after shutdown; hashing is outside all timing windows'}
out=ROOT/'evidence/n1-native-20261117/g3-final-integrity.json'
with out.open('x') as f:json.dump(report,f,indent=2)
print(json.dumps({'passed':report['passed'],'checks':len(rows)}))
if not report['passed']:raise SystemExit(1)
