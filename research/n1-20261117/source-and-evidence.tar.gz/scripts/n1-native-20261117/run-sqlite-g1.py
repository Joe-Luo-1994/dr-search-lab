from pathlib import Path
import subprocess,json,time
base=Path('/PUBLIC/WINDOWS_WORKSPACE')
out=base/'evidence/n1-native-20261117/sqlite-g1-attempt1'
assert not out.exists()
unit='dr-n1-sqlite-g1-20261117'
cmd=['systemd-run','--user','--wait','--pipe','--unit='+unit,'-p','CPUQuota=400%','-p','MemoryMax=8G','-p','MemorySwapMax=0','-p','TasksMax=128','-p','RuntimeMaxSec=120','/PUBLIC/LINUX_HOME/.nvm/versions/node/v22.18.0/bin/node',str(base/'scripts/n1-native-20261117/sqlite/golden.mjs'),str(out)]
started=time.time()
try:
 r=subprocess.run(cmd,capture_output=True,text=True,timeout=150)
except subprocess.TimeoutExpired as e:
 r=subprocess.CompletedProcess(cmd,124,stdout=(e.stdout or b'').decode(errors='replace') if isinstance(e.stdout,bytes) else e.stdout or '',stderr='CONTROLLER_TIMEOUT\n'+((e.stderr or b'').decode(errors='replace') if isinstance(e.stderr,bytes) else e.stderr or ''))
finally:
 subprocess.run(['systemctl','--user','stop',unit],capture_output=True)
state=subprocess.run(['systemctl','--user','show',unit,'-p','MainPID,ActiveState,Result,ExecMainStatus'],capture_output=True,text=True)
receipt={'at':started,'seconds':time.time()-started,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'finalState':state.stdout,'scope':'small G1 only'}
(base/'evidence/n1-native-20261117/sqlite-g1-controller.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt));raise SystemExit(r.returncode)
