from pathlib import Path
import os,subprocess,time,json,shutil,hashlib,sys
base=Path('/PUBLIC/WINDOWS_WORKSPACE')
run=Path('/PUBLIC/LINUX_HOME/dr-search-lab-e1-20261115/repo/.lab/n1-native-20261117')
attempt=int(sys.argv[1]) if len(sys.argv)>1 else 1
assert attempt in [1,2]
rust='1.88.0' if attempt==1 else '1.90.0'
out=base/f'evidence/n1-native-20261117/tantivy-build-attempt{attempt}';out.mkdir()
project=run/f'tantivy-build-attempt{attempt}';shutil.copytree(base/'scripts/n1-native-20261117/tantivy',project)
if attempt==2:shutil.copy2(run/'tantivy-build-attempt1/Cargo.lock',project/'Cargo.lock')
unit='dr-n1-tantivy-build-20261117';tc=run/'toolchain'
env=dict(os.environ,CARGO_HOME=str(tc/'cargo'),RUSTUP_HOME=str(tc/'rustup'),RUSTUP_TOOLCHAIN=rust,CARGO_BUILD_JOBS='4',PATH=str(tc/'cargo/bin')+':'+os.environ['PATH'])
(out/'source-freeze.json').write_text(json.dumps({str(p.relative_to(project)):hashlib.sha256(p.read_bytes()).hexdigest() for p in project.rglob('*') if p.is_file()},indent=2))
cmd=['systemd-run','--user','--wait','--pipe','--unit='+unit,'-p','CPUQuota=400%','-p','MemoryMax=8G','-p','MemorySwapMax=0','-p','TasksMax=256','-p','RuntimeMaxSec=2700','--working-directory='+str(project)]+['--setenv='+k+'='+env[k] for k in ['CARGO_HOME','RUSTUP_HOME','RUSTUP_TOOLCHAIN','CARGO_BUILD_JOBS','PATH']]+[str(tc/'cargo/bin/cargo'),'build','--release']+(['--locked'] if attempt==2 else [])
start=time.monotonic();reason=None
with (out/'stdout.log').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
 p=subprocess.Popen(cmd,env=env,stdout=stdout,stderr=stderr)
 try:
  while p.poll() is None:
   available=int(next(s.split()[1] for s in Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemAvailable:')))*1024
   used=int(subprocess.check_output(['du','-sb',str(run)]).split()[0])
   if available<1536*1024**2 or shutil.disk_usage(run).free<30*1024**3 or used>60*1024**3:reason='HOST_RESOURCE_GUARD';break
   if time.monotonic()-start>2730:reason='BUILD_DEADLINE';break
   time.sleep(5)
 finally:
  subprocess.run(['systemctl','--user','stop',unit],capture_output=True)
  try:p.wait(timeout=15)
  except subprocess.TimeoutExpired:p.kill();p.wait()
for name in ['Cargo.lock','Cargo.toml']:
 if (project/name).exists():shutil.copy2(project/name,out/name)
binary=project/'target/release/n1-tantivy-reader'
r={'passed':p.returncode==0 and binary.exists() and reason is None,'returncode':p.returncode,'stop':reason,'seconds':time.monotonic()-start,'binarySha256':hashlib.sha256(binary.read_bytes()).hexdigest() if binary.exists() else None,'limits':{'cpu':4,'memoryGiB':8,'swap':0},'rust':rust,'scope':'build only, not search validation'}
(out/'result.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
