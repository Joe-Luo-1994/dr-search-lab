from pathlib import Path
import json, subprocess, hashlib, shutil, time
root=Path('/PUBLIC/LINUX_HOME/dr-search-lab-e1-20261115/repo')
out=Path('/PUBLIC/WINDOWS_WORKSPACE/evidence/n1-native-20261117')
run=root/'.lab/n1-native-20261117'
run.mkdir(exist_ok=True);out.mkdir(exist_ok=True)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
mem=dict((x.split(':')[0],x.split(':')[1].strip()) for x in Path('/proc/meminfo').read_text().splitlines())
assert int(mem['MemAvailable'].split()[0])*1024>1536*1024**2
assert shutil.disk_usage(run).free>30*1024**3
files=[]
for v in ['v1','v2']:
 for name in ['search.sqlite','manifest.json']:
  p=root/'.lab/c-million-20261116/fixture-1000000'/v/name
  files.append({'version':v,'name':name,'bytes':p.stat().st_size,'sha256':sha(p)})
receipt={'at':time.time(),'scope':'G0 read-only inventory and input hashes; hash warms filesystem cache','memory':{k:mem[k] for k in ['MemTotal','MemAvailable','SwapTotal']},'diskFree':shutil.disk_usage(run).free,'inputs':files,'runningUserServices':subprocess.run(['systemctl','--user','list-units','--type=service','--state=running','--no-pager'],capture_output=True,text=True).stdout,'toolchain':'Rust absent at initial inventory; isolated installation planned','formalCapacity':False}
(out/'g0-preflight.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps({'passed':True,'inputs':len(files),'diskFree':receipt['diskFree']}))
