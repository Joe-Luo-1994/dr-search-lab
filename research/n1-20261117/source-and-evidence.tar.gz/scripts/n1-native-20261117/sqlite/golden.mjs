import {DatabaseSync} from 'node:sqlite';
import {mkdir,writeFile,readFile} from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
import {pages,cases,tokenCases,snapshotId,dataAsOf} from './golden-fixture.mjs';
import {normalize,queryTokens,openReader} from './adapter.mjs';

if(!process.argv[2])throw Error('Usage: node golden.mjs NEW_OUTPUT_DIRECTORY');
const out=path.resolve(process.argv[2]);await mkdir(out); // refuse overwrite
const results=[], tokenResults=[];let failure=null;
const dbPath=path.join(out,'golden.sqlite');const db=new DatabaseSync(dbPath);
db.exec(`CREATE TABLE metadata(snapshotId TEXT NOT NULL);
 CREATE TABLE pages(pageId TEXT PRIMARY KEY,spaceId TEXT NOT NULL,title TEXT NOT NULL,content TEXT NOT NULL);
 CREATE TABLE page_tags(pageId TEXT NOT NULL,tagId TEXT NOT NULL,PRIMARY KEY(pageId,tagId));
 CREATE INDEX pages_space ON pages(spaceId);CREATE INDEX tags_reverse ON page_tags(tagId,pageId);
 CREATE VIRTUAL TABLE search_index USING fts5(title,content,tokenize='unicode61');`);
db.prepare('INSERT INTO metadata VALUES (?)').run(snapshotId);
for(const p of pages){const row=db.prepare('INSERT INTO pages VALUES (?,?,?,?)').run(p.pageId,p.spaceId,p.title,p.content);
 db.prepare('INSERT INTO search_index(rowid,title,content) VALUES (?,?,?)').run(row.lastInsertRowid,normalize(p.title),normalize(p.content));
 for(const tag of p.tags)db.prepare('INSERT INTO page_tags VALUES (?,?)').run(p.pageId,tag);}
db.close();
const readers=[];const outputs=new Map();
try {
 for(const c of tokenCases){const actual=queryTokens(c.text);tokenResults.push({...c,actual});assert.deepEqual(actual,c.expected,c.text);}
 for(const variant of ['S0','S1']){
  const reader=openReader(dbPath,{variant,dataAsOf,includeScores:true});readers.push(reader);
  for(const contract of ['E','L'])for(const c of cases){
   const input={...c.input,contract};let value,error;
   try{value=reader.search(input);}catch(e){error=e.message;}
   const row={variant,contract,id:c.id,input,value,error};results.push(row);
   if(c.error){assert.equal(error,c.error,c.id);continue;}
   assert.equal(error,undefined,c.id);assert.equal(value.snapshotId,snapshotId);assert.equal(value.dataAsOf,dataAsOf);
   const ids=value.hits.map(h=>h.pageId),eligible=c.eligible??c.expected;
   assert.ok(ids.every(id=>eligible.includes(id)),c.id+' returned ineligible ID');
   if(eligible.length<=10)assert.deepEqual([...ids].sort(),[...eligible].sort(),c.id);
   assert.equal(new Set(ids).size,ids.length);
   assert.equal(ids.length,Math.min(10,eligible.length));
   if(c.expectedOrder)assert.deepEqual(ids,c.expectedOrder,'native title boost ranking');
   if(c.expectedOrderByContract?.[contract])assert.deepEqual(ids,c.expectedOrderByContract[contract],'contract tie ordering');
   if(c.expectedSqliteOrder)assert.deepEqual(ids,c.expectedSqliteOrder,'SQLite retains lexical pageId tie order');
   const scores=value.diagnostic.nativeScores.map(x=>x.score);
   assert.ok(scores.every(Number.isFinite));
   for(let i=1;i<scores.length;i++)assert.ok(scores[i-1]<=scores[i],'SQLite negative BM25 ascending');
   if(c.id==='title-boost')assert.ok(scores[0]<scores[1],'strictly better title weight');
   if(contract==='E')assert.equal(value.total,eligible.length);else assert.equal(Object.hasOwn(value,'total'),false);
   for(const hit of value.hits){const p=pages.find(p=>p.pageId===hit.pageId);assert.equal(hit.title,p.title);assert.equal(hit.spaceId,p.spaceId);
    assert.equal(hit.snippet,Array.from(p.content).slice(0,160).join(''));assert.deepEqual(hit.tagIds,[...p.tags].sort());}
   if(c.id==='same-score')assert.deepEqual(ids,['g11','g12']);
   const key=contract+':'+c.id;
   if(variant==='S0')outputs.set(key,ids);else assert.deepEqual(ids,outputs.get(key),'S0/S1 ordered parity '+key);
  }
  await writeFile(path.join(out,variant+'-eqp.json'),JSON.stringify(reader.explain({q:'orchid',identity:'a',tags:['ops','dr'],contract:'E'}),null,2));
 }
}catch(e){failure={message:e.message,stack:e.stack};}
finally{for(const r of readers)r.close();}
const hashes={};for(const name of ['adapter.mjs','golden.mjs','golden-fixture.mjs'])hashes[name]=createHash('sha256').update(await readFile(new URL(name,import.meta.url))).digest('hex');
const report={passed:!failure,scope:'G1 small hand-authored fixture only; no capacity or production quality claim',
 node:process.version,sqlite:process.versions.sqlite,icu:process.versions.icu,hashes,cases:cases.length,attempts:results.length,
 tokenResults,results,failure};
await writeFile(path.join(out,'result.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({passed:report.passed,cases:cases.length,attempts:results.length,out,failure}));
if(failure)process.exitCode=1;
