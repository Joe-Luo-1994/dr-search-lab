import {querySpecs} from '../../c-million-20261116/source.mjs';
// Independent source-rule predicates; never import the search adapter or inspect DB hits to count.
export function probes(count,version){
 const extra=[
  ['and-common','disaster recovery'],['reference-word','reference'],['title-two','knowledge page'],
  ['last-id','p'+String(count).padStart(6,'0')],['rare-wrong-space','uniquep000123',{spaceId:'space1'}],
  ['zh-space','災難復原',{spaceId:'space1'}],['zh-tags','災難復原',{tags:['t0','t1']}],
  ['long-common','disaster recovery reference'],['two-unique','uniquep000123 uniquep000124'],
  ['published-authorized','attachmentknowledge',{identity:'a'}],
  ['restricted-wrong-space','disaster',{identity:'a',spaceId:'space1'}],['v2-marker','revisiontwo']
 ].map(([id,q,opts])=>({id,q,identity:'all',tags:[],...opts}));
 return [...querySpecs(count),...extra];
}
export function descriptor(i,count,version){return {pageId:'p'+String(i).padStart(6,'0'),
 spaceId:version==='v2'&&i===1?'space1':i<=Math.floor(count/2)?'space0':'space'+(1+(i-1)%99),
 tags:version==='v2'&&i===2?['t8','t9']:['t'+i%10,'t'+(i+1)%10],
 chinese:i%5===0,published:i<=Math.min(count,256)||(version==='v2'&&i===count+1)};}
export function matches(q,i,count,version){
 const p=descriptor(i,count,version);
 if(q.identity==='none'||(q.identity==='a'&&p.spaceId!=='space0'))return false;
 if(q.spaceId&&p.spaceId!==q.spaceId)return false;
 if(q.tags.some(t=>!p.tags.includes(t)))return false;
 switch(q.id){
 case 'common':case 'space':case 'tags':case 'restricted':case 'restricted-tags':case 'and-common':case 'reference-word':case 'title-two':case 'long-common':case 'restricted-wrong-space':return true;
 case 'rare':return i===Math.min(123,count);
 case 'rare-wrong-space':return i===123;
 case 'chinese':case 'zh-space':case 'zh-tags':return p.chinese;
 case 'absent':case 'two-unique':return false;
 case 'pdf':case 'published-authorized':return p.published;
 case 'last-id':return i===count;
 case 'v2-marker':return version==='v2'&&i===3;
 default:throw Error('UNKNOWN_PROBE');
 }
}
