import {DatabaseSync} from 'node:sqlite';

const segmenter = new Intl.Segmenter('zh-Hant', {granularity: 'word'});
export const normalize = text => text.replace(/\p{Script=Han}+/gu, run => [...segmenter.segment(run)].map(x => x.segment).join(' '));
export function queryTokens(text) {
  if (typeof text !== 'string' || text.length > 4096) throw Error('INVALID_QUERY');
  const terms = normalize(text).match(/[\p{L}\p{N}\p{M}]+/gu);
  if (!terms?.length) throw Error('INVALID_QUERY');
  return terms.map(t => t.toLowerCase());
}

export function openReader(filename, {variant = 'S0', dataAsOf = null, includeScores = false} = {}) {
  if (!['S0', 'S1'].includes(variant)) throw Error('INVALID_VARIANT');
  const db = new DatabaseSync(filename, {readOnly: true});
  db.exec('PRAGMA query_only=ON; PRAGMA cache_size=-8192; PRAGMA mmap_size=0;');
  const snapshotId = db.prepare('SELECT snapshotId FROM metadata').get().snapshotId;
  const tags = db.prepare('SELECT tagId FROM page_tags WHERE pageId=? ORDER BY tagId');
  function compile(input) {
    if (!['all', 'a', 'none'].includes(input.identity)) throw Error('UNKNOWN_IDENTITY');
    if (!['E', 'L'].includes(input.contract)) throw Error('INVALID_CONTRACT');
    if (!Array.isArray(input.tags) || input.tags.length > 32 || input.tags.some(t => typeof t !== 'string')) throw Error('INVALID_TAGS');
    if (input.spaceId !== undefined && (typeof input.spaceId !== 'string' || !input.spaceId)) throw Error('INVALID_SPACE');
    const terms = queryTokens(input.q);
    const clauses = ['search_index MATCH ?'];
    const params = [terms.map(t => '"' + t + '"').join(' AND ')];
    if (input.identity === 'none') clauses.push('0');
    if (input.identity === 'a') {clauses.push('p.spaceId=?'); params.push('space0');}
    if (input.spaceId) {clauses.push('p.spaceId=?'); params.push(input.spaceId);}
    for (const tag of input.tags) {
      clauses.push('EXISTS (SELECT 1 FROM page_tags t WHERE t.pageId=p.pageId AND t.tagId=?)'); params.push(tag);
    }
    const from = ' FROM search_index JOIN pages p ON p.rowid=search_index.rowid WHERE ' + clauses.join(' AND ');
    const rankClause = variant === 'S1' ? " AND rank MATCH 'bm25(3.0,1.0)'" : '';
    const order = variant === 'S1' ? 'rank,p.pageId' : 'bm25(search_index,3.0,1.0),p.pageId';
    const score = variant === 'S1' ? 'rank' : 'bm25(search_index,3.0,1.0)';
    const sql = 'SELECT p.pageId,p.spaceId,p.title,substr(p.content,1,160) AS snippet' + (includeScores ? ',' + score + ' AS nativeScore' : '') + from + rankClause + ' ORDER BY ' + order + ' LIMIT 10';
    return {params, sql, countSql: 'SELECT count(*) AS n' + from, terms};
  }
  function search(input) {
    const q = compile(input), start = performance.now();
    // E/L differ only in exact-total work. Both retain pageId tie order.
    let total;
    if (input.contract === 'E') total = db.prepare(q.countSql).get(...q.params).n;
    const counted = performance.now();
    const hits = db.prepare(q.sql).all(...q.params);
    const nativeScores=includeScores ? hits.map(h=>({pageId:h.pageId,score:h.nativeScore})) : [];
    for(const hit of hits)delete hit.nativeScore;
    const ranked = performance.now();
    for (const hit of hits) hit.tagIds = tags.all(hit.pageId).map(x => x.tagId);
    const finished = performance.now();
    return {snapshotId, dataAsOf, ...(input.contract === 'E' ? {total} : {}), hits,
      diagnostic: {variant, contract: input.contract, tokens: q.terms, nativeScores, countMs: counted-start,
        topMs: ranked-counted, tagsMs: finished-ranked, totalMs: finished-start}};
  }
  return {search, explain: input => {const q=compile(input); return {sql:q.sql, countSql:q.countSql,
    params:q.params, rows:db.prepare('EXPLAIN QUERY PLAN '+q.sql).all(...q.params)};},
    snapshotId, close: () => db.close()};
}
