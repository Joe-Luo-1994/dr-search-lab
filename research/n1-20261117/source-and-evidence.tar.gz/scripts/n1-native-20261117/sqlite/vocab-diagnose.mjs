import {DatabaseSync} from 'node:sqlite';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {pages} from './golden-fixture.mjs';
import {normalize,queryTokens} from './adapter.mjs';
const [filename,out]=process.argv.slice(2);if(!filename||!out)throw Error('Usage: node vocab-diagnose.mjs GOLDEN_DB NEW_JSON');
const hash=async()=>createHash('sha256').update(await readFile(filename)).digest('hex');
const before=await hash(),db=new DatabaseSync(filename,{readOnly:true});
db.exec('CREATE VIRTUAL TABLE temp.vocab USING fts5vocab(main,search_index,instance)');
const segmenter=new Intl.Segmenter('zh-Hant',{granularity:'word'}),rows=[];
for(const p of pages){const id=db.prepare('SELECT rowid FROM pages WHERE pageId=?').get(p.pageId).rowid;
 for(const column of ['title','content']){const text=p[column],terms=db.prepare('SELECT term,offset FROM temp.vocab WHERE doc=? AND col=? ORDER BY offset').all(id,column);
  rows.push({pageId:p.pageId,column,text,hanSegments:[...text.matchAll(/\p{Script=Han}+/gu)].map(m=>({run:m[0],segments:[...segmenter.segment(m[0])].map(s=>({segment:s.segment,isWordLike:s.isWordLike}))})),
   normalized:normalize(text),queryTokens:queryTokens(text),actualIndex:terms,
   indexQueryTokenParity:JSON.stringify(terms.map(t=>t.term))===JSON.stringify(queryTokens(text))});
 }}
db.close();const after=await hash();
const result={scope:'Read-only diagnostic; not revised oracle or pass reclassification',node:process.version,icu:process.versions.icu,sqlite:process.versions.sqlite,before,after,unchanged:before===after,rows};
await writeFile(out,JSON.stringify(result,null,2),{flag:'wx'});
console.log(JSON.stringify({columns:rows.length,unchanged:result.unchanged,parityMismatches:rows.filter(r=>!r.indexQueryTokenParity),chinese:rows.filter(r=>r.hanSegments.length)}));
