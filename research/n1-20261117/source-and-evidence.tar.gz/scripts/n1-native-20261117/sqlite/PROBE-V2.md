# Screening v2 resource boundary

Prepared, not executed. `node probe-v2.mjs DB NEW_OUTDIR 1000000 v1`.

Parent computes and validates the independent oracle outside reader quota. It invokes a fresh `systemd-run --user --wait --pipe` unit for each S0/S1 × E/L configuration, with 4 CPU, 8 GiB, swap 0, 600-second unit runtime. Reader exchanges JSONL over stdin/stdout; no fork IPC crosses systemd. Ready handshake includes actual Node PID; parent reads back unit limits, MainPID and ControlGroup and verifies `/proc/PID/cgroup` before any query.

Each search or EQP has a parent 4-second deadline. On timeout the parent calls `systemctl --user stop UNIT` and verifies inactive/failed, MainPID 0, and original child PID absent. Cleanup time is outside the query deadline and may add up to the bounded 15-second systemctl call. Any timeout, invalid output, oracle mismatch, failed limits/membership or unverifiable cleanup stops the whole screen; no retries/escalation/formal blocks.

Same 84 queries as v1. Full source hashes and overall host/disk/runtime watchdog remain parent orchestrator responsibilities. Resource readback itself occurs before search timing. DB stat mismatch becomes a persisted failure receipt instead of throwing before writing result. Old probe and failed vocabulary receipts are preserved.

`vocab-check-v2.mjs` changes only g05 title's hand-written expected terms from 排程/維護 to 排/程/維護, with reviewer approval and a revision comment. No tokenizer, fixture or original checker changes. Run against the existing golden DB and write a new receipt; correctness of whole-text index/query tokens does not establish natural-language retrieval quality or every substring query.
