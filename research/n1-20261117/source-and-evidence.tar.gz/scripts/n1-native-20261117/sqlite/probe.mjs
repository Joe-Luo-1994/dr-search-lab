import {fork} from 'node:child_process';
import {mkdir,writeFile,stat,readFile} from 'node:fs/promises';
import {appendFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import assert from 'node:assert/strict';
import {probes,matches} from './probe-cases.mjs';
import {source} from '../../c-million-20261116/source.mjs';

const [database,output,countText='1000000',version='v1']=process.argv.slice(2),count=Number(countText);
if(!database||!output||!Number.isSafeInteger(count)||count<123||count>1000000||!['v1','v2'].includes(version))throw Error('Usage: node probe.mjs DB NEW_OUTDIR [COUNT=1000000] [v1|v2]');
const out=path.resolve(output);await mkdir(out);const initial=await stat(database),cases=probes(count,version),records=[],plans=[];
const log=event=>{records.push(event);appendFileSync(path.join(out,'raw.ndjson'),JSON.stringify({at:new Date().toISOString(),...event})+'\n');};
const counts=Object.fromEntries(cases.map(q=>[q.id,0]));
for(let i=1;i<=count+(version==='v2'?1:0);i++)for(const q of cases)if(matches(q,i,count,version))counts[q.id]++;
await writeFile(path.join(out,'frozen-cases.json'),JSON.stringify({count,version,cases,counts,scope:'Fixed 9 legacy shapes plus 12 source-rule probes. Screen only, one query each.'},null,2));
let child=null,pending=null,readyResolve,readyReject,failure=null,seq=0,stopContext=null;
const killed=[];
function stopChild(){if(child){const pid=child.pid;child.kill('SIGKILL');killed.push(pid);child=null;}}
async function start(variant){
 child=fork(fileURLToPath(new URL('./probe-child.mjs',import.meta.url)),[path.resolve(database),variant],{stdio:['ignore','ignore','inherit','ipc']});
 const ready=new Promise((resolve,reject)=>{readyResolve=resolve;readyReject=reject;});
 const timer=setTimeout(()=>{readyReject(Error('READY_TIMEOUT'));stopChild();},10000);
 child.on('message',m=>{if(m.ready){clearTimeout(timer);readyResolve(m);return;}if(pending&&m.id===pending.id){clearTimeout(pending.timer);const p=pending;pending=null;m.error?p.reject(Error(m.error)):p.resolve(m.result);}});
 child.on('exit',(code,signal)=>{clearTimeout(timer);const e=Error('CHILD_EXIT:'+code+':'+signal);readyReject(e);if(pending){clearTimeout(pending.timer);pending.reject(e);pending=null;}});
 child.on('error',e=>{readyReject(e);if(pending){clearTimeout(pending.timer);pending.reject(e);pending=null;}});
 const info=await ready;assert.equal(info.snapshotId,version);log({event:'ready',variant,...info});
}
function request(input,explain=false){return new Promise((resolve,reject)=>{
 const id=++seq;const timer=setTimeout(()=>{pending=null;stopChild();reject(Error('QUERY_DEADLINE_4000MS'));},4000);
 pending={id,timer,resolve,reject};child.send({id,input,explain});
});}
const parity=new Map();
try{
 for(const variant of ['S0','S1'])for(const contract of ['E','L']){
  stopContext={variant,contract,phase:'ready'};
  await start(variant);
  for(const q of cases){const input={...q,contract},began=performance.now();let result;
   stopContext={variant,contract,phase:'search',queryId:q.id};
   log({event:'query.begin',variant,contract,id:q.id});
   try{result=await request(input);}catch(e){log({event:'query.failed',variant,contract,id:q.id,error:e.message,roundTripMs:performance.now()-began});throw e;}
   const roundTripMs=performance.now()-began;log({event:'query.result',variant,contract,id:q.id,roundTripMs,result});
   assert.equal(result.snapshotId,version);const ids=result.hits.map(h=>h.pageId);assert.equal(new Set(ids).size,ids.length);assert.equal(ids.length,Math.min(10,counts[q.id]));
   if(contract==='E')assert.equal(result.total,counts[q.id]);else assert.equal(Object.hasOwn(result,'total'),false);
   for(const h of result.hits){const i=Number(h.pageId.slice(1));assert.ok(i>=1&&i<=count+(version==='v2'?1:0));assert.ok(matches(q,i,count,version),q.id+':ineligible');
    const p=source(i,version,count);assert.equal(h.pageId,p.pageId);assert.equal(h.spaceId,p.spaceId);assert.equal(h.title,p.title);assert.equal(h.snippet,Array.from(p.content).slice(0,160).join(''));assert.deepEqual(h.tagIds,[...p.tags].sort());}
   const key=contract+':'+q.id;if(variant==='S0')parity.set(key,ids);else assert.deepEqual(ids,parity.get(key),'S0/S1 ordered parity '+key);
   stopContext={variant,contract,phase:'explain',queryId:q.id};
   plans.push({variant,contract,id:q.id,plan:await request(input,true)});
  }
  const closing=child;const exit=new Promise(resolve=>closing.once('exit',resolve));closing.disconnect();await exit;child=null;
 }
}catch(e){failure={message:e.message,stack:e.stack,context:stopContext,policy:'Stop current configuration and all remaining screening configurations; no retries or escalation'};log({event:'screen.stopped',failure});}
finally{stopChild();}
const final=await stat(database);assert.equal(final.size,initial.size);assert.equal(final.mtimeMs,initial.mtimeMs);
const hashes={};for(const name of ['adapter.mjs','probe.mjs','probe-child.mjs','probe-cases.mjs'])hashes[name]=createHash('sha256').update(await readFile(new URL(name,import.meta.url))).digest('hex');
const result={passed:!failure,failure,scope:'G2 screening only, not formal block or SLO/capacity evidence',count,version,hashes,plans,killed,
 completed:records.filter(r=>r.event==='query.result').length,expectedQueries:cases.length*4,dbStatUnchanged:true};
await writeFile(path.join(out,'result.json'),JSON.stringify(result,null,2));console.log(JSON.stringify({passed:result.passed,completed:result.completed,expected:result.expectedQueries,failure}));if(failure)process.exitCode=1;
