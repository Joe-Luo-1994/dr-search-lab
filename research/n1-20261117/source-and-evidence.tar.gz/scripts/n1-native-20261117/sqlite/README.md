# N1 SQLite G1 candidate

Prepared only; parent orchestrator executes after design-review closure.

`node golden.mjs NEW_OUTPUT_DIRECTORY` (Node 22 with node:sqlite). Output directory must not exist. It creates only its own tiny fixture and writes raw assertions, token expectations, source hashes and EXPLAIN QUERY PLAN. No service, million-page query or external dependency is started here.

Adapter: `openReader(databasePath, {variant:'S0'|'S1', dataAsOf})`; `.search({q, identity:'all'|'a'|'none', spaceId?, tags:[], contract:'E'|'L'})`, `.explain(input)`, `.close()`.

S0 retains original query shape; S1 uses rank MATCH with the same 3:1 BM25 weights. Both retain pageId tie-break. E includes exact count; L omits total entirely. Filters/identity precede LIMIT. Invalid identity rejects; this deliberately fixes historical broad fallback behavior, so S0 refers to SQL control, not an identical historical worker executable.

No worker scheduling or cancellation exists in this module: run it in a parent-controlled child process; do not import synchronous search into the Next event loop. Parent must enforce external deadlines and resource limits. It is not a production ReBAC adapter. dataAsOf must come from verified artifact metadata; missing value is null, never fabricated.

32 hand-authored cases run in each of S0/S1 × E/L. Expectations are literal and do not derive from SQLite. Cases cover nonrepeated documents, CJK/English, tags AND, space, authorization, null match, body/title, PDF-extracted text and equal-score tie. A matched-length title/body pair verifies strict 3:1 title-boost order, native negative-BM25 ascending direction, and a winner contrary to pageId order. Twelve tied documents are inserted in reverse lexical order, including p999999/p1000000: E total must be 12 while only ten unique eligible hits are returned. E requires lexical pageId tie order; SQLite L deliberately retains it, whereas the shared fixture permits Tantivy L native ties. This small set is not production relevance evidence. Full token parity against Tantivy and million-page source oracle remain separate gates.

No tests have been executed by this implementation agent.

G1 uses `includeScores:true` to assert score direction. Default is false, preserving the original projection for subsequent performance runs. Do not treat G1 diagnostic timings as a performance comparison.
