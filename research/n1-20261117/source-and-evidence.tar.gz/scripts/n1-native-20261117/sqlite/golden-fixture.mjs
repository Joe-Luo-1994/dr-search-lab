// Hand-authored expectations; no engine/query code is imported here.
export const snapshotId='n1-golden-v1';
export const dataAsOf='2026-11-17T00:00:00Z';
export const pages=[
  {pageId:'g01',spaceId:'space0',title:'Orchid recovery guide',content:'Restore the orchid service safely.',tags:['ops','dr']},
  {pageId:'g02',spaceId:'space1',title:'Orchid budget',content:'Finance plans for next year.',tags:['finance']},
  {pageId:'g03',spaceId:'space0',title:'Network operations',content:'Router failover and packet tracing.',tags:['ops']},
  {pageId:'g04',spaceId:'space0',title:'資料備份',content:'災難復原 文件 搜尋',tags:['dr','zh']},
  {pageId:'g05',spaceId:'space1',title:'排程維護',content:'週末維護 windows server',tags:['ops','zh']},
  {pageId:'g06',spaceId:'space0',title:'PDF laboratory',content:'Extracted PDF text: quartz calibration certificate.',tags:['pdf','lab']},
  {pageId:'g07',spaceId:'space0',title:'Harbor login',content:'Identity token rotation procedure.',tags:['security','ops']},
  {pageId:'g08',spaceId:'space1',title:'Banana recipe',content:'Banana bread uses flour and ripe fruit.',tags:['food']},
  {pageId:'g09',spaceId:'space0',title:'Firmware bulletin',content:'Sensor error E42 requires revision B7.',tags:['lab','ops']},
  {pageId:'g10',spaceId:'space0',title:'Archive handbook',content:'Orchid records retained for audit.',tags:['archive']},
  {pageId:'g11',spaceId:'space0',title:'Tie marker',content:'Equal scoring words.',tags:['tie']},
  {pageId:'g12',spaceId:'space0',title:'Tie marker',content:'Equal scoring words.',tags:['tie']},
  {pageId:'g13',spaceId:'space0',title:'plain neutral',content:'magnet reference',tags:['boost']},
  {pageId:'g14',spaceId:'space0',title:'magnet reference',content:'plain neutral',tags:['boost']},
  // Reverse lexicographic insertion deliberately differs from pageId tie order.
  ...['p999999','p999998','p900000','p800000','p700000','p600000','p500000','p400000','p300000','p200000','p1000000','p100000']
    .map(pageId=>({pageId,spaceId:'space0',title:'cutoff sentinel',content:'identical equal scoring document',tags:['cutoff']})),
];
const q=(id,text,expected,extra={})=>({id,input:{q:text,identity:'all',tags:[],...extra},expected,eligible:expected});
export const cases=[
  q('title-only','budget',['g02']),q('body-only','packet',['g03']),q('uppercase','ORCHID',['g01','g02','g10']),
  q('and-terms','orchid recovery',['g01']),q('long-and','quartz calibration certificate',['g06']),
  q('no-match','notpresentanywhere',[]),q('space','orchid',['g01','g10'],{spaceId:'space0'}),
  q('space-other','orchid',['g02'],{spaceId:'space1'}),q('tags-and','orchid',['g01'],{tags:['ops','dr']}),
  q('tags-missing','orchid',[],{tags:['ops','finance']}),q('tag-order','orchid',['g01'],{tags:['dr','ops']}),
  q('tag-repeat','orchid',['g01'],{tags:['dr','dr']}),q('authorized','orchid',['g01','g10'],{identity:'a'}),
  q('unauthorized-space','orchid',[],{identity:'a',spaceId:'space1'}),q('none','orchid',[],{identity:'none'}),
  q('zh-title','資料',['g04']),q('zh-body','災難復原',['g04']),q('zh-mixed','維護 windows',['g05']),
  q('pdf-extracted-body','quartz',['g06']),q('pdf-filter','quartz',['g06'],{tags:['pdf','lab']}),
  q('punctuation','E42, B7',['g09']),q('cross-field','harbor token',['g07']),
  q('space-and-tags','rotation',['g07'],{spaceId:'space0',tags:['security','ops']}),
  q('and-not-or','banana router',[]),q('same-score','tie marker',['g11','g12']),
  q('unrelated-tag','banana',[],{tags:['ops']}),q('unicode-filter','災難',['g04'],{identity:'a',tags:['zh','dr']}),
  {...q('title-boost','magnet',['g13','g14']),expectedOrder:['g14','g13']},
  {...q('top10-cutoff','cutoff',
    ['p100000','p1000000','p200000','p300000','p400000','p500000','p600000','p700000','p800000','p900000','p999998','p999999']),
    expectedOrderByContract:{E:['p100000','p1000000','p200000','p300000','p400000','p500000','p600000','p700000','p800000','p900000']},
    expectedSqliteOrder:['p100000','p1000000','p200000','p300000','p400000','p500000','p600000','p700000','p800000','p900000'],
    // Tantivy L may use native tie order: validate ten unique eligible results,
    // not this SQLite-specific pageId order. E must enforce lexical pageId.
    nativeTiesAllowedInL:true},
  {id:'unknown-identity',input:{q:'orchid',identity:'invented',tags:[]},error:'UNKNOWN_IDENTITY'},
  {id:'missing-identity',input:{q:'orchid',tags:[]},error:'UNKNOWN_IDENTITY'},
  {id:'empty-query',input:{q:'!!!',identity:'all',tags:[]},error:'INVALID_QUERY'},
];
export const tokenCases=[
  {text:'DISASTER recovery',expected:['disaster','recovery']},
  {text:'E42, B7',expected:['e42','b7']},
  {text:'資料',expected:['資料']},
  {text:'災難復原',expected:['災難','復原']},
  {text:'維護 windows',expected:['維護','windows']},
];
