import {openReader} from './adapter.mjs';
const reader=openReader(process.argv[2],{variant:process.argv[3],includeScores:false});
process.send({ready:true,snapshotId:reader.snapshotId});
process.on('message',({id,input,explain})=>{
 try{const result=explain?reader.explain(input):reader.search(input);process.send({id,result});}
 catch(e){process.send({id,error:e.message});}
});
process.on('disconnect',()=>{reader.close();process.exit(0);});
