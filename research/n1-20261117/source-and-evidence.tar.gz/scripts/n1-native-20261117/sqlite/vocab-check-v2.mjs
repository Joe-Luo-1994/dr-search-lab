// Revision 2: reviewer-approved literal oracle correction for ICU77.1. Original failure preserved.
import {DatabaseSync} from 'node:sqlite';
import {writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {pages} from './golden-fixture.mjs';
// Literal lexical expectations, independent of SQLite and adapter normalization.
const words={
g01:['orchid recovery guide','restore the orchid service safely'],g02:['orchid budget','finance plans for next year'],
g03:['network operations','router failover and packet tracing'],g04:['資料 備份','災難 復原 文件 搜尋'],
g05:['排 程 維護','週末 維護 windows server'],g06:['pdf laboratory','extracted pdf text quartz calibration certificate'],
g07:['harbor login','identity token rotation procedure'],g08:['banana recipe','banana bread uses flour and ripe fruit'],
g09:['firmware bulletin','sensor error e42 requires revision b7'],g10:['archive handbook','orchid records retained for audit'],
g11:['tie marker','equal scoring words'],g12:['tie marker','equal scoring words'],g13:['plain neutral','magnet reference'],g14:['magnet reference','plain neutral']};
const [filename,out]=process.argv.slice(2);if(!filename||!out)throw Error('Usage: node vocab-check.mjs GOLDEN_DB NEW_RESULT_JSON');
const db=new DatabaseSync(filename,{readOnly:true});const rows=[];let failure;
try{
 db.exec("CREATE VIRTUAL TABLE temp.vocab USING fts5vocab(main,search_index,instance)");
 for(const p of pages){const id=db.prepare('SELECT rowid FROM pages WHERE pageId=?').get(p.pageId).rowid;
  const expected=words[p.pageId]??['cutoff sentinel','identical equal scoring document'];
  for(const [i,column]of ['title','content'].entries()){
   const actual=db.prepare('SELECT term,offset FROM temp.vocab WHERE doc=? AND col=? ORDER BY offset').all(id,column);
   const want=expected[i].split(' ').map((term,offset)=>({term,offset}));rows.push({pageId:p.pageId,column,expected:want,actual});
   assert.deepEqual(actual.map(x=>({...x})),want,p.pageId+':'+column);
  }
 }
}catch(e){failure={message:e.message,stack:e.stack};}finally{db.close();}
await writeFile(out,JSON.stringify({passed:!failure,scope:'Actual golden FTS5 instance vocabulary vs hand-authored terms and offsets; not million corpus parity',rows,failure},null,2),{flag:'wx'});
console.log(JSON.stringify({passed:!failure,columns:rows.length,failure}));if(failure)process.exitCode=1;
