import readline from 'node:readline';
import {openReader} from './adapter.mjs';
const reader=openReader(process.argv[2],{variant:process.argv[3],includeScores:false});
const send=x=>process.stdout.write(JSON.stringify(x)+'\n');
send({ready:true,pid:process.pid,snapshotId:reader.snapshotId});
const input=readline.createInterface({input:process.stdin});
input.on('line',line=>{let id;
 try{const m=JSON.parse(line);id=m.id;send({id,result:m.explain?reader.explain(m.input):reader.search(m.input)});}
 catch(e){send({id,error:e.message});}
});
input.on('close',()=>{reader.close();process.exit(0);});
