# N1 G2 screening candidate (not executed)

G1 files remain unchanged. New files are `vocab-check.mjs`, `probe-cases.mjs`, `probe-child.mjs`, `probe.mjs` and this note.

1. `node vocab-check.mjs GOLDEN_DB NEW_RESULT_JSON`
   Opens the G1 golden DB read-only and creates only a TEMP fts5vocab(instance) view. Compares actual indexed terms and offsets with literal hand-authored canonical expectations for every title/body. This is independent of adapter normalization; failures must remain evidence. It is a golden-corpus parity check, not full Unicode parity.
2. `node probe.mjs MILLION_DB NEW_OUTPUT_DIR 1000000 v1`
   One screening query for each of nine legacy shapes plus twelve fixed probes, for S0/S1 × E/L (84 queries). Independent source-rule predicates compute exact eligible counts without reading query results. Returned IDs must be unique, eligible and exactly min(10,count); fields are checked against the existing source generator. E exact total and L absent-total are checked. S0/S1 preserve ordered result parity. All queries use no-score projection; each query also gets a separately timed/deadlined EQP, not included in its measured round trip.

Each config uses a fresh child and each request has a parent 4-second deadline that kills the synchronous SQLite child. No internal benchmark loop, retries or automatic resource escalation. First failure stops the screening run; evidence is retained. Screen timing is not a formal block or SLO estimate. Formal blocks must only be prepared after both-engine gates and reviewer approval; not implemented here.

Parent must run the whole controller/children inside the bounded resource unit, impose total runtime/host/disk guards, verify child cleanup and hash the DB/source inputs before/after. This runner only checks DB size+mtime; it does not claim full DB hash integrity or cgroup enforcement. Reading/stat or oracle setup happens outside query timing. Source-rule oracle has O(21N) work and should finish before any child is started.

No test or benchmark was executed by this implementation agent.
