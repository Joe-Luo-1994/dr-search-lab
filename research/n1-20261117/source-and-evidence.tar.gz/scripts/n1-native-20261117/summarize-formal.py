"""Summarize completed blocks without replacing raw evidence or pooling percentiles."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
EVIDENCE = ROOT / 'evidence/n1-native-20261117'
blocks = []
for engine in ('sqlite', 'tantivy'):
    for block in (1, 2, 3):
        path = EVIDENCE / f'formal-{engine}-b{block}-results/result.json'
        if not path.exists():
            continue
        result = json.loads(path.read_text(encoding='utf8'))
        blocks.append({'engine': engine, 'block': block, 'passed': result['passed'],
                       'source': str(path.relative_to(ROOT)).replace('\\', '/'),
                       'summary': result['summary']})
summary = {'complete': len(blocks) == 6 and all(b['passed'] for b in blocks),
           'blocks': blocks,
           'scope': 'Synthetic serial E contract; 30 samples per shape/block; no production/API capacity or pure-engine ratio claim.'}
out = EVIDENCE / 'formal-summary.json'
out.write_text(json.dumps(summary, indent=2, ensure_ascii=False)+'\n', encoding='utf8')
print(json.dumps({'complete': summary['complete'], 'blocks': len(blocks)}))
for shape in sorted({s for b in blocks for s in b['summary']}):
    values = {}
    for engine in ('sqlite', 'tantivy'):
        v = [b['summary'][shape]['roundTripMs']['p95'] for b in blocks if b['engine'] == engine]
        values[engine] = '/'.join(f'{x:.2f}' for x in v)
    print(f"{shape}: SQLite={values['sqlite']} ms; Tantivy={values['tantivy']} ms")
