# G3a最小接入：實作前review卡

2026-11-17，僅預載V1混合負載，非完整G3。此目錄是新隔離runtime來源，不修改K5／Rust binary／既有MinIO資料。Reviewer已允許進最小實作；完成後仍需讀碼及smoke gate。

## 檔案與復用

- `service.mjs`：沿用K5 c-million service的page/media/SSR授權、version pin、body/media hash、backpressure、內容槽4；startup改預載descriptor校驗與CompositePool，`update`一律404且status標`preloaded-no-update`。對外search只剝diagnostic，保留dataAsOf（來源未提供則null）／total／hits並補pageId URL；Rust仍計算nativeScores，不能說已省掉成本。
- `pool.mjs`：單一aggregate queue16、4秒admission deadline（包含排隊）。固定2個Rust search slots＋2個Node metadata slots，共4child；所有child與Next在同4CPU／8GiB reader cgroup。分派從共用queue找可用角色，記明拓撲差異，不與SQLite4通用worker作單變因因果聲明。slot關閉、ready失敗、protocol mismatch、timeout均使aggregate fail-closed並清除排隊；所有child回收，不能只殺Node留下Rust。
- `metadata-worker.mjs`：複用原worker的只讀SQLite page／media lookup及quick_check；不執行search。讀完整舊SQLite DB，仍含FTS與正文，全部算容量／傳輸，不稱metadata-only。
- `storage.mjs`：保留原MinIO遠端內容函式，不新增外部服務；startup完整artifact校驗放`preloaded.mjs`，不走原單檔install/download。
- `preloaded.mjs`：config列metadata DB bytes/hash、Rust binary hash、Tantivy index逐檔bytes/hash、snapshot/source fingerprint。start前串流校驗，不覆寫artifact；拒絕路徑穿越／symlink；要求Tantivy manifest版本與來源hash等於同版SQLite外層來源manifest。檔案驗證與ready成本獨立記錄，不列入steady-state窗。
- `README.md`：配置schema、所有程序／PID／queue度量、尚未完成G3b、初始人工預載成本。

## 版本與協定

只允許E契約；query長度120、tags<=10沿舊service，identity先限制all/a/none。queryTokens在pool內複用已凍結canonical分詞步驟（Han Intl.Segmenter、Unicode字詞、lowercase），未import SQLite adapter，避免額外載入DB依賴；`spaceId=null`從傳給Rust的input省略。Rust ready檢查snapshot、count、protocol；每response再核snapshot，避免`...result`蓋過pinned version。Meta ready亦需相同snapshot；metadata與search在同一CompositePool.version／refs下pin。

Tokenization在Next服務同quota內做，不移到load generator。Tantivy不套SQLite的Top10 ID順序oracle，僅驗必要golden、eligible/count/足額/unique與原生排序規則；不同拓撲的結果不當單變因因果。

status保留workers PID列表供現有harness，但增加workerDetails角色與pid、各role busy及aggregatequeue。harness須辨識兩種cmdline與相同cgroup，不能刪掉PID歸屬檢查來讓測試通過。原K5load包含update，因此不能直接使用整份舊runner作G3a，須由主agent新runner只執行W/M且明示未測更新。

## 最小驗收與界線

先小型smoke：search→page→media、unknown identity拒絕、none空結果、Space/Tags、未授權page、錯version、update404、stop後全PID消失。artifact或ready版本不合需503且不ready。此smoke不實作新的故障矩陣；至少驗一個不一致descriptor拒絕。

研究投入上限2h由主agent計時；若只能完成adapter不能完成smoke，不宣稱可跑正式混載。滿足W/M也只是G3a，G3b仍需整包MinIO發布／下載／新舊metadata+index原子切版／雙role drain。未知工時不代表不值得，只作下一卡的實際工程差額。
