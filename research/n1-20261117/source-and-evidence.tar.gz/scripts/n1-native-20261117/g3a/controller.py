"""G3a isolated preloaded W/M controller. Explicit prepare/start only; no import side effects."""
from pathlib import Path
import argparse, hashlib, json, os, shutil, signal, socket, sqlite3, subprocess, time, urllib.request, urllib.error
ROOT=Path('/PUBLIC/LINUX_HOME/dr-search-lab-e1-20261115/repo')
OLD=ROOT/'.lab/c-million-20261116'
SOURCE=Path(__file__).resolve().parent
NODE='/PUBLIC/LINUX_HOME/.nvm/versions/node/v22.18.0/bin/node'
ENV=dict(os.environ,PATH=str(Path(NODE).parent)+':/usr/local/bin:/usr/bin:/bin',NEXT_TELEMETRY_DISABLED='1')
BASE='http://127.0.0.1:3190'; NEXT='dr-n1-g3a-reader-20261117'; MINIO='dr-n1-g3a-minio-20261117'
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def descriptor(p):return {'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':digest(p)}
def save(p,v):p.write_text(json.dumps(v,indent=2))
def save_private(p,v):
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
 with os.fdopen(fd,'w') as f:json.dump(v,f,indent=2)
 p.chmod(0o600)
def command(args,check=True):return subprocess.run(args,env=ENV,capture_output=True,text=True,check=check)
def state(unit):
 r=command(['systemctl','--user','show',unit,'--property=MainPID,ActiveState,Result,ExecMainStatus,ControlGroup,TimeoutStopUSec,KillMode'],False)
 return dict(line.split('=',1) for line in r.stdout.splitlines() if '=' in line)
def limits(unit,memory):
 s=state(unit);cg=Path('/sys/fs/cgroup'+s['ControlGroup']);v={f:(cg/f).read_text().strip() for f in ['cpu.max','memory.max','memory.swap.max','cgroup.procs']}
 assert v['cpu.max']=='400000 100000' and v['memory.max']==str(memory) and v['memory.swap.max']=='0'
 assert s['KillMode']=='control-group' and s['TimeoutStopUSec']=='2s'
 return {'unit':unit,'cgroup':str(cg),'state':s,**v}
def launch(unit,argv,run,memory,extra=[]):
 command(['systemd-run','--user','--unit='+unit,'-p','CPUQuota=400%','-p','MemoryMax='+str(memory),'-p','MemorySwapMax=0','-p','TasksMax=128','-p','RuntimeMaxSec=3600','-p','TimeoutStopSec=2s','-p','KillMode=control-group','-p','StandardOutput=append:'+str(run/(unit+'.log')),'-p','StandardError=append:'+str(run/(unit+'.log')),'--working-directory='+str(run/'project'),'--setenv=PATH='+ENV['PATH'],'--setenv=NEXT_TELEMETRY_DISABLED=1']+extra+argv)
def get(path,identity=None,timeout=10):
 req=urllib.request.Request(BASE+path,headers={} if identity is None else {'x-cap-identity':identity})
 try:
  with urllib.request.urlopen(req,timeout=timeout) as r:return r.status,r.read(),dict(r.headers)
 except urllib.error.HTTPError as e:return e.code,e.read(),dict(e.headers)
def stop(run):
 rows={}
 for unit in [NEXT,MINIO]:
  before=state(unit);cg=before.get('ControlGroup');pids=[];stats={}
  if cg:
   cp=Path('/sys/fs/cgroup'+cg)
   for f in ['cgroup.procs','cpu.stat','memory.peak','memory.events','io.stat']:
    try:stats[f]=(cp/f).read_text()
    except FileNotFoundError:pass
   pids=[int(x) for x in stats.get('cgroup.procs','').split()]
  command(['systemctl','--user','stop',unit],False)
  alive=[p for p in pids if Path('/proc/'+str(p)).exists()]
  rows[unit]={'before':before,'stats':stats,'after':state(unit),'pids':pids,'remainingPids':alive}
 save(run/('stop-'+str(time.time_ns())+'.json'),rows)
 assert all(not x['remainingPids'] for x in rows.values()),'CHILD_LEAK'
 return rows

def prepare(a,run):
 if run.exists():raise RuntimeError('NEW_RUN_REQUIRED')
 if state(NEXT).get('ActiveState')=='active' or state(MINIO).get('ActiveState')=='active':raise RuntimeError('G3A_ALREADY_RUNNING')
 run.mkdir(parents=True);(run/'runtime').mkdir();(run/'project').mkdir()
 for p in SOURCE.glob('*'):
  if p.is_file():shutil.copy2(p,run/'runtime'/p.name)
 for name in ['package.json','package-lock.json']:shutil.copy2(OLD/'project'/name,run/'project'/name)
 (run/'project/node_modules').symlink_to(OLD/'project/node_modules',target_is_directory=True)
 shutil.copytree(OLD/'project/.next',run/'project/.next')
 cfg=json.loads((OLD/'fallback-1/config.json').read_text())
 source=OLD/'fixture-1000000/v1/manifest.json';db=source.parent/'search.sqlite'
 g={'engine':a.engine,'snapshotId':'v1','metadata':descriptor(db),'sourceManifest':descriptor(source)}
 if a.engine=='T1':
  if not a.index or not a.binary:raise RuntimeError('T1_REQUIRES_INDEX_BINARY')
  index=Path(a.index).resolve();g.update(binary=descriptor(Path(a.binary)),indexDir=str(index),indexFiles=[])
  for p in sorted(index.iterdir()):
   if not p.is_file() or p.is_symlink():raise RuntimeError('INDEX_FLAT_REGULAR_ONLY')
   d=descriptor(p);d['path']=p.name;g['indexFiles'].append(d)
 cfg.update(endpoint='http://127.0.0.1:19700',baseUrl=BASE+'/api/capi',webBase=BASE,webBaseUrl=BASE,eventLog=str(run/'events.ndjson'),cacheDir=str(run/'unused-cache'),testHooks=False,readerCpu=400,readerMemory=8*1024**3,g3a=g)
 cfg.update(minioCpu=400,minioMemory=4*1024**3,diskGuardFile=str(run/'disk-guard.json'),loadHarness={'engine':'sqlite' if a.engine=='S1' else 'tantivy','baselineGeneration':a.name,'workerRoles':([{'role':'general','count':4,'commandIncludes':str(run/'runtime/sqlite-worker.mjs')}] if a.engine=='S1' else [{'role':'metadata','count':2,'commandIncludes':str(run/'runtime/metadata-worker.mjs')},{'role':'search','count':2,'commandIncludes':str(Path(a.binary).resolve())+' serve '+str(Path(a.index).resolve())}])})
 cfgfile=run/'config.json';save_private(cfgfile,cfg)
 # Deliberately omit all credentials/private config from public receipts.
 save(run/'prepared.json',{'at':time.time(),'engine':a.engine,'artifacts':g,'runtimeFiles':{p.name:descriptor(p) for p in (run/'runtime').glob('*') if p.is_file()},'nextBuildId':(run/'project/.next/BUILD_ID').read_text().strip(),'mode':'preloaded-no-update','ports':[3190,19700,19701]})
 print(json.dumps({'prepared':str(run),'engine':a.engine,'noServicesStarted':True}))

def start(run):
 for port in [3190,19700,19701]:
  with socket.socket() as s:
   if s.connect_ex(('127.0.0.1',port))==0:raise RuntimeError('PORT_OCCUPIED_'+str(port))
 # Reusing a MinIO data directory requires its old server to be stopped.
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
  except (FileNotFoundError,PermissionError):continue
  if str(OLD/'minio-data') in cmd and 'minio' in cmd:raise RuntimeError('OLD_MINIO_DATA_IN_USE')
 began=time.monotonic()
 try:
  launch(MINIO,[str(ROOT/'work/minio-official-build/bin/minio'),'server',str(OLD/'minio-data'),'--address','127.0.0.1:19700','--console-address','127.0.0.1:19701'],run,4*1024**3,['-p','EnvironmentFile='+str(OLD/'minio.env')])
  launch(NEXT,[NODE,str(run/'project/node_modules/next/dist/bin/next'),'start','--port','3190','--hostname','127.0.0.1'],run,8*1024**3,['--setenv=CAP_CONFIG='+str(run/'config.json'),'--setenv=CAP_SERVICE_URL='+(run/'runtime/service.mjs').as_uri()])
  lim={'reader':limits(NEXT,8*1024**3),'minio':limits(MINIO,4*1024**3)};save(run/'limits.json',lim)
  cfg=json.loads((run/'config.json').read_text());cfg.update(readerCgroup=lim['reader']['cgroup'],minioCgroup=lim['minio']['cgroup']);save_private(run/'config.json',cfg)
  last='not attempted'
  while time.monotonic()-began<180:
   try:
    status,body,_=get('/api/capi/status',timeout=max(1,180-(time.monotonic()-began)))
    data=json.loads(body)
    if status!=200 or data.get('fatal') or data.get('snapshotId')!='v1':raise RuntimeError('NOT_READY')
    roles=sorted(x['role'] for x in data['workerDetails']);expected=['general']*4 if cfg['g3a']['engine']=='S1' else ['metadata','metadata','search','search']
    assert roles==expected and len(set(data['workers']))==4
    membership={}
    for pid in [data['pid']]+data['workers']:
     text=Path('/proc/'+str(pid)+'/cgroup').read_text();assert lim['reader']['state']['ControlGroup'] in text
     membership[str(pid)]={'cgroup':text,'cmdline':Path('/proc/'+str(pid)+'/cmdline').read_bytes().replace(b'\0',b' ').decode()}
    with urllib.request.urlopen('http://127.0.0.1:19700/minio/health/ready',timeout=5) as r:assert r.status==200
    save(run/'started-at.json',{'wallTime':time.time()-(time.monotonic()-began),'maxLifetimeSeconds':3600})
    save(run/'ready.json',{'startupSeconds':time.monotonic()-began,'status':data,'membership':membership,'cacheNote':'startup full hashes may warm host cache; not cold RTO'})
    print(json.dumps({'ready':True,'startupSeconds':time.monotonic()-began}));return
   except (OSError,ValueError,RuntimeError) as e:last=type(e).__name__;time.sleep(.5)
  raise RuntimeError('READY_TIMEOUT_'+last)
 except BaseException:
  save(run/'startup-failed.json',{'at':time.time(),'elapsedSeconds':time.monotonic()-began});stop(run);raise

def smoke(run):
 from urllib.parse import urlencode
 cfg=json.loads((run/'config.json').read_text());db=sqlite3.connect('file:'+cfg['g3a']['metadata']['path']+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
 page=dict(db.execute("SELECT * FROM pages WHERE bodyKey IS NOT NULL AND mediaId IS NOT NULL LIMIT 1").fetchone());media=dict(db.execute('SELECT * FROM media WHERE mediaId=?',(page['mediaId'],)).fetchone());tags=[x[0] for x in db.execute('SELECT tagId FROM page_tags WHERE pageId=? ORDER BY tagId',(page['pageId'],))];db.close()
 rows=[]
 def check(name,path,identity,status,predicate=lambda b:True):
  t=time.monotonic();code,body,_=get(path,identity);ok=code==status and predicate(body);rows.append({'name':name,'status':code,'expectedStatus':status,'passed':ok,'elapsedMs':(time.monotonic()-t)*1000,'responseBytes':len(body)});save(run/'smoke.json',{'passed':all(x['passed'] for x in rows),'rows':rows});assert ok,name
 q='/api/capi/search?'+urlencode({'q':'unique'+page['pageId']})
 check('search-page-mapping',q,'all',200,lambda b:(lambda r:r['snapshotId']=='v1' and r['dataAsOf'] is None and r['total']==1 and [h['pageId'] for h in r['hits']]==[page['pageId']])(json.loads(b)))
 check('none',q,'none',200,lambda b:json.loads(b)['total']==0 and not json.loads(b)['hits'])
 check('unknown',q,'unknown',503)
 check('wrong-space',q+'&spaceId=never','all',200,lambda b:json.loads(b)['total']==0)
 check('tag-and',q+''.join('&'+urlencode({'tagId':t}) for t in tags),'all',200,lambda b:json.loads(b)['total']==1)
 check('tag-and-one-missing',q+''.join('&'+urlencode({'tagId':t}) for t in tags)+'&tagId=never','all',200,lambda b:json.loads(b)['total']==0)
 check('wrong-tag',q+'&tagId=never','all',200,lambda b:json.loads(b)['total']==0)
 pp='/api/capi/page?'+urlencode({'pageId':page['pageId'],'version':'v1'})
 check('page',pp,'all',200,lambda b:json.loads(b)['pageId']==page['pageId'])
 check('page-denied',pp,'none',404)
 check('wrong-version',pp.replace('version=v1','version=v2'),'all',409)
 mp='/api/capi/media?'+urlencode({'pageId':page['pageId'],'mediaId':page['mediaId'],'version':'v1'})
 check('media',mp,'all',200,lambda b:len(b)==media['bytes'] and hashlib.sha256(b).hexdigest()==media['sha256'])
 check('update-disabled','/api/capi/update','all',404)
 code="import {readFile} from 'node:fs/promises';const {verifyPreloaded}=await import(process.argv[1]);const c=JSON.parse(await readFile(process.argv[2],'utf8'));c.g3a.metadata.bytes=-1;try{await verifyPreloaded(c);process.exitCode=1;}catch(e){if(e.message!=='ARTIFACT_DESCRIPTOR')process.exitCode=2;}"
 r=command([NODE,'--input-type=module','-e',code,(run/'runtime/preloaded.mjs').as_uri(),str(run/'config.json')],False)
 rows.append({'name':'bad-descriptor-rejected','passed':r.returncode==0,'exitCode':r.returncode})
 save(run/'smoke.json',{'passed':all(x['passed'] for x in rows),'rows':rows});assert r.returncode==0,'BAD_DESCRIPTOR_GATE'
 print(json.dumps({'smokePassed':True,'checks':len(rows)}))


def run_load(a,run):
 if not a.stage:raise RuntimeError('STAGE_REQUIRED')
 stage=a.stage;rep=a.rep;out=run/('load-'+stage+'-'+str(rep))
 if out.exists():raise RuntimeError('NEW_LOAD_OUTPUT_REQUIRED')
 if (run/'load-failed.json').exists():raise RuntimeError('PRIOR_LOAD_FAILED_NEW_BASELINE_REQUIRED')
 def passed(path):
  return path.exists() and json.loads(path.read_text()).get('passed') is True
 if stage=='baseline':
  if rep!=1 or any(run.glob('load-baseline-*')):raise RuntimeError('BASELINE_ONCE_ONLY')
 else:
  if not passed(run/'load-baseline-1/result.json'):raise RuntimeError('BASELINE_NOT_PASSED')
  if stage=='M' and not all(passed(run/('load-W-'+str(i)+'/result.json')) for i in [1,2,3]):raise RuntimeError('ALL_W_REQUIRED')
  if rep>1 and not passed(run/('load-'+stage+'-'+str(rep-1)+'/result.json')):raise RuntimeError('PREVIOUS_REP_REQUIRED')
 loader=SOURCE.parent/'g3-load/load.mjs'
 argv=[NODE,str(loader),'--config',str(run/'config.json'),'--oracle',str(OLD/'fixture-1000000/oracle.json'),'--out',str(out),'--stage',stage,'--rep',str(rep)]
 if stage!='baseline':argv+=['--baseline-result',str(run/'load-baseline-1/result.json')]
 # Parent loadgen remains outside reader/minio cgroups. 398-second deadline includes independent oracle preparation (maximum30s).
 log=(run/('load-'+stage+'-'+str(rep)+'.log')).open('x');cp=subprocess.Popen(argv,env=ENV,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 started=time.monotonic();schedule_at=None;reason=None;receipt={};last_host=-10;row={}
 try:
  while cp.poll() is None:
   now=time.monotonic()
   if (out/'schedule.json').exists() and schedule_at is None:schedule_at=now
   age=now-started
   if now-started-last_host>=5:
    last_host=now-started;free=shutil.disk_usage(run).free
    mem={line.split(':')[0]:int(line.split()[1])*1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith(('MemAvailable:','SwapFree:'))}
    used=int(subprocess.check_output(['du','-sb',str(ROOT/'.lab/n1-native-20261117')]).split()[0])
    row={'at':time.time(),'elapsedSeconds':age,'diskFreeBytes':free,'runBytes':used,**mem,'hostLoad':Path('/proc/loadavg').read_text().strip()}
    with (run/('guard-'+stage+'-'+str(rep)+'.ndjson')).open('a') as f:f.write(json.dumps(row)+'\n')
    if free<30*1024**3 or mem['MemAvailable']<1536*1024**2 or used>60*1024**3:reason='HOST_RESOURCE_GUARD'
   if schedule_at is None and age>30:reason='INSTRUMENT_PREPARATION_OVER_30S'
   if age>398:reason='STAGE_TIMEOUT_398S_FROM_PROCESS_START'
   if time.time()-json.loads((run/'started-at.json').read_text())['wallTime']>3500:reason='CONFIG_LIFETIME_GUARD_3500S'
   if reason:
    save(run/'disk-guard.json',{'reason':reason,**row});break
   time.sleep(.5)
  if reason:
   os.killpg(cp.pid,signal.SIGTERM)
   try:cp.wait(timeout=2)
   except subprocess.TimeoutExpired:os.killpg(cp.pid,signal.SIGKILL);cp.wait(timeout=5)
  code=cp.wait(timeout=5);result=out/'result.json'
  if code!=0 or not passed(result):reason=reason or 'LOADER_OR_GATE_FAILED'
  receipt={'stage':stage,'rep':rep,'exitCode':code,'passed':reason is None,'stopReason':reason,'elapsedSeconds':time.monotonic()-started,'scheduleDeadlineSeconds':398,'preparationDeadlineSeconds':30,'deadlineOrigin':'loader process start','hostAvailableGuardBytes':1536*1024**2,'diskFreeGuardBytes':30*1024**3,'runBytesGuard':60*1024**3}
 finally:
  if cp.poll() is None:
   os.killpg(cp.pid,signal.SIGKILL);cp.wait(timeout=5)
  log.close()
  if not receipt.get('passed'):
   save(run/'load-failed.json',receipt or {'stopReason':'CONTROLLER_EXCEPTION','stage':stage,'rep':rep});stop(run)
  elif stage=='M' and rep==3:stop(run)
  save(run/('load-controller-'+stage+'-'+str(rep)+'.json'),receipt)
 print(json.dumps(receipt))
 if not receipt.get('passed'):raise RuntimeError('LOAD_STOPPED')

def main():
 p=argparse.ArgumentParser();p.add_argument('action',choices=['prepare','start','status','stop','smoke','run-load']);p.add_argument('--name',required=True);p.add_argument('--engine',choices=['S1','T1'],default='T1');p.add_argument('--index');p.add_argument('--binary');p.add_argument('--stage',choices=['baseline','W','M']);p.add_argument('--rep',type=int,choices=[1,2,3],default=1);a=p.parse_args()
 if not a.name or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in a.name):raise RuntimeError('INVALID_RUN_NAME')
 run=ROOT/'.lab/n1-native-20261117/g3a'/a.name
 if a.action=='prepare':prepare(a,run)
 elif a.action=='start':start(run)
 elif a.action=='stop':stop(run);print('stopped G3a units; receipt saved')
 elif a.action=='status':print(json.dumps({u:state(u) for u in [NEXT,MINIO]}))
 elif a.action=='smoke':smoke(run)
 elif a.action=='run-load':run_load(a,run)
if __name__=='__main__':main()
