import {fork,spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
export const fail=(code,status=503)=>Object.assign(Error(code),{code,status});
const sqliteWorker=fileURLToPath(new URL('./sqlite-worker.mjs',import.meta.url));
const metadataWorker=fileURLToPath(new URL('./metadata-worker.mjs',import.meta.url));
const segmenter=new Intl.Segmenter('zh-Hant',{granularity:'word'});
function tokens(text){const normalized=text.replace(/\p{Script=Han}+/gu,s=>[...segmenter.segment(s)].map(x=>x.segment).join(' '));const ts=normalized.match(/[\p{L}\p{N}\p{M}]+/gu);if(!ts?.length)throw fail('INVALID_QUERY',400);return ts.map(t=>t.toLowerCase());}
export class Pool {
 constructor(descriptor){Object.assign(this,descriptor);this.workers=[];this.queue=[];this.seq=0;this.refs=0;this.closed=false;this.fatal=null;this.timings=[];this.jobs=0;}
 async start(){
  let watchdog;
  try{
   await Promise.race([Promise.all((this.engine==='S1'?['general','general','general','general']:['metadata','metadata','search','search']).map(role=>this.spawn(role))),new Promise((_,reject)=>{watchdog=setTimeout(()=>reject(Error('WORKER_START_TIMEOUT')),30000);})]);
   const check=await this.run('check',{});if(check.some(x=>Object.values(x)[0]!=='ok'))throw Error('SQLITE_CHECK');return this;
  }catch(e){await this.close();throw e;}finally{clearTimeout(watchdog);}
 }
 spawn(role){return new Promise((resolve,reject)=>{
  const child=role!=='search'?fork(role==='general'?sqliteWorker:metadataWorker,[this.metadata],{stdio:['ignore','inherit','inherit','ipc']}):spawn(this.binary,['serve',this.indexDir],{stdio:['pipe','pipe','inherit']});
  const slot={child,role,job:null,ready:false};this.workers.push(slot);
  const poison=error=>{if(!this.closed){this.fatal={error:error.message,role,pid:child.pid};reject(error);void this.close();}};
  const message=m=>{
   if(this.closed)return;
   if(m.ready){if(slot.ready||m.snapshotId!==this.version||(role==='search'&&(m.protocol!=='n1-tantivy-v1'||m.count!==this.count)))return poison(Error('WORKER_VERSION'));slot.ready=true;resolve();return;}
   const job=slot.job;if(!slot.ready||!job||m.id!==job.id)return poison(Error('WORKER_PROTOCOL'));
   clearTimeout(job.timer);slot.job=null;
   if(m.error){job.reject(fail('QUERY_FAILED'));this.dispatch();return;}
   const result=role==='search'?m.value:m.result;
   if(role==='search'&&result?.snapshotId!==this.version){job.reject(fail('WORKER_VERSION'));return poison(Error('WORKER_VERSION'));}
   this.jobs++;this.timings.push({op:job.op,lane:job.input.lane??'internal',queueMs:job.dispatched-job.admitted,workerMs:role==='search'?result.diagnostic?.totalMs:m.workerMs,totalMs:performance.now()-job.admitted});if(this.timings.length>256)this.timings.shift();
   job.resolve(result);this.dispatch();
  };
  if(role!=='search')child.on('message',message);
  else{let buffered='';child.stdout.setEncoding('utf8');child.stdout.on('data',b=>{if(this.closed)return;buffered+=b;if(Buffer.byteLength(buffered)>2*1024*1024)return poison(Error('WORKER_RESPONSE_SIZE'));let at;while((at=buffered.indexOf('\n'))>=0){const line=buffered.slice(0,at);buffered=buffered.slice(at+1);try{message(JSON.parse(line));}catch(e){return poison(e);}}});child.stdin.on('error',poison);}
  child.on('error',poison);child.on('exit',(code,signal)=>{if(!this.closed)poison(Error(`WORKER_EXIT:${code}:${signal}`));});
 });}
 run(op,input){
  if(this.closed||this.fatal)return Promise.reject(fail('WORKER_UNAVAILABLE'));
  if(!['search','page','check'].includes(op))return Promise.reject(fail('UNKNOWN_OP'));
  if(this.queue.length>=16)return Promise.reject(fail('SEARCH_BUSY'));
  return new Promise((resolve,reject)=>{
   const job={id:++this.seq,op,input,resolve,reject,admitted:performance.now(),dispatched:null,timer:null};
   job.timer=setTimeout(()=>{const i=this.queue.indexOf(job);if(i>=0){this.queue.splice(i,1);reject(fail('QUEUE_TIMEOUT'));}else{this.fatal={timeout:true,op,lane:input.lane,queueMs:job.dispatched-job.admitted};reject(fail('QUERY_TIMEOUT'));void this.close();}},op==='check'?30000:4000);
   this.queue.push(job);this.dispatch();
  });
 }
 dispatch(){
  if(this.closed||this.fatal)return;
  for(const slot of this.workers){
   if(!slot.ready||slot.job)continue;
   const at=this.queue.findIndex(j=>slot.role==='general'||(j.op==='search')===(slot.role==='search'));if(at<0)continue;
   const job=this.queue.splice(at,1)[0];slot.job=job;job.dispatched=performance.now();
   try{
    if(slot.role!=='search')slot.child.send({id:job.id,op:job.op,input:job.input});
    else{const input={q:job.input.q,identity:job.input.identity,tags:job.input.tags,contract:'E',...(job.input.spaceId?{spaceId:job.input.spaceId}:{})};slot.child.stdin.write(JSON.stringify({id:job.id,input,tokens:tokens(input.q)})+'\n');}
   }catch(e){clearTimeout(job.timer);slot.job=null;job.reject(e);this.dispatch();}
  }
 }
 metrics(){return {jobs:this.jobs,queued:this.queue.length,busy:this.workers.filter(w=>w.job).length,roles:this.workers.map(w=>({pid:w.child.pid,role:w.role,busy:!!w.job})),timings:this.timings};}
 async close(){
  if(this.closing)return this.closing;this.closed=true;
  this.closing=(async()=>{for(const j of this.queue.splice(0)){clearTimeout(j.timer);j.reject(fail('POOL_CLOSED'));}
   for(const slot of this.workers)if(slot.job){clearTimeout(slot.job.timer);slot.job.reject(fail('POOL_CLOSED'));slot.job=null;}
   await Promise.all(this.workers.map(({child})=>new Promise(resolve=>{if(child.exitCode!==null||child.signalCode!==null)return resolve();const timer=setTimeout(()=>child.kill('SIGKILL'),500);child.once('close',()=>{clearTimeout(timer);resolve();});child.kill('SIGTERM');})));
  })();return this.closing;
 }
}
