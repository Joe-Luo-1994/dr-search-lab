import {DatabaseSync} from 'node:sqlite';
const db=new DatabaseSync(process.argv[2],{readOnly:true});
db.exec('PRAGMA query_only=ON; PRAGMA cache_size=-8192; PRAGMA mmap_size=0;');
const snapshotId=db.prepare('SELECT snapshotId FROM metadata').get().snapshotId;
const pageStmt=db.prepare('SELECT * FROM pages WHERE pageId=?');
const tagsStmt=db.prepare('SELECT tagId FROM page_tags WHERE pageId=? ORDER BY tagId');
const mediaStmt=db.prepare('SELECT * FROM media WHERE mediaId=?');
process.send({ready:true,snapshotId});
process.on('message',({id,op,input})=>{
 const began=performance.now();
 try{
  let result;
  if(op==='check')result=db.prepare('PRAGMA quick_check').all();
  else if(op==='page'){const p=pageStmt.get(input.pageId);result=p?{...p,tagIds:tagsStmt.all(p.pageId).map(t=>t.tagId),media:p.mediaId?mediaStmt.get(p.mediaId):null}:null;}
  else throw Error('UNSUPPORTED_METADATA_OP');
  process.send({id,result,workerMs:performance.now()-began});
 }catch(e){process.send({id,error:e.message,workerMs:performance.now()-began});}
});
process.on('disconnect',()=>{db.close();process.exit(0);});
