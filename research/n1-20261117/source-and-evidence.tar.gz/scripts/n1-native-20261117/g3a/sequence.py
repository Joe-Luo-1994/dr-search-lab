"""Single live WSL process for one already prepared, fresh G3a attempt.
Environment-lifetime fix only. No retry, workload, engine, or resource change.
"""
from pathlib import Path
import argparse, importlib.util, json, os, signal, time
from types import SimpleNamespace

def main():
 p=argparse.ArgumentParser();p.add_argument('--name',required=True);p.add_argument('--engine',choices=['S1','T1'],required=True);a=p.parse_args()
 if not a.name or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in a.name):raise RuntimeError('INVALID_RUN_NAME')
 spec=importlib.util.spec_from_file_location('g3a_controller',Path(__file__).with_name('controller.py'))
 c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
 run=c.ROOT/'.lab/n1-native-20261117/g3a'/a.name
 if not (run/'prepared.json').exists():raise RuntimeError('PREPARE_FRESH_ATTEMPT_FIRST')
 if (run/'ready.json').exists() or any(run.glob('load-*')):raise RuntimeError('FRESH_ATTEMPT_REQUIRED')
 if json.loads((run/'prepared.json').read_text()).get('engine')!=a.engine:raise RuntimeError('PREPARED_ENGINE_MISMATCH')
 if any(c.state(u).get('ActiveState') in ['active','activating','deactivating'] for u in [c.NEXT,c.MINIO]):raise RuntimeError('G3A_UNITS_ALREADY_RUNNING')
 # Exclusive marker prevents accidentally repeating this attempt after any failure.
 with (run/'sequence-start.json').open('x') as f:
  json.dump({'at':time.time(),'pid':os.getpid(),'limitSeconds':3000,'name':a.name,'purpose':'continuous WSL lifetime; no global linger changes'},f)
 began=time.monotonic();rows=[];failure=None;cleanup=None
 def snapshot(label):
  row={'label':label,'at':time.time(),'elapsedSeconds':time.monotonic()-began,'bootId':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'units':{u:c.state(u) for u in [c.NEXT,c.MINIO]}}
  rows.append(row);c.save(run/'sequence-progress.json',{'rows':rows});print(json.dumps({'step':label,'elapsedSeconds':row['elapsedSeconds']}),flush=True)
 def deadline(signum,frame):raise TimeoutError('SEQUENCE_DEADLINE_3000S')
 old=signal.signal(signal.SIGALRM,deadline);signal.alarm(3000)
 try:
  snapshot('before-start');c.start(run);snapshot('ready')
  c.smoke(run);snapshot('smoke-pass')
  stages=[('baseline',1)]+[('W',i) for i in [1,2,3]]+[('M',i) for i in [1,2,3]]
  for stage,rep in stages:
   snapshot('before-'+stage+str(rep))
   c.run_load(SimpleNamespace(stage=stage,rep=rep),run)
   result=json.loads((run/('load-'+stage+'-'+str(rep))/'result.json').read_text())
   if result.get('passed') is not True:raise RuntimeError('STAGE_GATE_FAILED')
   snapshot('passed-'+stage+str(rep))
 except BaseException as e:
  failure={'type':type(e).__name__,'message':str(e)[:300]}
 finally:
  signal.alarm(0)
  # A separately bounded final stop runs even when start, smoke or load failed.
  signal.signal(signal.SIGALRM,lambda s,f:(_ for _ in ()).throw(TimeoutError('CLEANUP_DEADLINE_20S')));signal.alarm(20)
  try:
   c.stop(run);snapshot('finally-stopped');cleanup={'passed':True}
  except BaseException as e:cleanup={'passed':False,'type':type(e).__name__,'message':str(e)[:300]}
  finally:signal.alarm(0);signal.signal(signal.SIGALRM,old)
  receipt={'passed':failure is None and cleanup.get('passed') is True,'elapsedSeconds':time.monotonic()-began,'failure':failure,'cleanup':cleanup,'completedStages':[r['label'] for r in rows if r['label'].startswith('passed-')],'bootIds':sorted(set(r['bootId'] for r in rows)),'environmentFix':'one persistent WSL Python process; previous stop cause remains hypothesis'}
  c.save(run/'sequence-result.json',receipt);print(json.dumps(receipt),flush=True)
 if not receipt['passed']:raise SystemExit(1)
if __name__=='__main__':main()
