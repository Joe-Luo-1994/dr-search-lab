# G3a預載E契約整合

新隔離runtime，未執行／未通過smoke或正式混載。需reviewer讀碼後由主controller執行。保留完整原SQLite、既有Rust binary、Next build與MinIO內容路徑；不修改原runtime／索引。此目錄複製到native新runtime後，CAP_SERVICE_URL指向service.mjs，CAP_CONFIG仍為原storage config加g3a物件。

## Config新增schema（示意，真實path／hash由controller產製）

```json
{
  "g3a": {
    "snapshotId": "v1",
    "metadata": {"path": "/absolute/search.sqlite", "bytes": 0, "sha256": "64-hex"},
    "sourceManifest": {"path": "/absolute/v1/manifest.json", "bytes": 0, "sha256": "64-hex"},
    "binary": {"path": "/absolute/n1-tantivy-reader", "bytes": 0, "sha256": "64-hex"},
    "indexDir": "/absolute/tantivy-index",
    "indexFiles": [{"path": "meta.json", "bytes": 0, "sha256": "64-hex"}]
  }
}
```

indexFiles須列indexDir全部平面檔案，包含meta.json、n1-manifest.json及segment與既有lock檔，不可只列meta.json；拒絕子目錄／symlink／未列檔案。controller在G2結束後才產完整hash清單，避免干擾測量。本次不處理壓縮封裝或MinIO index下載。metadata/sourceManifest/binary逐檔算bytes及SHA；sourceManifest必須是原fixture v1 manifest，其db descriptor須匹配metadata；Tantivy n1-manifest的referenceManifestSha256必須匹配該manifest hash，sourceSHA/count/version皆同。

其餘endpoint、bucket、accessKey/secretKey、eventLog沿原K5私密config，由controller建立，不由本目錄寫入公開檔。cacheDir/release欄位可保留但新service不呼叫download/install。

## 行為

- Startup於Next同quota串流校驗全部artifact，啟動2 metadata Node＋2 Rust search子程序；所有ready/版本一致且SQLite quick_check後才active。
- Tokenization於pool dispatch在Next同quota執行；Rust固定E。spaceId null省略。Response保留snapshotId/dataAsOf(null)/total/hits，剝diagnostic（Rust產生scores成本仍在）。pageId URL與舊API一致。
- 一個aggregate queue，最多16排隊；4秒從admission起算。search/page分派到各2個role slots，總4child，原SQLite4通用worker不同拓撲。讀取多角色PID與cgroup，不能刪掉歸屬驗證。
- 所有request pin同一Pool.version及refs；此版固定V1，update404、hold test hook404。status mode=preloaded-no-update，workers為全部PID，workerDetails列role。
- worker timeout/crash/ready或protocol錯誤使整個pool fail-closed並關閉全部child；沒有自動恢復。controller負責whole-cgroup停止，pool會先TERM、500ms後KILL。
- page/media/SSR授權、MinIO完整hash、backpressure、內容slots4沿K5。原SQLite仍含FTS／正文，全部列資源；Tantivy不套SQLite Top10 ID順序。

## 需要controller／reviewer驗證

先完整metadata/索引source一致與hash receipt，再啟4CPU／8GiB Next unit，MinIO另計；ready檢查四個PID角色與同cgroup。最小smoke為search→page→media、none／unknown／錯Space、Tags、錯version、update404與一個bad descriptor拒絕，之後才W/M。原K5 load包含update，不能直接宣稱整段可沿用；主agent新runner需明示G3a未測更新。

預載hash可能暖OS cache，記startup與steady-state分開，不稱冷啟RTO。G3b仍需index＋metadata整包發布／下載／原子切換／雙role drain；本目錄沒有實作，混載通過也不能視為完整G3。

## Controller and S1 control (not executed)

Run `controller.py prepare --name <unique-name> --engine T1 --index <native-absolute-path> --binary <native-absolute-path>` only AFTER G2 completes (hash/copy work). For S1 omit index/binary. Then use start, smoke, status, stop with the same name. Fixed units/ports require stop before switching configurations. New run refuses overwrite. Private config is not exported.

S1 uses g3a.engine=S1, metadata/sourceManifest descriptors only, four general Node workers. sqlite-worker keeps the original single DB handle and uses rank MATCH bm25(3,1), rank/pageId ordering, nativeScore diagnostics and dataAsOf:null. T1 uses two metadata and two search workers, hence this is a topology comparison. Both retain the complete old SQLite artifact.

Prepare copies existing built .next into the new run (no build), links existing node_modules, reads OLD/fallback-1/config.json privately, and reuses OLD/minio-data/minio.env. Start rejects an already running MinIO on that data directory. Ports3190/19700/19701, Next4CPU8GiB with children and MinIO4CPU4GiB separate;180s startup receipt. Unit lifetime3600s is an upper bound, not a load duration. No public export of credentials.

Controller `run-load --name NAME --stage baseline|W|M --rep N` invokes the sibling g3-load/load.mjs, so invoke controller from the repository source path, not its copied runtime path. External deadline398s starts at loader creation; oracle preparation over30s stops as instrumentation failure, without shortening the60+300s schedule. Host monitoring every5s reuses run-stage guards: available1536MiB, disk free30GiB, N1 run logical bytes60GiB. Failure kills load process group and both units, preserves receipts and prevents continuation. W/M pass leaves the runtime alive for the same baseline; final M3 pass stops. Runtime upper bound3600s plus controller lifetime guard3500s. Load generator/source dependency freezing remains the parent controller's responsibility; prepared.json alone does not freeze every reused Next dependency.
