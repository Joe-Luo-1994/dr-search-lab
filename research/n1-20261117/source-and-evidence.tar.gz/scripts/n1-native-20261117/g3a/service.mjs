import {readFile,mkdir,appendFile,stat,readdir} from 'node:fs/promises';
import path from 'node:path';
import {EventEmitter} from 'node:events';
import {monitorEventLoopDelay,performance} from 'node:perf_hooks';
import {Pool,fail} from './pool.mjs';
import {config,object} from './storage.mjs';
import {verifyPreloaded} from './preloaded.mjs';
let active,initializing,updating=false,contentInFlight=0;const retired=[];
const events=[];
const loop=monitorEventLoopDelay({resolution:20});loop.enable();let lastUtil=performance.eventLoopUtilization();
function metrics(){const current=performance.eventLoopUtilization();const delta=performance.eventLoopUtilization(current,lastUtil);lastUtil=current;
  const eventLoop={p95Ms:loop.percentile(95)/1e6,maxMs:loop.max/1e6,meanMs:loop.mean/1e6,utilization:delta.utilization};loop.reset();return {eventLoop,pool:active.metrics()};}
const emitter=new EventEmitter();
async function event(type,data={}){const e={type,at:Date.now(),...data};events.push(e);const c=await config();await appendFile(c.eventLog,JSON.stringify(e)+'\n');emitter.emit(type,e);}
async function init(){
 if(active)return;
 if(!initializing)initializing=(async()=>{const c=await config();const descriptor=await verifyPreloaded(c);const pool=new Pool(descriptor);await pool.start();active=pool;await event('ready',{snapshotId:pool.version,...descriptor.receipt});})();
 return initializing;
}
function retire(pool){pool.retired=true;retired.push(pool);release(pool);}
function release(pool){if(pool.retired&&pool.refs===0&&!pool.closed){void pool.close().then(()=>event('retired-drained',{version:pool.version}));}}
function json(res,status,value){res.statusCode=status;res.setHeader('content-type','application/json');res.setHeader('cache-control','no-store');res.end(JSON.stringify(value));}
function waitFor(res,event){return new Promise(resolve=>{const done=()=>{res.off(event,done);res.off('close',done);resolve();};res.once(event,done);res.once('close',done);});}
function allow(identity,page){return page&&(identity==='all'||identity==='a'&&page.spaceId==='space0');}
export async function handler(req,res){
  let pinned,contentSlot=false;
  try{
    await init();const c=await config();const url=new URL(req.url,'http://localhost');
    const op=url.pathname.split('/').at(-1);
    if(op==='status'){return json(res,200,{snapshotId:active.version,pid:process.pid,workers:active.workers.map(x=>x.child.pid),queue:active.queue.length,contentInFlight,updating:false,testHooks:false,mode:'preloaded-no-update',workerDetails:active.workers.map(x=>({pid:x.child.pid,role:x.role})),fatal:active.fatal,metrics:metrics(),events:events.slice(-20)});}
    if(op==='update')throw fail('NOT_FOUND',404);
    const identity=req.headers['x-cap-identity'];if(!['all','a','none'].includes(identity))throw fail('AUTHORIZATION_UNKNOWN');
    pinned=active;pinned.refs++;
    if(req.headers['x-cap-hold-until-activation']==='1')throw fail('TEST_HOOK_DISABLED',404);
    if(op==='search'){
      const q=url.searchParams.get('q')??'',spaceId=url.searchParams.get('spaceId'),tags=url.searchParams.getAll('tagId');
      if(!q||q.length>120||tags.length>10)throw fail('INVALID_REQUEST',400);
      const result=await pinned.run('search',{q,spaceId,tags,identity,lane:req.headers['x-cap-lane']??'api'});
      if(result.snapshotId!==pinned.version)throw fail('WORKER_VERSION');
      delete result.diagnostic;
      result.hits.forEach(h=>h.url='/api/capi/page?pageId='+h.pageId+'&version='+pinned.version);
      return json(res,200,{snapshotId:pinned.version,...result});
    }
    if(!['page','media'].includes(op))throw fail('NOT_FOUND',404);
    if(url.searchParams.get('version')!==pinned.version)throw fail('VERSION_MISMATCH',409);
    const page=await pinned.run('page',{pageId:url.searchParams.get('pageId'),lane:req.headers['x-cap-lane']??'api'});
    if(!allow(identity,page))throw fail('NOT_FOUND',404);
    let descriptor;
    if(op==='page'){
      if(!page.bodyKey)throw fail('BODY_NOT_PUBLISHED',503);
      descriptor={key:page.bodyKey,bytes:page.bodyBytes,sha256:page.bodySha};
    }else{
      if(!page.media||page.mediaId!==url.searchParams.get('mediaId'))throw fail('NOT_FOUND',404);
      descriptor=page.media;
    }
    if(contentInFlight>=4)throw fail('CONTENT_BUSY');contentInFlight++;contentSlot=true;
    const bytes=await object(descriptor);
    if(op==='page'){const body=JSON.parse(bytes);if(body.pageId!==page.pageId||body.snapshotId!==pinned.version)throw fail('CONTENT_INTEGRITY');}
    res.statusCode=200;res.setHeader('cache-control','no-store');res.setHeader('content-type',op==='page'?'application/json':descriptor.mimeType);res.setHeader('content-length',bytes.length);
    // Hold admission and version pin through actual socket completion; chunked writes honor backpressure.
    for(let offset=0;offset<bytes.length;offset+=64*1024){if(res.destroyed)break;if(!res.write(bytes.subarray(offset,offset+64*1024)))await waitFor(res,'drain');}
    if(!res.destroyed){const finished=waitFor(res,'finish');res.end();await finished;}
  }catch(e){if(!res.headersSent&&!res.destroyed)json(res,e.status??503,{error:{code:e.code??e.message??'UNAVAILABLE'}});else if(!res.destroyed)res.destroy();}
  finally{if(contentSlot)contentInFlight--;if(pinned){pinned.refs--;release(pinned);}}
}

export async function webModel(identity,pageId,version){
  await init();if(!['all','a','none'].includes(identity))throw fail('AUTHORIZATION_UNKNOWN');
  const pool=active;pool.refs++;let slot=false;
  try{
    if(version&&version!==pool.version)throw fail('VERSION_MISMATCH',409);
    const page=await pool.run('page',{pageId,lane:'web-ssr'});
    if(!allow(identity,page))throw fail('NOT_FOUND',404);
    if(!page.bodyKey)throw fail('BODY_NOT_PUBLISHED');
    if(contentInFlight>=4)throw fail('CONTENT_BUSY');contentInFlight++;slot=true;
    const bytes=await object({key:page.bodyKey,bytes:page.bodyBytes,sha256:page.bodySha});
    const payload=JSON.parse(bytes);if(payload.pageId!==pageId||payload.snapshotId!==pool.version)throw fail('CONTENT_INTEGRITY');
    return {snapshotId:pool.version,pageId,title:page.title,body:payload.body};
  }finally{if(slot)contentInFlight--;pool.refs--;release(pool);}
}

// Controller owns process-group shutdown; exported closure is for bounded smoke teardown.
export async function close(){if(active)await active.close();loop.disable();}
