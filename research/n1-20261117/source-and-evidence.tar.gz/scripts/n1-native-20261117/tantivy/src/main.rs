use std::{cmp::Reverse, error::Error, fs, io::{self, BufRead, BufReader, Read, Write}, path::Path, time::Instant};
use serde_json::{json, Value};
use tantivy::{Index, TantivyDocument, Term, DocId, Score, SegmentReader};
use tantivy::schema::{Schema, Field, TEXT, STRING, STORED, FAST, IndexRecordOption};
use tantivy::schema::Value as TantivyValue;
use tantivy::tokenizer::{PreTokenizedString, Token};
use tantivy::query::{Query, TermQuery, BooleanQuery, Occur, BoostQuery, ConstScoreQuery, EmptyQuery};
use tantivy::collector::{Count, TopDocs};

type Result<T> = std::result::Result<T, Box<dyn Error>>;
const MAX_LINE: usize = 2 * 1024 * 1024;
#[derive(Clone, Copy)]
struct Fields { title: Field, body: Field, space: Field, tags: Field, rank: Field, payload: Field }
fn schema() -> (Schema, Fields) {
    let mut s = Schema::builder();
    let fields = Fields { title:s.add_text_field("title",TEXT), body:s.add_text_field("body",TEXT),
        space:s.add_text_field("space",STRING), tags:s.add_text_field("tags",STRING),
        rank:s.add_u64_field("page_lex_rank",FAST), payload:s.add_text_field("payload",STORED) };
    (s.build(),fields)
}
fn strings(v: &Value) -> Result<Vec<String>> {
    v.as_array().ok_or("EXPECTED_ARRAY")?.iter().map(|x| x.as_str().map(str::to_owned).ok_or_else(||"EXPECTED_STRING".into())).collect()
}
fn tokenized(tokens: Vec<String>) -> PreTokenizedString {
    let mut text=String::new(); let mut out=Vec::new();
    for (position,term) in tokens.into_iter().enumerate() {
        if !text.is_empty(){text.push(' ');}
        let offset_from=text.len();text.push_str(&term);
        out.push(Token{offset_from,offset_to:text.len(),position,text:term,position_length:1});
    }
    PreTokenizedString{text,tokens:out}
}
fn line(reader: &mut impl BufRead) -> Result<Option<String>> {
    let mut bytes=Vec::new();
    let n=reader.take((MAX_LINE+1) as u64).read_until(b'\n',&mut bytes)?;
    if n==0{return Ok(None)}
    if bytes.len()>MAX_LINE{return Err("LINE_TOO_LARGE".into())}
    Ok(Some(String::from_utf8(bytes)?))
}
fn emit(v:Value)->Result<()> { let mut o=io::stdout().lock();serde_json::to_writer(&mut o,&v)?;o.write_all(b"\n")?;o.flush()?;Ok(()) }
fn build(dir:&Path,input:&Path)->Result<()> {
    if dir.exists(){return Err("OUTPUT_EXISTS".into())} fs::create_dir_all(dir)?;
    let mut source=BufReader::new(fs::File::open(input)?);
    let manifest:Value=serde_json::from_str(&line(&mut source)?.ok_or("NO_MANIFEST")?)?;
    if manifest["kind"]!="manifest"||manifest["protocol"]!="n1-tantivy-v1"||manifest["tantivy"]!="0.27.0"{return Err("MANIFEST_MISMATCH".into())}
    let (s,f)=schema();let index=Index::create_in_dir(dir,s)?;
    let mut writer=index.writer_with_num_threads(1,64_000_000)?;
    let mut count=0usize;
    while let Some(raw)=line(&mut source)? {
        let row:Value=serde_json::from_str(&raw)?;
        if row["kind"]!="page"{return Err("EXPECTED_PAGE".into())}
        let p=&row["page"];let mut doc=TantivyDocument::default();
        doc.add_pre_tokenized_text(f.title,tokenized(strings(&row["titleTokens"])?));
        doc.add_pre_tokenized_text(f.body,tokenized(strings(&row["bodyTokens"])?));
        doc.add_text(f.space,p["spaceId"].as_str().ok_or("SPACE_MISSING")?);
        for tag in strings(&p["tags"])? {doc.add_text(f.tags,tag);}
        doc.add_u64(f.rank,row["lexRank"].as_u64().ok_or("RANK_MISSING")?);
        let content=p["content"].as_str().ok_or("CONTENT_MISSING")?;
        let mut tags=strings(&p["tags"])?;tags.sort();tags.dedup();
        let payload=json!({"pageId":p["pageId"],"spaceId":p["spaceId"],"title":p["title"],
            "snippet":content.chars().take(160).collect::<String>(),"tagIds":tags});
        doc.add_text(f.payload,payload.to_string());writer.add_document(doc)?;count+=1;
    }
    writer.commit()?;writer.wait_merging_threads()?;
    if manifest["count"].as_u64()!=Some(count as u64){return Err("COUNT_MISMATCH".into())}
    fs::write(dir.join("n1-manifest.json"),serde_json::to_vec_pretty(&manifest)?)?;
    emit(json!({"built":true,"count":count,"manifest":manifest}))
}
fn term(field:Field,text:&str)->Box<dyn Query> {Box::new(TermQuery::new(Term::from_field_text(field,text),IndexRecordOption::WithFreqs))}
fn query(input:&Value,tokens:&Value,f:Fields)->Result<Box<dyn Query>> {
    let identity=input["identity"].as_str().ok_or("UNKNOWN_IDENTITY")?;
    if !["all","a","none"].contains(&identity){return Err("UNKNOWN_IDENTITY".into())}
    if ![Some("E"),Some("L")].contains(&input["contract"].as_str()){return Err("INVALID_CONTRACT".into())}
    let tags=strings(&input["tags"]).map_err(|_|"INVALID_TAGS")?;
    if tags.len()>32{return Err("INVALID_TAGS".into())}
    if input.get("spaceId").is_some() && input["spaceId"].as_str().is_none_or(str::is_empty){return Err("INVALID_SPACE".into())}
    let words=strings(tokens).map_err(|_|"INVALID_QUERY")?;
    if words.is_empty()||words.len()>512||words.iter().any(|w|w.is_empty()||w.len()>4096){return Err("INVALID_QUERY".into())}
    if identity=="none"{return Ok(Box::new(EmptyQuery))}
    let mut clauses:Vec<(Occur,Box<dyn Query>)>=Vec::new();
    for word in words {
        let fields=vec![(Occur::Should,Box::new(BoostQuery::new(term(f.title,&word),3.0)) as Box<dyn Query>),
            (Occur::Should,term(f.body,&word))];
        clauses.push((Occur::Must,Box::new(BooleanQuery::new(fields))));
    }
    let mut filters=Vec::new();
    if identity=="a"{filters.push((Occur::Must,term(f.space,"space0")));}
    if let Some(space)=input["spaceId"].as_str(){filters.push((Occur::Must,term(f.space,space)));}
    for tag in tags{filters.push((Occur::Must,term(f.tags,&tag)));}
    if !filters.is_empty(){clauses.push((Occur::Must,Box::new(ConstScoreQuery::new(Box::new(BooleanQuery::new(filters)),0.0))));}
    Ok(Box::new(BooleanQuery::new(clauses)))
}
fn serve(dir:&Path)->Result<()> {
    let manifest:Value=serde_json::from_slice(&fs::read(dir.join("n1-manifest.json"))?)?;
    if manifest["protocol"]!="n1-tantivy-v1"||manifest["tantivy"]!="0.27.0"{return Err("MANIFEST_MISMATCH".into())}
    let index=Index::open_in_dir(dir)?;let (s,f)=schema();if index.schema()!=s{return Err("SCHEMA_MISMATCH".into())}
    let reader=index.reader()?;let searcher=reader.searcher();
    if manifest["count"].as_u64()!=Some(searcher.num_docs()){return Err("COUNT_MISMATCH".into())}
    emit(json!({"ready":true,"protocol":"n1-tantivy-v1","snapshotId":manifest["snapshotId"],"count":searcher.num_docs()}))?;
    let mut stdin=io::stdin().lock();
    while let Some(raw)=line(&mut stdin)? {
        let request:Value=serde_json::from_str(&raw)?;let id=request.get("id").cloned().ok_or("ID_REQUIRED")?;
        let result=(||->Result<Value>{
            let began=Instant::now();let q=query(&request["input"],&request["tokens"],f)?;
            let exact=request["input"]["contract"]=="E";
            let (total,hits)=if exact {
                let top=TopDocs::with_limit(10).tweak_score(|segment:&SegmentReader| {
                    let ranks=segment.fast_fields().u64("page_lex_rank").expect("validated rank field").first_or_default_col(0);
                    move |doc:DocId,score:Score| (score,Reverse(ranks.get_val(doc)))
                });
                let (count,values)=searcher.search(&*q,&(Count,top))?;
                (Some(count),values.into_iter().map(|((score,_),addr)|(score,addr)).collect::<Vec<_>>())
            }else{(None,searcher.search(&*q,&TopDocs::with_limit(10).order_by_score())?)};
            let mut output=Vec::new();let mut scores=Vec::new();
            for (score,addr) in hits {
                let doc:TantivyDocument=searcher.doc(addr)?;
                let payload:Value=serde_json::from_str(doc.get_first(f.payload).and_then(|v|v.as_str()).ok_or("PAYLOAD_MISSING")?)?;
                scores.push(json!({"pageId":payload["pageId"],"score":score}));output.push(payload);
            }
            let mut value=json!({"snapshotId":manifest["snapshotId"],"dataAsOf":manifest["dataAsOf"],"hits":output,
                "diagnostic":{"variant":"T1","contract":request["input"]["contract"],"tokens":request["tokens"],"nativeScores":scores,"totalMs":began.elapsed().as_secs_f64()*1000.0}});
            if let Some(n)=total{value["total"]=json!(n)} Ok(value)
        })();
        match result {Ok(value)=>emit(json!({"id":id,"value":value}))?,Err(e)=>emit(json!({"id":id,"error":e.to_string()}))?}
    } Ok(())
}
fn main()->Result<()> {
    let args:Vec<String>=std::env::args().collect();
    match args.get(1).map(String::as_str) {
        Some("build") if args.len()==4=>build(Path::new(&args[2]),Path::new(&args[3])),
        Some("serve") if args.len()==3=>serve(Path::new(&args[2])),
        _=>Err("Usage: n1-tantivy-reader build NEW_INDEX INPUT_JSONL | serve INDEX".into())
    }
}
