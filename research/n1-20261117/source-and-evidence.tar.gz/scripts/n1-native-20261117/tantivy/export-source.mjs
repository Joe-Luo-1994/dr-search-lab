import {mkdir,readFile,writeFile,appendFile} from 'node:fs/promises';
import {createWriteStream} from 'node:fs';
import {once} from 'node:events';
import {finished} from 'node:stream/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {source,pageId,seed,sourceContract} from '../../c-million-20261116/source.mjs';
import {normalize} from '../sqlite/adapter.mjs';

const [outArg,countArg,version,referenceArg]=process.argv.slice(2),count=Number(countArg);
if(!referenceArg||!outArg||!Number.isSafeInteger(count)||count<123||count>1000000||!['v1','v2'].includes(version))throw Error('Usage: node export-source.mjs NEW_OUTDIR COUNT v1|v2 FROZEN_SOURCE_MANIFEST');
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const sourceBytes=await readFile(new URL('../../c-million-20261116/source.mjs',import.meta.url));
const referenceBytes=await readFile(referenceArg),reference=JSON.parse(referenceBytes);
if(reference.sourceSha256!==hash(sourceBytes)||reference.snapshotId!==version||reference.count!==count+(version==='v2'?1:0)||reference.sourceContract!==sourceContract||reference.seed!==seed)throw Error('FROZEN_SOURCE_MANIFEST_MISMATCH');
const out=path.resolve(outArg);await mkdir(out);
const start=performance.now(),actualCount=count+(version==='v2'?1:0);
// Explicit lexical mapping: numeric i is incorrect at the six/seven-digit boundary.
const lexical=Array.from({length:actualCount},(_,i)=>pageId(i+1)).sort();
const ranks=new Map(lexical.map((id,i)=>[id,i]));
const manifest={kind:'manifest',protocol:'n1-tantivy-v1',snapshotId:version,dataAsOf:null,count:actualCount,
  seed,sourceContract,sourceSha256:hash(sourceBytes),referenceManifestSha256:hash(referenceBytes),tantivy:'0.27.0',
  tokenization:'shared Node Segmenter zh-Hant on Han runs; Unicode L/N/M runs lowercased; controlled fixture only',
  node:process.version,icu:process.versions.icu,lexRank:'ascending JavaScript string pageId, unique ordinal'};
const stream=createWriteStream(path.join(out,'source.jsonl'),{flags:'wx'}),digest=createHash('sha256');
let rows=0,bytes=0,failure=null,streamError=null;stream.on('error',e=>{streamError=e;});
const emit=async value=>{if(streamError)throw streamError;const b=Buffer.from(JSON.stringify(value)+'\n');digest.update(b);bytes+=b.length;if(!stream.write(b))await once(stream,'drain');};
const tokens=text=>(normalize(text).match(/[\p{L}\p{N}\p{M}]+/gu)??[]).map(t=>t.toLowerCase());
try{
 await emit(manifest);
 for(let i=1;i<=actualCount;i++){
  const page=source(i,version,count);await emit({kind:'page',page,lexRank:ranks.get(page.pageId),titleTokens:tokens(page.title),bodyTokens:tokens(page.content)});rows++;
  if(i%10000===0)await appendFile(path.join(out,'progress.ndjson'),JSON.stringify({at:new Date().toISOString(),rows,bytes,elapsedMs:performance.now()-start})+'\n');
 }
 stream.end();await finished(stream);
}catch(e){failure={message:e.message,stack:e.stack};stream.destroy();}
const inputHashes={};for(const n of ['export-source.mjs','../sqlite/adapter.mjs'])inputHashes[n]=hash(await readFile(new URL(n,import.meta.url)));
const receipt={passed:!failure,manifest,inputHashes,rows,bytes,sha256:digest.digest('hex'),elapsedMs:performance.now()-start,failure,
 scope:'Streaming deterministic frozen source reproduction; no benchmark or production tokenization claim; parent controls resource/deadline limits'};
await writeFile(path.join(out,'export-receipt.json'),JSON.stringify(receipt,null,2));console.log(JSON.stringify({passed:receipt.passed,rows,bytes,sha256:receipt.sha256,out,failure}));if(failure)process.exitCode=1;
