# N1 Tantivy G1 adapter

2026-11-17。目前僅程式完成及兩個Node腳本語法檢查；Rust尚未編譯或執行，不宣稱G1通過。

由主agent使用隔離Rust工具鏈與4CPU／8GiB controller執行。Cargo依賴Tantivy exact 0.27.0；首次解析後保留Cargo.lock並使用--locked，不修改共用工具鏈。

1. `node export-golden.mjs NEW_EXPORT`：沿用 `../sqlite/golden-fixture.mjs` 的同一套pages／cases，產生source.jsonl與fixture.json；不覆寫既有輸出。
2. 外部受控 `cargo build --release`（首次產lock）／後續 `cargo build --release --locked`。
3. `BINARY build NEW_INDEX NEW_EXPORT/source.jsonl`：單builder thread、64MB writer buffer，原生merge完成後輸出manifest。
4. `node golden.mjs BINARY INDEX EXPORT/fixture.json NEW_RESULT`：每request外部4秒截止，ready10秒；結束要求child關閉，3秒仍未結束則kill。結果寫result.json，不覆寫。

JSONL IPC：request `{id,input:{q,identity,tags,spaceId?,contract},tokens}`；response `{id,value}`或`{id,error}`；首行ready。tokens由可信Node adapter提供，不是對外API。Rust不解析q語法；typed AND query跨title/body，title score boost3/body1；Space／Tags filter包零分ConstScoreQuery。E=(Count,TopDocs tweak_score(score,Reverse(page lexical rank)))；L只nativeTopDocs，同分DocAddress不保證跨版本穩定。page lexical rank由實際字串排序產生，非numeric i。

儲存title/body的預分詞倒排資料與必要回應payload（title／160字摘要／tags／IDs），不store完整正文。尚未整合正式metadata、閱讀／下載／MinIO更新，不可直接進G3。

使用共用queryTokens與normalize只使輸入一致，**不是獨立tokenizer parity證明**。SQLite agent另核實際FTS詞項；Rust PreTokenizedString的text使用tokens join，offset對應該衍生字串，不用來聲稱原文highlight正確。BM25權重與SQLite不同公式，僅比較必要任務。共享fixture中PDF案例為手工抽取文字，非真PDF extraction流程。

Top10-cutoff測試覆蓋>10同分及六／七位pageId的E lexical順序；本builder自然產生的segment數未知，**未強制跨segment tie案例**。需檢查index metadata，若只有單segment，不能聲稱跨segment已驗。

成本：新增Rust crate／lockfile／binary封裝、typed query adapter、IPC deadline與程序生命週期、schema／token版本。G1 wrapper為研究工具，不算正式production supervisor已完成。外部超時kill會失去該process全部在途工作，因此初版單process只接受一筆在途request。尚未驗自動restart、慢query故障注入、跨version index拒絕與G3併發。

Reviewer修正：即使全部request斷言通過，reader最後非零exit或收到signal（包括cleanup被迫SIGKILL）仍令整份G1報告失敗。此次只改Node runner，不改已凍結Rust。

主agent回報build1已保留失敗：Rust1.88無法滿足本次lock解析出的ordered-float（需1.90）／uuid（需1.89）。後續以同Cargo.lock、隔離Rust1.90執行build2，這是工具鏈相容性調整，不能刪除build1紀錄或稱頂層MSRV足以保證依賴相容。

控制器建議順序（本agent未執行）：先export小fixture到全新attempt目錄；再以4CPU／8GiB及外部deadline呼叫binary build；成功後讀index/meta.json記錄segments陣列長度、每段num_docs及segment_id，另hash整份meta。只有segments>=2才可能支持跨segment觀察，仍需核對tie文件確實分散；只看到多segment不能直接稱跨segment tie已驗。最後以外部總deadline包住Node golden runner，保留build stdout/stderr、reader result.json、runner exit與controller timeout receipt。Node使用本輪鎖定的22.18.0，不沿用Windows預設版本。

## G2 streaming與單次screen（未執行）

`node export-source.mjs NEW_EXPORT 1000000 v1 FROZEN_V1_MANIFEST` 先核source.mjs SHA、seed、sourceContract、版本與count，串流產生含預分詞的source.jsonl；不讀搜尋結果產製語料。記錄完整輸出hash／bytes／rows及10k進度。lexRank以pageId字串排序計算，不用numeric i。輸出保留正文以供已凍結builder產摘要，可能數GB，需計入producer磁碟上限。

`node screen.mjs BINARY INDEX NEW_RESULT 1000000 v1 E` 是21題各一次的篩選，不是正式G2 block或SLO。只在決策允許時另建新attempt以L跑，不在E失敗後自動改契約重試。沿用SQLite probe-v2 parent／systemd模式及同probe-cases：parent先在reader配額外計算獨立expected counts；systemd reader直接啟動既有Rust binary，4CPU／8GiB／swap0／10min；讀回MainPID、cgroup、limits並確認parent不在reader cgroup。每query4秒timeout時stop unit且核PID消失，失敗停止整份screen。回應metadata／snippet／tags從source rules驗，不拿SQLite結果作排名oracle。

此screen只確認index/meta.json的size／mtime未變；完整source/index／binary凍結hash由主controller取得。before-stop記cpu.stat／memory.peak／memory.events供診斷，不能用單次查詢報P95。主controller仍須提供host memory／disk監控、全attempt外部deadline及輸出保存，不在reader cgroup執行O(21N) oracle。Rust binary未因screen修改。

Screen reviewer修正：systemd明設並讀回`TimeoutStopSec=2s`／`KillMode=control-group`；stdout／error／exit callbacks先核對active process，避免舊wrapper退出事件污染新工作。query timeout先寫`query.deadline`（4秒與實際觀察時間），再stop；cleanupMs獨立記錄，不把停止程序時間算成query latency。這只改screen研究工具，不改已build Rust或執行中的百萬builder。
