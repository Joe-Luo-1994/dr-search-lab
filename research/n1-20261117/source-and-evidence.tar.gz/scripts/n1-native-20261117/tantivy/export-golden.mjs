import {mkdir,writeFile,readFile} from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {pages,cases,tokenCases,snapshotId,dataAsOf} from '../sqlite/golden-fixture.mjs';
import {normalize,queryTokens} from '../sqlite/adapter.mjs';
if(!process.argv[2])throw Error('Usage: node export-golden.mjs NEW_DIRECTORY');
const out=path.resolve(process.argv[2]);await mkdir(out);
const all=[...pages];
const sorted=all.map(p=>p.pageId).sort();
if(new Set(sorted).size!==sorted.length)throw Error('DUPLICATE_PAGE');
const manifest={kind:'manifest',protocol:'n1-tantivy-v1',snapshotId,dataAsOf,count:all.length,
  tokenizer:'shared Node Segmenter + lowercase letter-number-mark tokens; actual SQLite parity must be separately verified',
  node:process.version,icu:process.versions.icu,tantivy:'0.27.0'};
const tokens=text=>(normalize(text).match(/[\p{L}\p{N}\p{M}]+/gu)??[]).map(t=>t.toLowerCase());
const records=all.map(page=>({kind:'page',page,lexRank:sorted.indexOf(page.pageId),titleTokens:tokens(page.title),bodyTokens:tokens(page.content)}));
await writeFile(path.join(out,'source.jsonl'),[manifest,...records].map(x=>JSON.stringify(x)+'\n').join(''));
const testCases=cases.map(c=>({...c,tokens:(()=>{try{return queryTokens(c.input.q)}catch{return []}})()}));
await writeFile(path.join(out,'fixture.json'),JSON.stringify({manifest,pages:all,cases:testCases,tokenCases},null,2));
const hashes={};for(const n of ['../sqlite/golden-fixture.mjs','../sqlite/adapter.mjs','export-golden.mjs'])hashes[n]=createHash('sha256').update(await readFile(new URL(n,import.meta.url))).digest('hex');
await writeFile(path.join(out,'export-receipt.json'),JSON.stringify({manifest,hashes,scope:'small synthetic G1 only; shared tokenizer is not independent token parity proof'},null,2));
console.log(JSON.stringify({out,count:all.length,cases:testCases.length}));
