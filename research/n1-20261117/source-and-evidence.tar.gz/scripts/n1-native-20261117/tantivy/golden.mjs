import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
const [binary,index,fixturePath,outArg]=process.argv.slice(2);
if(!outArg)throw Error('Usage: node golden.mjs BINARY INDEX FIXTURE_JSON NEW_OUTPUT');
const out=path.resolve(outArg);await mkdir(out);const fixture=JSON.parse(await readFile(fixturePath,'utf8'));
const child=spawn(binary,['serve',index],{stdio:['pipe','pipe','pipe']});
const results=[];let stderr='',failure=null,seq=0,pending=null,readyResolve,readyReject,ready=false;
const exited=new Promise(resolve=>child.once('close',(code,signal)=>resolve({code,signal})));
const readyPromise=new Promise((resolve,reject)=>{readyResolve=resolve;readyReject=reject;});
const timer=setTimeout(()=>{child.kill('SIGKILL');readyReject(Error('READY_TIMEOUT'));},10000);
child.stderr.on('data',b=>{if(stderr.length<65536)stderr+=b.toString().slice(0,65536-stderr.length);});
child.on('error',e=>{readyReject(e);pending?.reject(e);});
child.on('exit',()=>{if(!ready)readyReject(Error('EARLY_EXIT'));if(pending)pending.reject(Error('READER_EXIT'));});
const rl=createInterface({input:child.stdout});
rl.on('line',line=>{
 try{
  if(line.length>2*1024*1024)throw Error('RESPONSE_TOO_LARGE');const row=JSON.parse(line);
  if(!ready){assert.equal(row.ready,true);assert.equal(row.snapshotId,fixture.manifest.snapshotId);ready=true;clearTimeout(timer);readyResolve(row);return;}
  if(!pending||row.id!==pending.id)throw Error('UNEXPECTED_RESPONSE');const p=pending;pending=null;clearTimeout(p.timer);p.resolve(row);
 }catch(e){child.kill('SIGKILL');readyReject(e);pending?.reject(e);}
});
async function request(input,tokens){
 assert.equal(pending,null);const id=++seq;
 return new Promise((resolve,reject)=>{pending={id,resolve,reject,timer:setTimeout(()=>{child.kill('SIGKILL');const p=pending;pending=null;p?.reject(Error('QUERY_TIMEOUT'));},4000)};
 child.stdin.write(JSON.stringify({id,input,tokens})+'\n');});
}
try{
 await readyPromise;
 for(const contract of ['E','L'])for(const c of fixture.cases){
  const response=await request({...c.input,contract},c.tokens);results.push({contract,id:c.id,response});
  if(c.error){assert.equal(response.error,c.error,c.id);continue;}
  assert.equal(response.error,undefined,c.id);const value=response.value;const ids=value.hits.map(h=>h.pageId);
  assert.equal(value.snapshotId,fixture.manifest.snapshotId);assert.equal(value.dataAsOf,fixture.manifest.dataAsOf);
  const eligible=c.eligible??c.expected;
  assert.equal(ids.length,Math.min(10,eligible.length));assert.ok(ids.every(id=>eligible.includes(id)),c.id);assert.equal(new Set(ids).size,ids.length);
  if(eligible.length<=10)assert.deepEqual([...ids].sort(),[...eligible].sort(),c.id);
  if(c.expectedOrder)assert.deepEqual(ids,c.expectedOrder,c.id);
  if(c.expectedOrderByContract?.[contract])assert.deepEqual(ids,c.expectedOrderByContract[contract],c.id);
  const scores=value.diagnostic.nativeScores.map(x=>x.score);assert.ok(scores.every(Number.isFinite));
  for(let i=1;i<scores.length;i++)assert.ok(scores[i-1]>=scores[i],'Tantivy score descending');
  if(c.id==='title-boost')assert.ok(scores[0]>scores[1],'strict title boost');
  if(contract==='E')assert.equal(value.total,eligible.length);else assert.equal(Object.hasOwn(value,'total'),false);
  if(c.id==='same-score'&&contract==='E')assert.deepEqual(ids,['g11','g12']);
  for(const hit of value.hits){const p=fixture.pages.find(p=>p.pageId===hit.pageId);assert.equal(hit.title,p.title);assert.equal(hit.spaceId,p.spaceId);assert.equal(hit.snippet,Array.from(p.content).slice(0,160).join(''));assert.deepEqual(hit.tagIds,[...p.tags].sort());}
 }
}catch(e){failure={message:e.message,stack:e.stack};}
finally{clearTimeout(timer);if(pending)clearTimeout(pending.timer);child.stdin.end();const stop=setTimeout(()=>child.kill('SIGKILL'),3000);await exited;clearTimeout(stop);rl.close();}
const exit=await exited;
// Passing requests do not excuse a crash or forced cleanup at shutdown.
if(!failure&&(exit.code!==0||exit.signal!==null))failure={message:'UNCLEAN_READER_EXIT',exit};
const report={passed:!failure,scope:'G1 small shared synthetic fixture; not capacity or token parity proof',node:process.version,attempts:results.length,results,failure,exit,stderr};
await writeFile(path.join(out,'result.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({passed:report.passed,attempts:results.length,out,failure}));if(failure)process.exitCode=1;
