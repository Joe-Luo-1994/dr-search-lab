// Adapted from SQLite probe-v2; same parent-outside-cgroup/oracle/stop pattern.
import {spawn,execFileSync} from 'node:child_process';
import readline from 'node:readline';
import {mkdir,writeFile,stat,readFile} from 'node:fs/promises';
import {appendFileSync,readFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import assert from 'node:assert/strict';
import {probes,matches} from '../sqlite/probe-cases.mjs';
import {queryTokens} from '../sqlite/adapter.mjs';
import {source} from '../../c-million-20261116/source.mjs';

const [binary,index,output,countText='1000000',version='v1',contract='E']=process.argv.slice(2),count=Number(countText);
const database=path.join(index??'', 'meta.json');
if(!binary||!index||!output||!['E','L'].includes(contract)||!Number.isSafeInteger(count)||count<123||count>1000000||!['v1','v2'].includes(version))throw Error('Usage: node screen.mjs BINARY INDEX NEW_OUTDIR [COUNT] [v1|v2] [E|L]');
const out=path.resolve(output);await mkdir(out);const initial=await stat(database),cases=probes(count,version);
const records=[],plans=[],units=[],counts=Object.fromEntries(cases.map(q=>[q.id,0]));
const log=e=>{records.push(e);appendFileSync(path.join(out,'raw.ndjson'),JSON.stringify({at:new Date().toISOString(),...e})+'\n');};
const oracleStart=performance.now();
// Parent executes independent O(21N) oracle outside all reader cgroups.
for(let i=1;i<=count+(version==='v2'?1:0);i++)for(const q of cases)if(matches(q,i,count,version))counts[q.id]++;
await writeFile(path.join(out,'frozen-cases.json'),JSON.stringify({count,version,cases,counts,oracleMs:performance.now()-oracleStart,parentPid:process.pid,parentCgroup:readFileSync('/proc/self/cgroup','utf8')},null,2));
let active=null,pending=null,sequence=0,failure=null,context=null;
function systemctl(args){return execFileSync('systemctl',['--user',...args],{encoding:'utf8',timeout:15000});}
function properties(unit){const raw=systemctl(['show',unit,'--property=MainPID,ControlGroup,ActiveState,CPUQuotaPerSecUSec,MemoryMax,MemorySwapMax,RuntimeMaxUSec,TimeoutStopUSec,KillMode']);return Object.fromEntries(raw.trim().split('\n').map(s=>{const i=s.indexOf('=');return[s.slice(0,i),s.slice(i+1)];}));}
function stop(){
 if(!active)return;
 const a=active;active=null;const cleanupStarted=performance.now();
 try{const state=properties(a.unit),resources={};for(const file of ['cpu.stat','memory.peak','memory.events']){const p='/sys/fs/cgroup'+state.ControlGroup+'/'+file;if(existsSync(p))resources[file]=readFileSync(p,'utf8');}log({event:'resources.before-stop',unit:a.unit,state,resources});}catch(e){log({event:'resources.unavailable',unit:a.unit,message:e.message});}
 try{systemctl(['stop',a.unit]);}catch(e){log({event:'cleanup.stop.error',unit:a.unit,message:e.message});}
 let state;try{state=properties(a.unit);}catch(e){state={readbackError:e.message};}
 const alive=a.pid?existsSync('/proc/'+a.pid):null;
 const clean=!alive&&state.MainPID==='0'&&['inactive','failed'].includes(state.ActiveState);
 const receipt={unit:a.unit,pid:a.pid,state,alive,clean,cleanupMs:performance.now()-cleanupStarted};units.push(receipt);log({event:'cleanup',...receipt});
 a.process.stdin.destroy();
 if(!clean)throw Error('CLEANUP_NOT_VERIFIED:'+a.unit);
}
async function start(variant,contract){
 const unit=`dr-n1-tantivy-screen-${process.pid}-${variant.toLowerCase()}-${contract.toLowerCase()}`;
 const cp=spawn('systemd-run',['--user','--wait','--pipe','--unit='+unit,'-p','CPUQuota=400%','-p','MemoryMax=8589934592','-p','MemorySwapMax=0','-p','RuntimeMaxSec=600','-p','TasksMax=128','-p','TimeoutStopSec=2s','-p','KillMode=control-group',path.resolve(binary),'serve',path.resolve(index)],{stdio:['pipe','pipe','pipe']});
 active={unit,process:cp,pid:null};
 let resolveReady,rejectReady;const ready=new Promise((r,j)=>{resolveReady=r;rejectReady=j;});
 const timer=setTimeout(()=>rejectReady(Error('READY_TIMEOUT')),15000);
 cp.stderr.on('data',b=>appendFileSync(path.join(out,unit+'.stderr.log'),b));
 readline.createInterface({input:cp.stdout}).on('line',line=>{if(active?.process!==cp)return;let m;try{m=JSON.parse(line);}catch{rejectReady(Error('BAD_JSONL'));if(pending){clearTimeout(pending.timer);pending.reject(Error('BAD_JSONL'));pending=null;}return;}
  if(m.ready){clearTimeout(timer);resolveReady(m);return;}
  if(pending&&m.id===pending.id){const p=pending;pending=null;clearTimeout(p.timer);m.error?p.reject(Error(m.error)):p.resolve(m.value);}
 });
 cp.on('error',e=>{clearTimeout(timer);if(active?.process!==cp)return;rejectReady(e);if(pending){clearTimeout(pending.timer);pending.reject(e);pending=null;}});
 cp.on('exit',(code,signal)=>{clearTimeout(timer);if(active?.process!==cp)return;const e=Error(`SYSTEMD_RUN_EXIT:${code}:${signal}`);rejectReady(e);if(pending){clearTimeout(pending.timer);pending.reject(e);pending=null;}});
 const info=await ready;assert.equal(info.snapshotId,version);assert.equal(info.count,count+(version==='v2'?1:0));
 const state=properties(unit);info.pid=Number(state.MainPID);assert.ok(info.pid>0);active.pid=info.pid;
 const membership=readFileSync(`/proc/${info.pid}/cgroup`,'utf8'),parent=readFileSync('/proc/self/cgroup','utf8');
 log({event:'ready',variant,contract,unit,...info,state,membership,parent});
 assert.equal(state.MainPID,String(info.pid));assert.equal(state.ActiveState,'active');assert.equal(state.CPUQuotaPerSecUSec,'4s');assert.equal(state.MemoryMax,'8589934592');assert.equal(state.MemorySwapMax,'0');assert.equal(state.RuntimeMaxUSec,'10min');
 assert.equal(state.TimeoutStopUSec,'2s');assert.equal(state.KillMode,'control-group');
 assert.ok(membership.trim().split('\n').some(line=>line==='0::'+state.ControlGroup),'child outside unit');
 assert.ok(!parent.trim().split('\n').some(line=>line==='0::'+state.ControlGroup),'parent inside reader quota');
}
function request(input,explain=false){return new Promise((resolve,reject)=>{
 const id=++sequence,started=performance.now(),timer=setTimeout(()=>{pending=null;log({event:'query.deadline',id,queryId:input.id,deadlineMs:4000,observedUntilDeadlineMs:performance.now()-started,excludesCleanup:true});let cleanupError;try{stop();}catch(e){cleanupError=e.message;}reject(Error('QUERY_DEADLINE_4000MS'+(cleanupError?':'+cleanupError:'')));},4000);
 pending={id,timer,resolve,reject};active.process.stdin.write(JSON.stringify({id,input,tokens:queryTokens(input.q)})+'\n');
});}
const variant='T1';
try{
 {
  context={variant,contract,phase:'ready'};await start(variant,contract);
  for(const q of cases){context={variant,contract,queryId:q.id,phase:'search'};const input={...q,contract};log({event:'query.begin',...context});const start=performance.now();
   const result=await request(input),roundTripMs=performance.now()-start;log({event:'query.result',...context,roundTripMs,result});
   const ids=result.hits.map(h=>h.pageId);assert.equal(result.snapshotId,version);assert.equal(new Set(ids).size,ids.length);assert.equal(ids.length,Math.min(10,counts[q.id]));
   if(contract==='E')assert.equal(result.total,counts[q.id]);else assert.equal(Object.hasOwn(result,'total'),false);
   for(const h of result.hits){const i=Number(h.pageId.slice(1));assert.ok(i>=1&&i<=count+(version==='v2'?1:0));assert.ok(matches(q,i,count,version),q.id+':ineligible');const p=source(i,version,count);assert.equal(h.pageId,p.pageId);assert.equal(h.spaceId,p.spaceId);assert.equal(h.title,p.title);assert.equal(h.snippet,Array.from(p.content).slice(0,160).join(''));assert.deepEqual(h.tagIds,[...p.tags].sort());}
   const scores=result.diagnostic.nativeScores.map(x=>x.score);assert.ok(scores.every(Number.isFinite));
   for(let i=1;i<scores.length;i++){assert.ok(scores[i-1]>=scores[i],'descending BM25');if(contract==='E'&&scores[i-1]===scores[i])assert.ok(ids[i-1]<ids[i],'lexical tie');}
  }
  stop();
 }
}catch(e){failure={message:e.message,stack:e.stack,context,policy:'stop entire screen; do not retry, escalate or run formal blocks'};log({event:'screen.stopped',failure});}
finally{try{stop();}catch(e){failure??={message:e.message,context};log({event:'cleanup.failed',message:e.message});}}
let dbStatUnchanged=false;
try{const final=await stat(database);dbStatUnchanged=final.size===initial.size&&final.mtimeMs===initial.mtimeMs;if(!dbStatUnchanged)throw Error('SOURCE_STAT_CHANGED');}catch(e){failure??={message:e.message,context:{phase:'source-integrity'}};log({event:'integrity.failed',message:e.message});}
const hashes={};for(const name of ['screen.mjs','../sqlite/adapter.mjs','../sqlite/probe-cases.mjs','../../c-million-20261116/source.mjs'])hashes[name]=createHash('sha256').update(await readFile(new URL(name,import.meta.url))).digest('hex');
const result={passed:!failure,failure,scope:'Bounded G2 screen, parent outside reader quota; not formal block or SLO. Only index meta size/mtime checked here; source/content hashes belong to parent freeze.',count,version,hashes,plans,units,indexMetaStatUnchanged:dbStatUnchanged,
 completed:records.filter(r=>r.event==='query.result').length,expectedQueries:cases.length,contract,binarySha256:createHash('sha256').update(await readFile(binary)).digest('hex')};
await writeFile(path.join(out,'result.json'),JSON.stringify(result,null,2));console.log(JSON.stringify({passed:result.passed,completed:result.completed,failure}));if(failure)process.exitCode=1;
