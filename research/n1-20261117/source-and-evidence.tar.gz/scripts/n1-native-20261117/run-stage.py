from pathlib import Path
import subprocess,json,time,shutil,sys,os
base=Path('/PUBLIC/WINDOWS_WORKSPACE')
run=Path('/PUBLIC/LINUX_HOME/dr-search-lab-e1-20261115/repo/.lab/n1-native-20261117')
label,limit,mode=sys.argv[1:4];args=sys.argv[4:];limit=int(limit)
assert label.replace('-','').isalnum() and mode in ['unit','parent'] and 1<=limit<=2700
out=base/'evidence/n1-native-20261117'/label;out.mkdir()
unit='dr-n1-'+label
cmd=(['systemd-run','--user','--wait','--pipe','--unit='+unit,'-p','CPUQuota=400%','-p','MemoryMax=8G','-p','MemorySwapMax=0','-p','TasksMax=256','-p','RuntimeMaxSec='+str(limit)]+args) if mode=='unit' else args
start=time.monotonic();reason=None;metrics=[]
with (out/'stdout.log').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
 p=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,start_new_session=True)
 try:
  while p.poll() is None:
   available=int(next(s.split()[1] for s in Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemAvailable:')))*1024
   used=int(subprocess.check_output(['du','-sb',str(run)]).split()[0]);free=shutil.disk_usage(run).free
   metrics.append({'seconds':time.monotonic()-start,'hostAvailable':available,'runBytes':used,'diskFree':free})
   if available<1536*1024**2 or free<30*1024**3 or used>60*1024**3:reason='HOST_RESOURCE_GUARD';break
   if time.monotonic()-start>limit+15:reason='STAGE_DEADLINE';break
   time.sleep(5)
 except Exception as e:reason='MONITOR_ERROR:'+str(e)
 finally:
  subprocess.run(['systemctl','--user','stop',unit],capture_output=True)
  if mode=='parent':
   units=subprocess.run(['systemctl','--user','list-units','--plain','--no-legend','--all','dr-n1-probe-*'],capture_output=True,text=True).stdout
   for line in units.splitlines():
    name=line.split()[0]
    if name.startswith('dr-n1-probe-'):subprocess.run(['systemctl','--user','stop',name],capture_output=True)
  if p.poll() is None:
   import signal
   os.killpg(p.pid,signal.SIGKILL)
  p.wait()
state=subprocess.run(['systemctl','--user','show',unit,'-p','MainPID,ActiveState,Result,ExecMainStatus'],capture_output=True,text=True).stdout
r={'passed':p.returncode==0 and reason is None,'code':p.returncode,'stop':reason,'seconds':time.monotonic()-start,'mode':mode,'finalState':state,'metrics':metrics}
(out/'controller.json').write_text(json.dumps(r,indent=2));print(json.dumps({k:v for k,v in r.items() if k!='metrics'}))
raise SystemExit(0 if r['passed'] else 1)
