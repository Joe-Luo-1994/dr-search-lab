from pathlib import Path
import json,hashlib,sys
root=Path('/PUBLIC/LINUX_HOME/dr-search-lab-e1-20261115/repo')
out=Path('/PUBLIC/WINDOWS_WORKSPACE/evidence/n1-native-20261117')
phase=sys.argv[1];assert phase in ['before','after','formal-after']
assert not (out/f'g2-freeze-{phase}.json').exists(), 'DO_NOT_OVERWRITE_EVIDENCE'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
index=root/'.lab/n1-native-20261117/million-index'
paths=[root/'.lab/c-million-20261116/fixture-1000000/v1/search.sqlite']+sorted(p for p in index.rglob('*') if p.is_file())
rows=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in paths]
meta=json.loads((index/'meta.json').read_text())
result={'scope':'input hashes warm host cache; not cold-cache performance','files':rows,'indexBytes':sum(x['bytes'] for x in rows[1:]),'segments':len(meta['segments'])}
if phase!='before':result['unchanged']=rows==json.loads((out/'g2-freeze-before.json').read_text())['files']
(out/f'g2-freeze-{phase}.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='files'}))
