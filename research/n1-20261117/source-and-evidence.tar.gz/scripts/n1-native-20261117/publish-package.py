"""Prepare a bounded public backup; originals are never modified."""
import base64,gzip,hashlib,io,json,re,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2]
O=R/'research/n1-20261117';O.mkdir(parents=True,exist_ok=True)
P=R/'evidence/n1-publication-20261117';P.mkdir(parents=True,exist_ok=True)
paths=list((R/'scripts/n1-native-20261117').rglob('*'))+list((R/'evidence/n1-native-20261117').rglob('*'))
paths+=list((R/'docs').glob('DR_N1*.md'))+[R/'docs/DR_NATIVE_BASELINE_PLAN_20261116.md']
allowed={'.md','.json','.ndjson','.jsonl','.mjs','.js','.py','.rs','.toml','.lock','.sh','.log','.txt','.sha256'}
records=[];payload={};excluded=[];findings=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def clean(s):
 s=re.sub(r'C:(?:\\+|/)Users(?:\\+|/)User(?:\\+|/)Documents(?:\\+|/)ChatGPT(?:\\+|/)Search Playground','/PUBLIC/WINDOWS_WORKSPACE',s,flags=re.I)
 s=s.replace('/PUBLIC/WINDOWS_WORKSPACE','/PUBLIC/WINDOWS_WORKSPACE').replace('/PUBLIC/LINUX_HOME','/PUBLIC/LINUX_HOME')
 s=re.sub(r'C:(?:\\+|/)Users(?:\\+|/)User','/PUBLIC/WINDOWS_HOME',s,flags=re.I)
 s=s.replace('/PUBLIC/WINDOWS_HOME','/PUBLIC/WINDOWS_HOME')
 s=re.sub(r'DESKTOP-[A-Z0-9]+','PUBLIC-HOST',s,flags=re.I)
 return s
patterns=[r'github_pat_[A-Za-z0-9_]+',r'gh[pousr]_[A-Za-z0-9]{20,}',r'AKIA[A-Z0-9]{16}',r'-----BEGIN [^-]*PRIVATE KEY',r'(?i)"(?:secretKey|adminToken|password|accessKey)"\s*:\s*"[^"$<{]{8,}"',r'/PUBLIC/LINUX_HOME',r'(?i)C:(?:\\+|/)Users(?:\\+|/)User',r'(?i)DESKTOP-[A-Z0-9]+']
for p in sorted(set(paths)):
 if not p.is_file():continue
 rel=p.relative_to(R).as_posix()
 if '__pycache__' in p.parts or p.suffix not in allowed or p.name in ('config.json','private-config.json','minio.env'):
  excluded.append(rel);continue
 raw=p.read_bytes();s=clean(raw.decode('utf-8-sig'));b=s.encode()
 for i,pat in enumerate(patterns):
  if re.search(pat,s):findings.append({'file':rel,'rule':i})
 # Validate every structured record after redaction, including compressed archive inputs.
 if p.suffix=='.json':json.loads(s)
 if p.suffix in ('.jsonl','.ndjson'):
  for line in s.splitlines():
   if line.strip():json.loads(line)
 payload[rel]=b;records.append({'path':rel,'sourceBytes':len(raw),'sourceSha256':sha(raw),'publicBytes':len(b),'publicSha256':sha(b),'redacted':raw!=b})
audit={'files':len(records),'decodedBytes':sum(r['publicBytes'] for r in records),'findings':findings,'excluded':excluded}
(P/'scan.json').write_text(json.dumps(audit,indent=2),encoding='utf8')
if findings:print(json.dumps(audit));raise SystemExit(2)
manifest={'scope':'N1 synthetic research backup; public sanitized copies, not a certified portable environment or production result','policy':'Personal roots/host replaced with /PUBLIC placeholders; original source hashes remain provenance, not public-file checksums. Original local files retained. No DB/index/config/credentials. Extract archive into a fresh directory.','files':records,'excluded':excluded}
mb=json.dumps(manifest,ensure_ascii=False,indent=2).encode();(O/'manifest.json').write_bytes(mb)
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tar:
 for name,b in sorted({**payload,'manifest.json':mb}.items()):
  t=tarfile.TarInfo(name);t.size=len(b);t.mtime=0;t.mode=0o644;tar.addfile(t,io.BytesIO(b))
archive=gzip.compress(buf.getvalue(),compresslevel=9,mtime=0);(O/'source-and-evidence.tar.gz').write_bytes(archive)
# Renderable reports plus their direct evidence links; all other raw sources are in archive.
visible={k:v for k,v in payload.items() if k.startswith('docs/')}
for name in ['formal-summary.json','g3-final-integrity.json','g3a-sqlite-attempt3/summary.json','g3a-tantivy-attempt1/summary.json']:
 key='evidence/n1-native-20261117/'+name;visible[key]=payload[key]
for name,b in visible.items():
 p=O/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
readme='''# N1 實驗備份 — 2026-11-17

[決策報告](docs/DR_N1_OUTCOME_20261117.md) · [獨立review](docs/DR_N1_POSTREVIEW_20261117.md) · [設計](docs/DR_NATIVE_BASELINE_PLAN_20261116.md)

完整設計、程式、原始量測、環境修復及失敗證據：[下載 source-and-evidence.tar.gz](source-and-evidence.tar.gz)。下載後解壓至新目錄，依原有 docs/scripts/evidence 結構閱讀；GitHub 上僅另展開報告與主要摘要，細節連結請在解壓後使用。較早的共用來源在本 repo 既有 research 包；本包不宣稱一鍵重現。

G1/G2/G3a 限定結案。Tantivy 三輪 Web／混合負載通過；SQLite 此 E 配置 Web 暖機失敗，無同分次排序的 Top-K 尚未測。G3b 更新未做，不代表正式 DR 可部署或最低 TCO。

個人路徑／主機名稱已替換。未包含 DB、索引、私密 config、env 或憑證；本機原件保留。manifest 同時列原始與公開副本 checksum，來源hash不應拿來驗公開副本。舊實驗報告內的「尚未push」是當時狀態；本備份已由本次Git commit發布。

archive SHA256: `ARCHIVE_SHA`

驗證解壓檔案：在解壓目錄執行下列 Python（manifest 內每筆 publicSha256）。
```python
import hashlib,json,pathlib
root=pathlib.Path('.')
for f in json.loads((root/'manifest.json').read_text(encoding='utf8'))['files']:
    assert hashlib.sha256((root/f['path']).read_bytes()).hexdigest()==f['publicSha256'],f['path']
print('All public payload checksums match')
```
'''.replace('ARCHIVE_SHA',sha(archive))
(O/'README.md').write_text(readme,encoding='utf8')
uploads=[]
for p in sorted(O.rglob('*')):
 if p.is_file():
  b=p.read_bytes();uploads.append({'path':p.relative_to(R).as_posix(),'bytes':len(b),'sha256':sha(b),'gitBlob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
(P/'upload.json').write_text(json.dumps(uploads,indent=2),encoding='utf8')
print(json.dumps({'filesInArchive':len(records),'archiveBytes':len(archive),'uploadFiles':len(uploads),'findings':0,'excluded':excluded}))
