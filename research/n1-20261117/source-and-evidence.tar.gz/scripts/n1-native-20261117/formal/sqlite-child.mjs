import {createInterface} from 'node:readline';
import {openReader} from '../sqlite/adapter.mjs';
const reader=openReader(process.argv[2],{variant:process.argv[3],includeScores:true});
const send=x=>process.stdout.write(JSON.stringify(x)+'\n');send({ready:true,pid:process.pid,snapshotId:reader.snapshotId});
const lines=createInterface({input:process.stdin});
lines.on('line',line=>{let id;try{const m=JSON.parse(line);id=m.id;send({id,result:reader.search(m.input)});}catch(e){send({id,error:e.message});}});
lines.on('close',()=>{reader.close();process.exit(0);});
