import {spawn,execFileSync} from 'node:child_process';
import {createInterface} from 'node:readline';
import {readFileSync,existsSync,appendFileSync} from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';

// Shared by both engines; no engine-specific scheduling or deadline policy.
export class SystemdReader {
 constructor({command,unit,out,log,snapshotId,sourceCount}){Object.assign(this,{command,unit,out,log,snapshotId,sourceCount});this.pending=null;this.seq=0;this.cp=null;this.pid=null;}
 ctl(args){return execFileSync('systemctl',['--user',...args],{encoding:'utf8',timeout:15000});}
 state(){return Object.fromEntries(this.ctl(['show',this.unit,'--property=MainPID,ControlGroup,ActiveState,CPUQuotaPerSecUSec,MemoryMax,MemorySwapMax,RuntimeMaxUSec,TimeoutStopUSec,KillMode']).trim().split('\n').map(l=>{const i=l.indexOf('=');return[l.slice(0,i),l.slice(i+1)];}));}
 async start(){
  const cp=spawn('systemd-run',['--user','--wait','--pipe','--unit='+this.unit,'-p','CPUQuota=400%','-p','MemoryMax=8589934592','-p','MemorySwapMax=0','-p','TasksMax=128','-p','RuntimeMaxSec=1100','-p','TimeoutStopSec=2s','-p','KillMode=control-group',...this.command],{stdio:['pipe','pipe','pipe']});this.cp=cp;
  let resolveReady,rejectReady;const ready=new Promise((r,j)=>{resolveReady=r;rejectReady=j;});
  const timer=setTimeout(()=>rejectReady(Error('READY_TIMEOUT')),15000);
  cp.stderr.on('data',b=>appendFileSync(path.join(this.out,this.unit+'.stderr.log'),b));
  const fail=e=>{clearTimeout(timer);if(this.cp!==cp)return;rejectReady(e);if(this.pending){const p=this.pending;this.pending=null;clearTimeout(p.timer);p.reject(e);}};
  cp.on('error',fail);cp.on('exit',(code,signal)=>fail(Error(`WRAPPER_EXIT:${code}:${signal}`)));
  createInterface({input:cp.stdout}).on('line',line=>{
   if(this.cp!==cp)return;
   try{if(line.length>2*1024*1024)throw Error('RESPONSE_TOO_LARGE');const m=JSON.parse(line);
    if(m.ready){clearTimeout(timer);resolveReady(m);return;}
    if(!this.pending||m.id!==this.pending.id)throw Error('UNEXPECTED_RESPONSE');
    const p=this.pending;this.pending=null;clearTimeout(p.timer);
    if(m.error)p.reject(Error(m.error));else p.resolve({result:m.result??m.value,roundTripMs:performance.now()-p.started});
   }catch(e){fail(e);}
  });
  const info=await ready,state=this.state();this.pid=Number(state.MainPID);assert.ok(this.pid>0);assert.equal(info.snapshotId,this.snapshotId);
  if(info.pid!==undefined)assert.equal(info.pid,this.pid);
  if(info.count!==undefined)assert.equal(info.count,this.sourceCount);
  const membership=readFileSync(`/proc/${this.pid}/cgroup`,'utf8'),parent=readFileSync('/proc/self/cgroup','utf8');
  this.log({event:'reader.ready',unit:this.unit,info,state,membership,parent});
  assert.equal(state.ActiveState,'active');assert.equal(state.CPUQuotaPerSecUSec,'4s');assert.equal(state.MemoryMax,'8589934592');assert.equal(state.MemorySwapMax,'0');assert.ok(/^(18min\s*20s|1100s)$/.test(state.RuntimeMaxUSec),'runtime limit');assert.equal(state.TimeoutStopUSec,'2s');assert.equal(state.KillMode,'control-group');
  assert.ok(membership.trim().split('\n').includes('0::'+state.ControlGroup));assert.ok(!parent.trim().split('\n').includes('0::'+state.ControlGroup));
  return info;
 }
 request(payload,context){
  assert.equal(this.pending,null);assert.ok(this.cp);const id=++this.seq,started=performance.now();
  return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{
   this.pending=null;this.log({event:'query.deadline',id,context,deadlineMs:4000,elapsedToDeadlineMs:performance.now()-started,excludesCleanup:true});
   let cleanupError;try{this.stop();}catch(e){cleanupError=e.message;}reject(Error('QUERY_DEADLINE_4000MS'+(cleanupError?':'+cleanupError:'')));
  },4000);this.pending={id,started,timer,resolve,reject};this.cp.stdin.write(JSON.stringify({id,...payload})+'\n');});
 }
 stop(){
  if(!this.cp)return;const cp=this.cp;this.cp=null;const started=performance.now();
  try{const state=this.state(),resources={};for(const name of ['cpu.stat','memory.peak','memory.events','io.stat']){const p='/sys/fs/cgroup'+state.ControlGroup+'/'+name;if(existsSync(p))resources[name]=readFileSync(p,'utf8');}this.log({event:'resources.before-stop',unit:this.unit,state,resources});}catch(e){this.log({event:'resources.unavailable',unit:this.unit,message:e.message});}
  try{this.ctl(['stop',this.unit]);}catch(e){this.log({event:'cleanup.stop.error',unit:this.unit,message:e.message});}
  let state;try{state=this.state();}catch(e){state={readbackError:e.message};}
  const alive=this.pid?existsSync('/proc/'+this.pid):null,clean=!alive&&state.MainPID==='0'&&['inactive','failed'].includes(state.ActiveState);
  cp.stdin.destroy();const receipt={unit:this.unit,pid:this.pid,state,alive,clean,cleanupMs:performance.now()-started};this.log({event:'cleanup',...receipt});
  if(!clean)throw Error('CLEANUP_NOT_VERIFIED:'+this.unit);return receipt;
 }
}
