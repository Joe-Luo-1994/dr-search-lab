# N1 E-only formal block runner

Prepared for review, not executed by the implementation agent. Same shared SystemdReader transport, deadline and resource enforcement for both engines.

```
node run.mjs --engine sqlite --block 1 --index SQLITE_DB --out NEW_OUTDIR
node run.mjs --engine tantivy --block 1 --index TANTIVY_INDEX --binary READER_BINARY --out NEW_OUTDIR
```

Parent invokes blocks in order S1/T1, T1/S1, S1/T1 for block numbers 1,2,3. The runner only executes the single requested engine/block. Count defaults 1,000,000 and snapshot defaults v1. E only. Query schedule is identical per block across engines: 3 warm round-robin rounds followed by 30 measured rounds, with a frozen seeded shuffle of the 21 shapes per round. There are 63 warm and 630 measured requests. No EQP or parallel query hot path.

SQLite first runs a 21-query S0 control in its own reader, then opens S1. All S1 results must preserve ordered IDs against that control. S0 is not part of the engine ratio or measured samples. Both SQLite and Tantivy return nativeScores; SQLite negative BM25 ascends, Tantivy positive BM25 descends. Every result verifies eligible membership, exact total, completeness, uniqueness, fields, score direction and lexical pageId tie. Oracle and validation remain in the parent outside reader quota.

Each reader has 4CPU/8GiB, swap0, 1100s runtime, 2s stop, control-group kill. Parent must keep its 1200s outer block watchdog, host/disk guard and full input/index hashes. Unit prefix is `dr-n1-probe-formal-` so existing parent cleanup matches. Resource/cgroup readback precedes query. Each request has an independent 4s deadline; deadline time is logged before separately timed cleanup. First failure stops the block, and parent must not automatically continue remaining blocks or retry.

All request outputs and warm/control/measured labels are retained in raw.ndjson; result.json reports per-shape nearest-rank p50/p95/p99 and n=30 when complete. Failed/partial counts are explicit. These serial samples do not evidence API SLO, mixed-load capacity, production relevance, or ES superiority. Native timings have engine-specific implementation boundaries; roundTrip includes IPC/JSON and reader work but excludes parent oracle/validation. Tantivy query tokens are prepared in parent; SQLite preprocessing occurs in reader before its own native timer—report this distinction, not pure-algorithm equivalence.

Cache state: no OS cache flush. Fresh reader per block; SQLite control may warm shared pages. Both engines use 3 warm rounds. Parent hashes can warm OS cache and must be recorded. Existing screen timings are not a ratio baseline for this scores-enabled contract.
