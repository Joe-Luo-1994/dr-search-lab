import {mkdir,readFile,writeFile,stat} from 'node:fs/promises';
import {appendFileSync,readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {SystemdReader} from './systemd-reader.mjs';
import {probes,matches} from '../sqlite/probe-cases.mjs';
import {queryTokens} from '../sqlite/adapter.mjs';
import {source} from '../../c-million-20261116/source.mjs';

const opts={};for(let i=2;i<process.argv.length;i+=2){if(!process.argv[i]?.startsWith('--')||process.argv[i+1]===undefined)throw Error('Expected --key value');opts[process.argv[i].slice(2)]=process.argv[i+1];}
const engine=opts.engine,block=Number(opts.block),count=Number(opts.count??'1000000'),version=opts.version??'v1';
if(!['sqlite','tantivy'].includes(engine)||![1,2,3].includes(block)||!opts.index||!opts.out||!Number.isSafeInteger(count)||count<123||count>1000000||!['v1','v2'].includes(version)||(engine==='tantivy'&&!opts.binary))throw Error('Usage: node run.mjs --engine sqlite|tantivy --block 1|2|3 --index DB_OR_INDEX --out NEW_DIR [--binary TANTIVY] [--count 1000000] [--version v1]');
const out=path.resolve(opts.out);await mkdir(out);const index=path.resolve(opts.index),statPath=engine==='sqlite'?index:path.join(index,'meta.json');
const initial=await stat(statPath),cases=probes(count,version),counts=Object.fromEntries(cases.map(q=>[q.id,0]));
const log=e=>appendFileSync(path.join(out,'raw.ndjson'),JSON.stringify({at:new Date().toISOString(),engine,block,...e})+'\n');
const started=new Date().toISOString(),oracleStart=performance.now();
for(let i=1;i<=count+(version==='v2'?1:0);i++)for(const q of cases)if(matches(q,i,count,version))counts[q.id]++;
const schedule=[],seed=170000+block;
function shuffled(round){let state=(seed+round*7919)>>>0;const a=cases.map(q=>q.id);for(let i=a.length-1;i>0;i--){state=(Math.imul(state,1664525)+1013904223)>>>0;const j=state%(i+1);[a[i],a[j]]=[a[j],a[i]];}return a;}
for(let round=0;round<33;round++)for(const id of shuffled(round))schedule.push({phase:round<3?'warm':'measure',round:round<3?round:round-3,id});
await writeFile(path.join(out,'schedule.json'),JSON.stringify({seed,order:'round-robin, seeded shuffle each round; 3 warm rounds then 30 measured rounds',schedule,cases,counts,parentPid:process.pid,parentCgroup:readFileSync('/proc/self/cgroup','utf8'),oracleMs:performance.now()-oracleStart},null,2));
let reader=null,failure=null,context=null;const measured=[],control=new Map(),cleanup=[];
const command=variant=>engine==='sqlite'?[process.execPath,fileURLToPath(new URL('./sqlite-child.mjs',import.meta.url)),index,variant]:[path.resolve(opts.binary),'serve',index];
function makeReader(variant){return new SystemdReader({command:command(variant),unit:`dr-n1-probe-formal-${process.pid}-${engine}-${variant.toLowerCase()}-b${block}`,out,log,snapshotId:version,sourceCount:count+(version==='v2'?1:0)});}
function validate(q,result){
 assert.equal(result.snapshotId,version);assert.equal(result.total,counts[q.id]);const ids=result.hits.map(h=>h.pageId);assert.equal(ids.length,Math.min(10,counts[q.id]));assert.equal(new Set(ids).size,ids.length);
 for(const h of result.hits){const i=Number(h.pageId.slice(1));assert.ok(i>=1&&i<=count+(version==='v2'?1:0));assert.ok(matches(q,i,count,version));const p=source(i,version,count);assert.equal(h.pageId,p.pageId);assert.equal(h.spaceId,p.spaceId);assert.equal(h.title,p.title);assert.equal(h.snippet,Array.from(p.content).slice(0,160).join(''));assert.deepEqual(h.tagIds,[...p.tags].sort());}
 const native=result.diagnostic.nativeScores;assert.equal(native.length,ids.length);for(let i=0;i<native.length;i++){assert.equal(native[i].pageId,ids[i]);assert.ok(Number.isFinite(native[i].score));if(i){assert.ok(engine==='sqlite'?native[i-1].score<=native[i].score:native[i-1].score>=native[i].score);if(native[i-1].score===native[i].score)assert.ok(ids[i-1]<ids[i],'lexical tie');}}
 return ids;
}
async function query(q,ctx){context=ctx;log({event:'query.begin',context});const input={...q,contract:'E'},payload=engine==='sqlite'?{input}:{input,tokens:queryTokens(input.q)};
 const response=await reader.request(payload,context);log({event:'query.result',context,...response});const ids=validate(q,response.result);return {...response,ids};}
try{
 if(engine==='sqlite'){
  context={phase:'control-ready'};reader=makeReader('S0');await reader.start();
  for(const q of cases){const r=await query(q,{phase:'control',queryId:q.id});control.set(q.id,r.ids);}
  cleanup.push(reader.stop());reader=null;
 }
 context={phase:'candidate-ready'};reader=makeReader(engine==='sqlite'?'S1':'T1');await reader.start();
 for(const step of schedule){const q=cases.find(q=>q.id===step.id),r=await query(q,{phase:step.phase,round:step.round,queryId:q.id});
  if(engine==='sqlite')assert.deepEqual(r.ids,control.get(q.id),'S0/S1 ordered parity '+q.id);
  if(step.phase==='measure')measured.push({queryId:q.id,round:step.round,roundTripMs:r.roundTripMs,nativeMs:r.result.diagnostic.totalMs??null});
 }
 cleanup.push(reader.stop());reader=null;
}catch(e){failure={message:e.message,stack:e.stack,context};log({event:'block.stopped',failure});}
finally{try{if(reader){const r=reader.stop();if(r)cleanup.push(r);}}catch(e){failure??={message:e.message,context:{phase:'cleanup'}};log({event:'cleanup.failed',message:e.message});}}
let sourceStatUnchanged=false;try{const after=await stat(statPath);sourceStatUnchanged=after.size===initial.size&&after.mtimeMs===initial.mtimeMs;if(!sourceStatUnchanged)throw Error('SOURCE_STAT_CHANGED');}catch(e){failure??={message:e.message,context:{phase:'integrity'}};log({event:'integrity.failed',message:e.message});}
function stats(v){const a=[...v].sort((a,b)=>a-b),q=p=>a.length?a[Math.ceil(a.length*p)-1]:null;return {n:a.length,p50:q(.5),p95:q(.95),p99:q(.99),min:a[0]??null,max:a.at(-1)??null,method:'nearest-rank; descriptive only'};}
const summary=Object.fromEntries(cases.map(q=>[q.id,{roundTripMs:stats(measured.filter(m=>m.queryId===q.id).map(m=>m.roundTripMs)),nativeMs:stats(measured.filter(m=>m.queryId===q.id&&m.nativeMs!==null).map(m=>m.nativeMs))}]));
const hashes={};for(const n of ['run.mjs','systemd-reader.mjs','sqlite-child.mjs','../sqlite/adapter.mjs','../sqlite/probe-cases.mjs','../../c-million-20261116/source.mjs'])hashes[n]=createHash('sha256').update(await readFile(new URL(n,import.meta.url))).digest('hex');
if(opts.binary)hashes.binary=createHash('sha256').update(await readFile(opts.binary)).digest('hex');
const result={passed:!failure&&measured.length===630,failure,engine,block,count,version,contract:'E',started,finished:new Date().toISOString(),seed,hashes,summary,measuredCount:measured.length,expectedMeasured:630,cleanup,sourceStatUnchanged,
 cache:'Fresh reader per block; OS page cache not cleared. SQLite S0 control precedes S1 and may warm shared pages. Both have 3 warm rounds before measurement.',
 scope:'Sequential engine microbenchmark, diagnostic nativeScores included on both; no API SLO, concurrent capacity, ES ratio, or production relevance claim. Parent must freeze/hash full index and enforce outer host/runtime guards.'};
await writeFile(path.join(out,'result.json'),JSON.stringify(result,null,2));console.log(JSON.stringify({passed:result.passed,engine,block,measured:measured.length,failure}));if(!result.passed)process.exitCode=1;
