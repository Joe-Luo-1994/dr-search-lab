"""Collect only allowlisted G3a research receipts; no service control or load execution."""
import argparse, hashlib, json, re, shutil
from pathlib import Path
TOP=re.compile(r'^(?:prepared|ready|smoke|limits|started-at|startup-failed|load-failed|disk-guard|sequence-start|sequence-progress|sequence-result)\.json$|^stop-[0-9]+\.json$|^load-controller-(?:baseline|W|M)-[123]\.json$|^guard-(?:baseline|W|M)-[123]\.ndjson$|^events\.ndjson$|^load-(?:baseline|W|M)-[123]\.log$')
LEAF={'raw.ndjson','resources.ndjson','status.ndjson','control.ndjson','schedule.json','result.json'}
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def resources(p):
 groups={}; warnings=[]
 if not p.exists():return {'groups':{},'warnings':['resource evidence missing']}
 for n,line in enumerate(p.open(),1):
  try:row=json.loads(line)
  except ValueError:warnings.append('invalid resource line '+str(n));continue
  for name,g in row.get('groups',{}).items():
   if name not in ('reader','minio'):continue
   v=groups.setdefault(name,{'samples':0,'firstCpu':g.get('cpu',{}),'lastCpu':{},'maxMemoryCurrentBytes':0,'cgroupLifetimeMemoryPeakBytes':0})
   v['samples']+=1;v['lastCpu']=g.get('cpu',{});v['maxMemoryCurrentBytes']=max(v['maxMemoryCurrentBytes'],g.get('memoryCurrent',0));v['cgroupLifetimeMemoryPeakBytes']=max(v['cgroupLifetimeMemoryPeakBytes'],g.get('memoryPeak',0))
 for g in groups.values():
  first=g.pop('firstCpu');last=g.pop('lastCpu');g['cpuCounterDelta']={k:last[k]-first[k] for k in ('usage_usec','user_usec','system_usec','nr_periods','nr_throttled','throttled_usec') if k in first and k in last}
  if any(v<0 for v in g['cpuCounterDelta'].values()):warnings.append('counter reset detected')
 return {'groups':groups,'warnings':warnings,'scope':'first-to-last sampled counters; memory.peak is cgroup lifetime, not isolated stage peak'}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--name',required=True);ap.add_argument('--out',type=Path);a=ap.parse_args()
 if not re.fullmatch(r'[A-Za-z0-9_-]+',a.name):ap.error('invalid run name')
 root=a.root.resolve();source=root/'.lab/n1-native-20261117/g3a'/a.name;target=(a.out or root/'evidence/n1-native-20261117'/('g3a-'+a.name)).resolve()
 if not source.is_dir() or source.is_symlink():raise RuntimeError('source must be real run directory')
 if target.exists():raise RuntimeError('new output directory required')
 selected=[]
 for p in source.iterdir():
  if p.is_symlink():continue
  if p.is_file() and TOP.fullmatch(p.name):selected.append(p)
  elif p.is_dir() and re.fullmatch(r'load-(?:baseline|W|M)-[123]',p.name):
   selected.extend(f for f in p.iterdir() if f.is_file() and not f.is_symlink() and f.name in LEAF)
 target.mkdir(parents=True);manifest=[]
 for p in sorted(selected):
  relative=p.relative_to(source);dest=target/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
  manifest.append({'path':str(relative),'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()})
 stages=[]
 for stage,rep in [('baseline',1)]+[(s,r) for s in ('W','M') for r in (1,2,3)]:
  folder=target/f'load-{stage}-{rep}';result=folder/'result.json';controller=target/f'load-controller-{stage}-{rep}.json';row={'stage':stage,'rep':rep,'status':'not-tested','lanes':{},'resources':resources(folder/'resources.ndjson')}
  if result.exists():
   r=read(result);row.update(status='passed' if r.get('passed') else 'failed',instrumentInvalid=r.get('instrumentInvalid'),stop=r.get('stopped'))
   for lane,v in r.get('measure',{}).items():row['lanes'][lane]={'planned':v['offered'],'terminal':v['terminal'],'sent':v['sent'],'completed':v['completed'],'failedOrUncompleted':v['offered']-v['completed'],'p95Ms':v['latency']['p95'],'successfulLatencySamples':v['latency']['n'],'outcomes':v.get('outcomes',{})}
  elif controller.exists() or folder.exists():row['status']='incomplete-failed';row['reason']='attempted but no result receipt'
  if controller.exists():
   row['controller']=read(controller)
   if row['controller'].get('passed') is not True:row['status']='failed'
  elif result.exists():
   row['status']='incomplete';row['reason']='controller receipt missing; lane measurements do not establish stage pass'
  stages.append(row)
 summary={'name':a.name,'scope':'synthetic G3a preloaded workload; no production capacity or recovery claim','stages':stages,'collection':{'files':len(manifest),'excluded':'config, project, runtime, cache, env, arbitrary logs; no recursive wildcard copying'}}
 sequence=target/'sequence-result.json'
 summary['sequence']=read(sequence) if sequence.exists() else None
 summary['overallStatus']='passed' if all(r['status']=='passed' for r in stages) and summary['sequence'] and summary['sequence'].get('passed') is True else 'failed' if any(r['status']=='failed' for r in stages) or (summary['sequence'] is not None and summary['sequence'].get('passed') is not True) else 'incomplete'
 (target/'collection-manifest.json').write_text(json.dumps(manifest,indent=2));(target/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps({'target':str(target),'files':len(manifest),'stages':[{k:r[k] for k in ('stage','rep','status')} for r in stages]}))
if __name__=='__main__':main()
