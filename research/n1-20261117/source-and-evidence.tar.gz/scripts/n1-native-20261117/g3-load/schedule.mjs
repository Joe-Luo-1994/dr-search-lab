export const rates={baseline:{reading:1},W:{reading:1,'web-search':4},M:{reading:1,'web-search':4,consumer:2,media:2}};
export function arrivals(stage,start,warm=60,measure=300){
 if(!rates[stage])throw Error('INVALID_STAGE');const rows=[];
 for(const [lane,rate]of Object.entries(rates[stage]))for(let n=0;n<(warm+measure)*rate;n++){
  const scheduledAt=start+n*1000/rate;rows.push({lane,sequence:n,periodMs:1000/rate,scheduledAt,deadlineAt:scheduledAt+4000,window:n<warm*rate?'warm':'measure'});
 }
 return rows.sort((a,b)=>a.scheduledAt-b.scheduledAt||a.lane.localeCompare(b.lane));
}
export function admission(task,now,{inflight=0,laneInflight=0,stopped=false}={}){
 if(stopped)return 'canceled-after-stop';
 if(now>=task.deadlineAt||now>=task.scheduledAt+task.periodMs)return 'generator-missed';
 if(inflight>=128||laneInflight>=64)return 'generator-cap';
 return 'send';
}
export async function withDeadline(task,perform,clock=()=>performance.now()){
 const remaining=task.deadlineAt-clock();if(remaining<=0)throw Error('TASK_DEADLINE');
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(Error('TASK_DEADLINE')),remaining);
 try{const result=await perform({signal:controller.signal,remaining:()=>Math.max(0,task.deadlineAt-clock())});
  if(controller.signal.aborted||clock()>task.deadlineAt)throw Error('TASK_DEADLINE');return result;
 }finally{clearTimeout(timer);}
}
export const percentile=(values,p)=>values.length?[...values].sort((a,b)=>a-b)[Math.ceil(values.length*p)-1]:null;
export function summarize(rows,offered){const good=rows.filter(r=>r.outcome==='ok'),miss=rows.filter(r=>r.outcome==='generator-missed'||r.outcome==='generator-cap');
 return {offered,terminal:rows.length,sent:rows.filter(r=>r.sentAt!==null).length,completed:good.length,
  failureFraction:offered?(offered-good.length)/offered:null,generatorMissed:miss.length,missedFraction:offered?miss.length/offered:null,
  outcomes:Object.fromEntries([...new Set(rows.map(r=>r.outcome))].map(k=>[k,rows.filter(r=>r.outcome===k).length])),
  latency:{n:good.length,p50:percentile(good.map(r=>r.completedAt-r.scheduledAt),.5),p95:percentile(good.map(r=>r.completedAt-r.scheduledAt),.95),p99:percentile(good.map(r=>r.completedAt-r.scheduledAt),.99)},
  sentToDoneP95:percentile(good.map(r=>r.completedAt-r.sentAt),.95)};
}
