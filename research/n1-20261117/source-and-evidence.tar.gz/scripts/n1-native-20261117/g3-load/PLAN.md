# G3a load harness：實作前 scope review

2026-11-17。主agent指定先設計，未實作／執行。不修改正在執行的formal/或K5檔案。本卡只測預載V1 steady-state Web／consumer／下載；不呼叫update、不冒充完整G3或DR恢復驗收。

## 最小差額與復用

沿用K5的HTTP endpoint／headers、Next SSR顯示驗證規則、page/media metadata、來源generator與8個附件hash。另寫最小單stage CLI `load.mjs --config ... --oracle ... --out NEW --stage baseline|W|M --rep 1|2|3 --baseline-result ...`，不複製K5的update／多階控制／版本切換邏輯。

可抽小helper為本目錄的oracle／schedule／metrics；不修改已凍結K5／formal或把有CLI副作用的舊檔import執行。相同harness測SQLite與Tantivy，只依config識別worker role與runtime；搜尋tokenization由server處理，generator只發原始keyword／Space／tags。

## 工作與階段

| Stage | Reading | Web journey | Consumer | Media |
|---|---:|---:|---:|---:|
| baseline | 1/s | 0 | 0 | 0 |
| W | 1/s | 4/s | 0 | 0 |
| M | 1/s | 4/s | 2/s | 2/s |

每stage 60秒warm＋300秒measure，最多8秒drain，外層398秒截止。measure預定分母：baseline reading300；W reading300／web1200；M另consumer600／media600。Warm arrivals分開記錄且不進measure latency或分母。每engine固定build/resources/runtime只做一次baseline；W/M每stage最多3 repetitions，higher stage須先前stage三次均合格；任一失敗即停止升階，其他未測列未測。每rep使用固定序列與同engine合格baseline result；重啟、改build/配置或明顯host drift需新baseline或停止判斷，不事後放寬門檻；親orchestrator負責交錯engine、檢查剩餘budget足以完整跑stage，不縮窗。

建議查詢集合沿用G2固定21題，兩搜尋lane以相同凍結seed輪替；21題mix與K5九題不同，禁止拿歷史K5數字當相同工作量的ratio。若主agent決定沿用九題，必須在實作前凍結，不能依壓測結果更換。語義採E契約，無L或動態降級。

Reading固定原K5授權HTML頁p000001／identity all。Web journey是同Next `GET /docs/p000002?version=v1` SSR完成後發search，沿用該search的a/all身份（V1均有權限），不是直接HTTP search冒充Web。Consumer只呼叫search API。Media輪替8個既有media及對應合法pageId；固定檔案bytes/hash來自凍結oracle，不產生新下載資料。

## 到達與deadline：與K5不同且必須重新驗

- 所有任務預先生成scheduledAt、deadlineAt=scheduledAt+4000ms、lane、序號、queryId、arrivalWindow。使用monotonic clock量差、同時記epoch時間供事件對齊。
- 固定到達節奏，不等上一筆完成。若尚未送出的slot已跨下一個該lane slot，該舊slot記generator-missed，不批次追趕；只有最近仍有效的slot可發送。這比只等4秒過期更嚴格，避免負載產生器delay形成補送突發。各lane同時正當到達仍可並行，不視為補送。
- 過deadline未送、超generator in-flight cap或測量已停止，均記明未送原因；不可從預定分母刪除。cap預設每lane64／全域128，用作generator安全護欄，碰到即instrument-invalid而非server容量失敗。
- 單一AbortController覆蓋整個任務。Web SSR與search共享scheduledAt+4秒，第二步只剩餘時間，不能重設4秒。下載deadline涵蓋完整body收到及驗證；計算驗證若晚於deadline仍不得判成功。
- 每任務記scheduledAt／sentAt（nullable）／completedAt／deadlineAt、queue lag、HTTP各step、完整bytes、結果分類。body／oracle驗證完成才算完成；原生tokens不由generator產生。
- 完成歸原arrivalWindow，warm request即使在measure才完成仍是warm。到360秒停止新到達，最多drain8秒；超過者記未完成。安全或資料錯誤早停時將所有未到的預定slot補成canceled-after-stop紀錄，沒有補送HTTP。
- generatorMissed／預定到達>1%為instrument-invalid，不能判引擎容量失敗；立即停止升階。保留raw不偷偷重跑。

## 搜尋／內容驗證

親generator配額外預先計21shape的source-rule exact total（與G2同規則），測量時只對最多10筆結果驗source字段，避免每request掃百萬。

每search驗snapshot=v1、total exact、hits數=min(10,total)、unique pageId、每ID在獨立eligible集合、Space／Tags／身份、title／snippet／tagIds與原來源一致。保留K5 canonical link檢查：同origin、無credentials/hash、正確page endpoint、單一pageId/version、無多餘參數。Tantivy與SQLite原生BM25不同，不用舊SQLite expected exactIDs／順序作跨引擎oracle。API剝diagnostic時無法在HTTP端重驗native score／tie，明示這部分沿用G1/G2及adapter freeze證據，不宣稱HTTP已重新觀測排序分數。

SSR核對main的snapshot／pageId以及h1／pre完整標題正文，保留K5 escapeText處理，證明該HTTP rendered頁面可取，不是完整browser/assets或真人體感。Media驗HTTP200、完整byte數與SHA256，hash比對不可只檢headers。未授權資料、錯版本、錯hash、欄位違約立即停止；錯誤response保留，不當作正常空結果。

## 測量與門檻

- baseline reading P95≤500ms、各lane未完成/失敗≤1%；W/M reading P95≤max(2×同engine固定runtime合格baseline,500ms)。
- Web journey與consumer成功P95≤2s；下載成功P95≤2s。全以scheduled→驗證完成計，另報sent→done及step拆分。
- 各lane及query shape獨立報offered/sent/completed/rejected/timeout/missed/canceled，成功latency P50/P95/P99附n；失敗留預定分母。不能以快速拒絕稀釋P95。低樣本shape P95只描述，不當額外達標門檻。
- 每秒記generator CPU/RSS/event-loop lag與reader cpu.stat/memory.current/events/io.stat；MinIO每4秒一次。status每5秒觀察，控制流量另列且兩engine一致，不列使用者lane。
- config提供reader/MinIO實際cgroup及limits；readback必須符合4CPU8GiB reader與固定MinIO預算、swap0。status PID及workers/workerDetails需存在於reader cgroup；SQLite通用worker與Tantivy search/meta角色不同，依明確role/cmdline allowlist核對，不能刪掉歸屬檢查。更換預算／worker數需另卡。
- provider busy/429算rejection，不丟分母；fatal、OOM、transport failure分開記capacity/service/instrument，不一律叫效能差。parent整體host/disk watchdog、398秒process-group停止與服務cleanup另有receipt。

## Scope gate與待review問題

實作前只需reviewer核：21題mix是否採納、跨slot漏發規則、共同4秒journey deadline、query oracle不比較exactIDs、generator配額外及worker角色readback。通過再寫runner，不先增加新引擎API功能。

正式負載前必須G3a service smoke完成：search→page→media、unknown拒絕、none空集合、Space/Tags、錯version／descriptor拒絕及update404；loader本身以短fixture走一次「到達遲到／兩步共享deadline／完整body timeout」受控自驗，僅驗儀器不當服務容量。不得直接把K5原30秒／5秒HTTP／10秒journey deadline拿來用。

不做update／冷啟動RTO／全語料閱讀／新附件分布／consumer正式契約。一次baseline及3×W/M通過只支持G3a預載V1工作點，G3b生命週期與長期維運仍未知。

