import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {readFileSync,appendFileSync,existsSync} from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {monitorEventLoopDelay} from 'node:perf_hooks';
import {arrivals,admission,withDeadline,summarize,rates} from './schedule.mjs';
import {consumeBody} from './transport.mjs';
import {prepareOracle} from './oracle.mjs';
const sha=b=>createHash('sha256').update(b).digest('hex'),sleep=ms=>new Promise(r=>setTimeout(r,Math.max(0,ms)));
const options={};for(let i=2;i<process.argv.length;i+=2){if(!process.argv[i]?.startsWith('--')||process.argv[i+1]===undefined)throw Error('Expected --key value');options[process.argv[i].slice(2)]=process.argv[i+1];}
if(!options.config||!options.oracle||!options.out||!rates[options.stage]||![1,2,3].includes(Number(options.rep)))throw Error('Usage: node load.mjs --config PATH --oracle PATH --out NEW --stage baseline|W|M --rep 1|2|3 [--baseline-result PATH]');
if(options.stage==='baseline'&&options.rep!=='1')throw Error('ONE_BASELINE_PER_FIXED_RUNTIME');
const configBytes=await readFile(options.config),config=JSON.parse(configBytes),oracleBytes=await readFile(options.oracle),legacy=JSON.parse(oracleBytes);
const harness=config.loadHarness;assert.ok(harness&&['sqlite','tantivy'].includes(harness.engine)&&typeof harness.baselineGeneration==='string'&&harness.baselineGeneration.length>0);assert.ok(Array.isArray(harness.workerRoles)&&harness.workerRoles.length);
for(const r of harness.workerRoles){assert.ok(r.role&&Number.isInteger(r.count)&&r.count>0&&typeof r.commandIncludes==='string'&&r.commandIncludes.length>3);}
const base=config.baseUrl,web=config.webBase??config.webBaseUrl??new URL(base).origin;
for(const url of [base,web]){assert.equal(new URL(url).hostname,'127.0.0.1');assert.equal(new URL(url).protocol,'http:');}
const out=path.resolve(options.out);await mkdir(out);const oracle=prepareOracle(legacy,base),origin=performance.now(),epoch=Date.now(),clock=()=>performance.now();
const log=(file,row)=>appendFileSync(path.join(out,file),JSON.stringify({at:new Date().toISOString(),...row})+'\n');
const terminal=[],pending=new Set(),lanePending=new Map(),initialMemoryEvents=new Map(),activeControllers=new Set();
let stopped=null,statusPending=null,statusBusy=false,resourceTimer,statusTimer,firstStatus=null,lastStatus=null,baseline=null;
const eventLoop=monitorEventLoopDelay({resolution:20});eventLoop.enable();
const stop=(category,reason)=>{if(!stopped){stopped={category,reason,at:new Date().toISOString(),monotonicAt:clock()};log('control.ndjson',{event:'stop',...stopped});for(const c of activeControllers)c.abort(Error('STAGE_STOP'));}};
const parseStats=s=>Object.fromEntries(s.trim().split('\n').filter(Boolean).map(l=>{const[k,v]=l.split(/\s+/);return[k,Number(v)];}));
const groupSpecs=[['reader',config.readerCgroup,config.readerCpu,config.readerMemory],['minio',config.minioCgroup,config.minioCpu??400,config.minioMemory??4294967296]];
function resources(includeMinio=true){
 const groups={};for(const[name,dir,cpu,memory]of groupSpecs){if(name==='minio'&&!includeMinio)continue;assert.ok(path.isAbsolute(dir));const read=n=>readFileSync(path.join(dir,n),'utf8').trim();
  assert.equal(read('cpu.max'),`${cpu*1000} 100000`);assert.equal(Number(read('memory.max')),memory);assert.equal(Number(read('memory.swap.max')),0);
  const events=parseStats(read('memory.events'));if(!initialMemoryEvents.has(name))initialMemoryEvents.set(name,events);const old=initialMemoryEvents.get(name);
  if((events.oom??0)>(old.oom??0)||(events.oom_kill??0)>(old.oom_kill??0))stop('capacity','CGROUP_OOM:'+name);
  let io;try{io={available:true,value:read('io.stat'),reason:null};}catch(e){if(e.code!=='ENOENT')throw e;io={available:false,value:null,reason:'ENOENT'};}
  groups[name]={cpu:parseStats(read('cpu.stat')),memoryCurrent:Number(read('memory.current')),memoryPeak:Number(read('memory.peak')),events,io,pids:read('cgroup.procs').split('\n').filter(Boolean).map(Number)};
 }
 if(config.diskGuardFile&&existsSync(config.diskGuardFile))stop('instrument','PARENT_DISK_GUARD');
 log('resources.ndjson',{monotonicAt:clock(),groups,generator:{pid:process.pid,cpu:process.cpuUsage(),rss:process.memoryUsage().rss,eventLoopP99Ms:eventLoop.percentile(99)/1e6,eventLoopMaxMs:eventLoop.max/1e6},hostLoad:readFileSync('/proc/loadavg','utf8').trim()});eventLoop.reset();
}
async function status(){
 if(statusBusy||stopped)return;statusBusy=true;
 try{const response=await fetch(base+'/status',{signal:AbortSignal.timeout(4000),redirect:'error'});if(!response.ok)throw Error('STATUS_HTTP_'+response.status);const json=await response.json();
  assert.equal(json.snapshotId,'v1');if(json.fatal)throw Error('READER_FATAL:'+JSON.stringify(json.fatal));
  const members=readFileSync(path.join(config.readerCgroup,'cgroup.procs'),'utf8').trim().split('\n').filter(Boolean).map(Number),workers=json.workers;
  assert.ok(Number.isInteger(json.pid)&&Array.isArray(workers));assert.equal(new Set(workers).size,workers.length);assert.ok([json.pid,...workers].every(p=>members.includes(p)));
  assert.equal(workers.length,harness.workerRoles.reduce((n,r)=>n+r.count,0));
  const details=json.workerDetails??workers.map(pid=>({pid,role:'general'}));assert.equal(details.length,workers.length);assert.equal(new Set(details.map(d=>d.pid)).size,workers.length);
  const inspected=details.map(d=>{assert.ok(workers.includes(d.pid));const expected=harness.workerRoles.find(r=>r.role===d.role);assert.ok(expected);const cmd=readFileSync(`/proc/${d.pid}/cmdline`,'utf8').replaceAll('\0',' ');assert.ok(cmd.includes(expected.commandIncludes));return {...d,cmdline:cmd};});
  for(const r of harness.workerRoles)assert.equal(inspected.filter(d=>d.role===r.role).length,r.count);
  const ids=[json.pid,...workers].sort((a,b)=>a-b);if(firstStatus)assert.deepEqual(ids,firstStatus.pids,'RUNTIME_RESTART_DURING_STAGE');
  lastStatus={pids:ids,roles:inspected};firstStatus??=lastStatus;
  log('status.ndjson',{monotonicAt:clock(),...json,verifiedWorkerDetails:inspected});
 }catch(e){stop('service-or-instrument','STATUS:'+e.message);}finally{statusBusy=false;}
}
const identity={engine:harness.engine,configSha256:sha(configBytes),oracleSha256:sha(oracleBytes),baselineGeneration:harness.baselineGeneration,bootId:readFileSync('/proc/sys/kernel/random/boot_id','utf8').trim()};
let schedule=[],start=null;
const taskQuery=t=>oracle.cases[(t.sequence+Number(options.rep)*7)%oracle.cases.length];
async function http(url,task,signal,type,identityName='all',media=null){
 const began=clock(),response=await fetch(url,{signal,redirect:'error',headers:{'x-cap-identity':identityName,'x-cap-lane':task.lane}});
 const retained=type!=='media'||response.status!==200,maxBytes=response.status===200?(type==='media'?media.bytes:type==='html'?128*1024:1024*1024):1024*1024;
 const bytes=await consumeBody(response,{signal,maxBytes,retain:retained});
 const step={type,url,status:response.status,bytes:bytes.bytes,sentAt:began,completedAt:clock(),sha256:bytes.sha256};task.steps.push(step);task.bytes+=bytes.bytes;
 if(response.status!==200){let parsed;try{parsed=JSON.parse(bytes.body);}catch{}const code=response.headers.get('x-cap-error')??parsed?.error?.code??'HTTP_'+response.status;step.errorCode=code;
  if(['SEARCH_BUSY','CONTENT_BUSY','QUEUE_TIMEOUT'].includes(code)||response.status===429){const e=Error(code);e.outcome='rejected';throw e;}
  if(['QUERY_TIMEOUT','WORKER_EXIT','WORKER_UNAVAILABLE','POOL_START_TIMEOUT'].includes(code)){const e=Error(code);e.outcome='capacity-stop';throw e;}
  if(/HASH|INTEGRITY|IDENTITY|VERSION/.test(code)){const e=Error(code);e.outcome='quality-failure';throw e;}
  const e=Error(code);e.outcome='service-failure';throw e;
 }
 if(type==='html'){oracle.verifyHtml(bytes.body.toString('utf8'),task.lane==='reading'?'p000001':'p000002');}
 else if(type==='search'){const json=JSON.parse(bytes.body);oracle.verifySearch(json,task.query);step.searchResult=json;}
 else {assert.equal(bytes.bytes,media.bytes);assert.equal(bytes.sha256,media.sha256);}
 if(signal.aborted)throw signal.reason;
}
async function perform(task){
 task.sentAt=clock();task.steps=[];task.bytes=0;const outer=new AbortController();activeControllers.add(outer);
 try{await withDeadline(task,async({signal})=>{const shared=AbortSignal.any([signal,outer.signal]);
   if(task.lane==='reading')await http(web+'/docs/p000001?version=v1',task,shared,'html');
   else if(task.lane==='media'){const m=oracle.mediaWork[task.sequence%8],params=new URLSearchParams({pageId:m.pageId,mediaId:m.mediaId,version:'v1'});task.mediaId=m.mediaId;await http(base+'/media?'+params,task,shared,'media','all',m);}
   else{const q=task.query;if(task.lane==='web-search')await http(web+'/docs/p000002?version=v1',task,shared,'html',q.identity);
    if(shared.aborted||clock()>=task.deadlineAt)throw Error('TASK_DEADLINE');const params=new URLSearchParams({q:q.q});if(q.spaceId)params.set('spaceId',q.spaceId);for(const tag of q.tags)params.append('tagId',tag);await http(base+'/search?'+params,task,shared,'search',q.identity);
   }
  });task.outcome='ok';
 }catch(e){task.error=e.message;
  if(e.message==='TASK_DEADLINE'||e.name==='TimeoutError'||(!stopped&&e.name==='AbortError'))task.outcome='timeout';
  else if(stopped&&outer.signal.aborted)task.outcome='canceled-inflight';
  else if(e.outcome)task.outcome=e.outcome;
  else if(e.message==='fetch failed')task.outcome='service-failure';
  else task.outcome='quality-failure';
  if(['quality-failure','capacity-stop','service-failure'].includes(task.outcome))stop(task.outcome,task.error);
 }finally{activeControllers.delete(outer);task.completedAt=clock();task.queueLagMs=task.sentAt-task.scheduledAt;terminal.push(task);log('raw.ndjson',task);}
}
let sample=0;
try{
 assert.equal(config.readerCpu,400);assert.equal(config.readerMemory,8589934592);const parentCg=readFileSync('/proc/self/cgroup','utf8');assert.ok(!parentCg.includes(config.readerCgroup.replace('/sys/fs/cgroup','')));
 resources();await status();if(stopped)throw Error(stopped.reason);
 if(options.stage!=='baseline'){
  if(!options['baseline-result'])throw Error('BASELINE_REQUIRED');baseline=JSON.parse(await readFile(options['baseline-result'],'utf8'));
  assert.equal(baseline.passed,true);assert.equal(baseline.stage,'baseline');assert.deepEqual(baseline.identity,identity);assert.deepEqual(baseline.runtimePids,firstStatus.pids);assert.ok(baseline.measure.reading.latency.p95<=500);
 }
 start=clock()+1000;schedule=arrivals(options.stage,start);for(const t of schedule){t.scheduledEpochMs=epoch+(t.scheduledAt-origin);t.query=['web-search','consumer'].includes(t.lane)?taskQuery(t):null;t.queryId=t.query?.id??null;}
 await writeFile(path.join(out,'schedule.json'),JSON.stringify({identity,rep:Number(options.rep),stage:options.stage,start,warmSeconds:60,measureSeconds:300,counts:oracle.counts,media:oracle.mediaWork,queryMix:oracle.cases,schedule},null,2));
 resourceTimer=setInterval(()=>{try{resources(++sample%4===0);}catch(e){stop('instrument','RESOURCE_MONITOR:'+e.message);}},1000);
 statusTimer=setInterval(()=>{if(!statusBusy)statusPending=status();},5000);
 for(const t of schedule){if(!stopped&&clock()<t.scheduledAt)await sleep(t.scheduledAt-clock());const decision=admission(t,clock(),{inflight:pending.size,laneInflight:lanePending.get(t.lane)??0,stopped:!!stopped});
  if(decision!=='send'){const row={...t,sentAt:null,completedAt:clock(),outcome:decision,steps:[],bytes:0};terminal.push(row);log('raw.ndjson',row);if(decision==='generator-cap')stop('instrument','GENERATOR_CAP');continue;}
  lanePending.set(t.lane,(lanePending.get(t.lane)??0)+1);const p=perform({...t}).catch(e=>stop('instrument','TASK_RECORD:'+e.message)).finally(()=>{pending.delete(p);lanePending.set(t.lane,lanePending.get(t.lane)-1);});pending.add(p);
 }
 if(!stopped)await sleep(start+360000-clock());
 const drainStarted=clock();await Promise.race([Promise.allSettled([...pending]),sleep(8000)]);if(pending.size){stop('instrument','DRAIN_EXCEEDED');await Promise.allSettled([...pending]);}log('control.ndjson',{event:'drain',elapsedMs:clock()-drainStarted});
}catch(e){stop('instrument',e.message);}
finally{clearInterval(resourceTimer);clearInterval(statusTimer);if(statusPending)await statusPending;await Promise.allSettled([...pending]);eventLoop.disable();}
const recorded=new Set(terminal.map(t=>`${t.lane}:${t.sequence}`));
for(const t of schedule)if(!recorded.has(`${t.lane}:${t.sequence}`)){const row={...t,sentAt:null,completedAt:clock(),outcome:'canceled-after-stop',steps:[],bytes:0};terminal.push(row);log('raw.ndjson',row);}
const measure={},warm={},perQuery={};
for(const[lane,rate]of Object.entries(rates[options.stage])){measure[lane]=summarize(terminal.filter(r=>r.window==='measure'&&r.lane===lane),300*rate);warm[lane]=summarize(terminal.filter(r=>r.window==='warm'&&r.lane===lane),60*rate);}
for(const lane of ['web-search','consumer'])if(rates[options.stage][lane])for(const q of oracle.cases){const expected=schedule.filter(r=>r.window==='measure'&&r.lane===lane&&r.queryId===q.id).length;perQuery[lane+':'+q.id]=summarize(terminal.filter(r=>r.window==='measure'&&r.lane===lane&&r.queryId===q.id),expected);}
const readingLimit=options.stage==='baseline'?500:Math.max(2*(baseline?.measure?.reading?.latency?.p95??NaN),500);
const instrumentInvalid=Object.values(measure).some(x=>(x.missedFraction??1)>.01)||stopped?.category==='instrument';
const thresholds=Object.entries(measure).map(([lane,s])=>({lane,latencyLimitMs:lane==='reading'?readingLimit:2000,pass:s.terminal===s.offered&&s.failureFraction<=.01&&s.latency.p95!==null&&s.latency.p95<=(lane==='reading'?readingLimit:2000)}));
const result={passed:!stopped&&!instrumentInvalid&&thresholds.every(x=>x.pass),stage:options.stage,rep:Number(options.rep),identity,runtimePids:firstStatus?.pids??null,measure,warm,perQuery,thresholds,instrumentInvalid,stopped,
 scope:'G3a preloaded V1 only; no update/recovery/browser-assets/user acceptance. Serial user journeys are scheduled concurrently; all latency from planned arrival through validation.',
 generator:process.resourceUsage(),sourceCount:oracle.count,queryMixSize:oracle.cases.length,baselineFile:options['baseline-result']??null};
await writeFile(path.join(out,'result.json'),JSON.stringify(result,null,2));console.log(JSON.stringify({passed:result.passed,stage:result.stage,rep:result.rep,instrumentInvalid,stopped,thresholds}));if(!result.passed)process.exitCode=1;
