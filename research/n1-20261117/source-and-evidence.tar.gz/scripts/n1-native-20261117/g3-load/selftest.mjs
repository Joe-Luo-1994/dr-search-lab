import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {arrivals,admission,withDeadline,summarize} from './schedule.mjs';
import {consumeBody} from './transport.mjs';
const checks=[];
async function check(name,fn){await fn();checks.push(name);}
await check('planned denominators and warm isolation',()=>{const s=arrivals('M',100);assert.equal(s.filter(x=>x.window==='measure').length,2700);assert.equal(s.filter(x=>x.window==='warm').length,540);assert.equal(s.filter(x=>x.window==='measure'&&x.lane==='web-search').length,1200);});
await check('missed slots never catch up',()=>{const t={scheduledAt:0,periodMs:250,deadlineAt:4000};assert.equal(admission(t,250),'generator-missed');assert.equal(admission({...t,scheduledAt:250},300),'send');assert.equal(admission(t,4000),'generator-missed');});
await check('caps and canceled work distinct',()=>{const t={scheduledAt:0,periodMs:1000,deadlineAt:4000};assert.equal(admission(t,0,{inflight:128}),'generator-cap');assert.equal(admission(t,0,{laneInflight:64}),'generator-cap');assert.equal(admission(t,0,{stopped:true}),'canceled-after-stop');});
await check('planned denominator retains rejection and omission',()=>{const s=summarize([{outcome:'ok',sentAt:10,scheduledAt:0,completedAt:40},{outcome:'rejected',sentAt:20},{outcome:'generator-missed',sentAt:null}],4);assert.equal(s.failureFraction,.75);assert.equal(s.missedFraction,.25);assert.equal(s.latency.p95,40);assert.equal(s.terminal,3);});
const wait=(ms,signal)=>new Promise((resolve,reject)=>{const timer=setTimeout(()=>{signal.removeEventListener('abort',abort);resolve();},ms);function abort(){clearTimeout(timer);reject(signal.reason);}signal.addEventListener('abort',abort,{once:true});if(signal.aborted)abort();});
await check('two journey phases share one deadline',async()=>{await assert.rejects(withDeadline({deadlineAt:performance.now()+60},async({signal})=>{await wait(40,signal);await wait(40,signal);}),/TASK_DEADLINE/);});
await check('validation after deadline is failure',async()=>{let now=0;await assert.rejects(withDeadline({deadlineAt:10},async()=>{now=11;},()=>now),/TASK_DEADLINE/);});
await check('full body checksum and byte bound',async()=>{const b=Buffer.from('abcdef');const r=await consumeBody(new Response(b),{signal:new AbortController().signal,maxBytes:6});assert.equal(r.bytes,6);assert.equal(r.sha256,createHash('sha256').update(b).digest('hex'));await assert.rejects(consumeBody(new Response(b),{signal:new AbortController().signal,maxBytes:5}),/RESPONSE_SIZE_LIMIT/);});
await check('partial stalled body abort cannot succeed',async()=>{let canceled=false;const stream=new ReadableStream({start(c){c.enqueue(new Uint8Array([1]));},cancel(){canceled=true;}});await assert.rejects(withDeadline({deadlineAt:performance.now()+30},({signal})=>consumeBody(new Response(stream),{signal,maxBytes:10})),/TASK_DEADLINE/);assert.equal(canceled,true);});
const report={passed:true,checks,node:process.version,platform:process.platform,scope:'instrumentation only; no service or load executed'};
if(process.argv[2])await writeFile(process.argv[2],JSON.stringify(report,null,2),{flag:'wx'});console.log(JSON.stringify(report));
