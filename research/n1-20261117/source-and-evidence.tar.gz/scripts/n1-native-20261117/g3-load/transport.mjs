import {createHash} from 'node:crypto';
export async function consumeBody(response,{signal,maxBytes,retain=true}){
 const reader=response.body?.getReader();if(!reader)throw Error('MISSING_RESPONSE_BODY');
 const chunks=[],hash=createHash('sha256');let bytes=0;
 const abort=()=>{reader.cancel(signal.reason).catch(()=>{});};signal.addEventListener('abort',abort,{once:true});
 try{while(true){if(signal.aborted)throw signal.reason;const part=await reader.read();if(signal.aborted)throw signal.reason;if(part.done)break;
  bytes+=part.value.length;if(bytes>maxBytes){await reader.cancel();throw Error('RESPONSE_SIZE_LIMIT');}hash.update(part.value);if(retain)chunks.push(Buffer.from(part.value));}
  return {bytes,sha256:hash.digest('hex'),body:retain?Buffer.concat(chunks):null};
 }finally{signal.removeEventListener('abort',abort);reader.releaseLock();}
}
