import assert from 'node:assert/strict';
import {probes,matches} from '../sqlite/probe-cases.mjs';
import {source} from '../../c-million-20261116/source.mjs';
export function prepareOracle(legacy,baseUrl){
 const count=legacy.sourceCount,version='v1';assert.ok(Number.isInteger(count)&&count>=123);const cases=probes(count,version),counts=Object.fromEntries(cases.map(q=>[q.id,0]));
 for(let i=1;i<=count;i++)for(const q of cases)if(matches(q,i,count,version))counts[q.id]++;
 const media=legacy.versions.v1.media;assert.equal(media.length,8);assert.equal(new Set(media.map(m=>m.mediaId)).size,8);
 const mediaWork=media.map(m=>{const p=legacy.versions.v1.pages.find(p=>p.mediaId===m.mediaId);assert.ok(p);assert.ok(m.bytes>0&&/^[a-f0-9]{64}$/.test(m.sha256));return {...m,pageId:p.pageId};});
 return {count,cases,counts,mediaWork,
  verifySearch(json,q){assert.equal(json.snapshotId,version);assert.ok(Object.hasOwn(json,'dataAsOf'));assert.equal(json.dataAsOf,null);assert.equal(json.total,counts[q.id]);assert.equal(json.hits.length,Math.min(10,counts[q.id]));assert.equal(new Set(json.hits.map(h=>h.pageId)).size,json.hits.length);
   for(const h of json.hits){const i=Number(h.pageId?.slice(1));assert.ok(Number.isSafeInteger(i)&&i>=1&&i<=count);assert.ok(matches(q,i,count,version));const p=source(i,version,count);assert.equal(h.pageId,p.pageId);assert.equal(h.spaceId,p.spaceId);assert.equal(h.title,p.title);assert.equal(h.snippet,Array.from(p.content).slice(0,160).join(''));assert.deepEqual([...(h.tagIds??[])].sort(),[...p.tags].sort());
    const url=new URL(h.url,baseUrl),base=new URL(baseUrl);assert.equal(url.origin,base.origin);assert.equal(url.username,'');assert.equal(url.password,'');assert.equal(url.hash,'');assert.equal(url.pathname,base.pathname+'/page');assert.deepEqual([...url.searchParams.keys()].sort(),['pageId','version']);assert.equal(url.searchParams.get('pageId'),h.pageId);assert.equal(url.searchParams.get('version'),version);
   }
  },
  verifyHtml(html,pageId){const p=source(Number(pageId.slice(1)),version,count),main=html.match(/<main\b([^>]*)>/i)?.[1];assert.ok(main);
   const attr=name=>main.match(new RegExp('\\b'+name+'=["\u0027]([^"\u0027]*)["\u0027]','i'))?.[1];assert.equal(attr('data-pageid'),pageId);assert.equal(attr('data-version'),version);
   const decode=s=>s.replace(/<!--[^]*?-->/g,'').replace(/&#(x[0-9a-f]+|\d+);/gi,(_,n)=>String.fromCodePoint(n[0].toLowerCase()==='x'?parseInt(n.slice(1),16):Number(n))).replace(/&(quot|apos|lt|gt|amp);/g,(_,n)=>({quot:'"',apos:"'",lt:'<',gt:'>',amp:'&'}[n]));
   assert.equal(decode(html.match(/<h1\b[^>]*>([^]*?)<\/h1>/i)?.[1]??''),p.title);assert.equal(decode(html.match(/<pre\b[^>]*>([^]*?)<\/pre>/i)?.[1]??''),p.content);
  }};
}
