#!/bin/bash
set -eu
task_root=/PUBLIC/LINUX_HOME/dr-search-lab-e1-20261115/repo/.lab/n1-native-20261117
mkdir -p "$task_root/toolchain"
curl --fail --location --proto '=https' --tlsv1.2 --max-time 90 https://static.rust-lang.org/rustup/dist/x86_64-unknown-linux-gnu/rustup-init -o "$task_root/toolchain/rustup-init"
chmod u+x "$task_root/toolchain/rustup-init"
export CARGO_HOME="$task_root/toolchain/cargo"
export RUSTUP_HOME="$task_root/toolchain/rustup"
"$task_root/toolchain/rustup-init" -y --no-modify-path --profile minimal --default-toolchain 1.88.0
