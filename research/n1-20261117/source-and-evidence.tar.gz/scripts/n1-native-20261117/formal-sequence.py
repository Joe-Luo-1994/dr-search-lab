from pathlib import Path
import subprocess,json,time
base=Path('/PUBLIC/WINDOWS_WORKSPACE')
native=Path('/PUBLIC/LINUX_HOME/dr-search-lab-e1-20261115/repo/.lab')
node='/PUBLIC/LINUX_HOME/.nvm/versions/node/v22.18.0/bin/node'
out=base/'evidence/n1-native-20261117';sequence=[(1,'sqlite'),(1,'tantivy'),(2,'tantivy'),(2,'sqlite'),(3,'sqlite'),(3,'tantivy')];rows=[]
for block,engine in sequence:
 label=f'formal-{engine}-b{block}'
 index=native/'c-million-20261116/fixture-1000000/v1/search.sqlite' if engine=='sqlite' else native/'n1-native-20261117/million-index'
 args=['python3',str(base/'scripts/n1-native-20261117/run-stage.py'),label,'1200','parent',node,str(base/'scripts/n1-native-20261117/formal/run.mjs'),'--engine',engine,'--block',str(block),'--index',str(index),'--out',str(out/(label+'-results'))]
 if engine=='tantivy':args+=['--binary',str(native/'n1-native-20261117/tantivy-build-attempt2/target/release/n1-tantivy-reader')]
 began=time.time();print(json.dumps({'starting':label}),flush=True)
 r=subprocess.run(args)
 rows.append({'label':label,'code':r.returncode,'seconds':time.time()-began})
 (out/'formal-sequence.json').write_text(json.dumps({'scope':'G2 E-only diagnostic sequential blocks','sequence':rows,'complete':len(rows)==6 and r.returncode==0},indent=2))
 if r.returncode:raise SystemExit(r.returncode)
 print(json.dumps({'completed':label}),flush=True)
