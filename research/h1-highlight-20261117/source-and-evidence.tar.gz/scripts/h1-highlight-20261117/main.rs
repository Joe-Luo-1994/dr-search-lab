use std::{fs,time::Instant,io::{self,Write}};
use serde_json::{Value,json};
use tantivy::{Index,TantivyDocument,Term};
use tantivy::schema::{Schema,TEXT,STRING,IndexRecordOption};
use tantivy::tokenizer::{PreTokenizedString,Token};
use tantivy::query::{Query,TermQuery,BooleanQuery,Occur};
use tantivy::collector::Count;
use tantivy::snippet::SnippetGenerator;
fn emit(v:Value){println!("{}",v);io::stdout().flush().unwrap();}
fn tok(v:&Value)->PreTokenizedString{let mut text=String::new();let mut out=vec![];for (position,t) in v.as_array().unwrap().iter().enumerate(){if !text.is_empty(){text.push(' ')}let start=text.len();let term=t.as_str().unwrap();text.push_str(term);out.push(Token{offset_from:start,offset_to:text.len(),position,text:term.into(),position_length:1});}PreTokenizedString{text,tokens:out}}
fn tq(f:tantivy::schema::Field,t:&str)->Box<dyn Query>{Box::new(TermQuery::new(Term::from_field_text(f,t),IndexRecordOption::WithFreqs))}
fn main()->Result<(),Box<dyn std::error::Error>>{
 let a:Vec<String>=std::env::args().collect();let fixture:Value=serde_json::from_slice(&fs::read(&a[1])?)?;
 let mut sb=Schema::builder();let title=sb.add_text_field("title",TEXT);let body=sb.add_text_field("body",TEXT);let id=sb.add_text_field("id",STRING);
 let index=Index::create_in_ram(sb.build());let mut w=index.writer_with_num_threads(1,20_000_000)?;
 for c in fixture["cases"].as_array().unwrap(){let mut d=TantivyDocument::default();d.add_pre_tokenized_text(title,tok(&c["titleTokens"]));d.add_pre_tokenized_text(body,tok(&c["bodyTokens"]));d.add_text(id,c["id"].as_str().unwrap());w.add_document(d)?;}w.commit()?;w.wait_merging_threads()?;
 let reader=index.reader()?;let searcher=reader.searcher();
 for c in fixture["cases"].as_array().unwrap(){let mut clauses=vec![];for t in c["queryTokens"].as_array().unwrap(){clauses.push((Occur::Must,Box::new(BooleanQuery::new(vec![(Occur::Should,tq(title,t.as_str().unwrap())),(Occur::Should,tq(body,t.as_str().unwrap()))])) as Box<dyn Query>));}clauses.push((Occur::Must,tq(id,c["id"].as_str().unwrap())));let q=BooleanQuery::new(clauses);let raw_hit=searcher.search(&q,&Count)?>0;let allowed=!c["denied"].as_bool().unwrap();let mut fields=json!({});
  if raw_hit && allowed {for (name,f) in [("title",title),("body",body)] {let text=c[name].as_str().unwrap();let mut gen=SnippetGenerator::create(&searcher,&q,f)?;gen.set_max_num_chars(160);let sn=gen.snippet(text);let ranges:Vec<_>=sn.highlighted().iter().map(|r|json!({"start":r.start,"end":r.end,"text":&sn.fragment()[r.clone()]})).collect();fields[name]=json!({"fragment":sn.fragment(),"html":sn.to_html(),"ranges":ranges,"baseline":text.chars().take(160).collect::<String>()});}}
  emit(json!({"kind":"case","id":c["id"],"rawHit":raw_hit,"hit":raw_hit&&allowed,"fields":fields}));
 }
 if a.get(2).map(String::as_str)!=Some("bench"){return Ok(())}
 // Diagnostic ONLY: already selected/authorized resident English documents; not search or HTTP capacity.
 let q=TermQuery::new(Term::from_field_text(body,"backup"),IndexRecordOption::WithFreqs);
 for block in 0..3 {for size in [1024usize,10240,102400,1048576]{let text=format!("{} backup recovery ending.","ordinary context words. ".repeat(size/24));let texts=vec![text;10];
  for iteration in 0..55 {for mode in if (iteration+block)%2==0 {["baseline","highlight"]}else{["highlight","baseline"]}{let start=Instant::now();let mut count=0;
   if mode=="baseline" {for t in &texts{let snippet:String=t.chars().take(160).collect();count+=std::hint::black_box(snippet).len();}}
   else {let mut gen=SnippetGenerator::create(&searcher,&q,body)?;gen.set_max_num_chars(160);for t in &texts {let sn=gen.snippet(t);assert!(sn.highlighted().iter().any(|r|&sn.fragment()[r.clone()]=="backup"));count+=std::hint::black_box(sn.to_html()).len();}}
   emit(json!({"kind":"bench","block":block,"iteration":iteration,"warm":iteration<5,"mode":mode,"docBytes":texts[0].len(),"batch":10,"ns":start.elapsed().as_nanos() as u64,"outputBytes":count}));
  }}
 }}Ok(())
}
