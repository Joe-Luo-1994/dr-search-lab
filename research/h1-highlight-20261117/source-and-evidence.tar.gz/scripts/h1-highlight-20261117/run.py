from pathlib import Path
import subprocess,os,shutil,json,time,hashlib
BASE=Path('/PUBLIC/WORKSPACE')
SRC=BASE/'scripts/h1-highlight-20261117'
OUT=BASE/'evidence/h1-highlight-20261117'; OUT.mkdir(exist_ok=False)
OLD=Path('/PUBLIC/HOME/dr-search-lab-e1-20261115/repo/.lab/n1-native-20261117')
WORK=Path('/PUBLIC/HOME/dr-h1-highlight-20261117');WORK.mkdir(exist_ok=False)
TC=OLD/'toolchain'; NODE='/PUBLIC/HOME/.nvm/versions/node/v22.18.0/bin/node'
PS='/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
def hostfree():
 p=subprocess.run([PS,'-NoProfile','-Command','[long](Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory * 1024'],capture_output=True,text=True,timeout=10,check=True)
 return int(p.stdout.strip())
def receipt(name,x): (OUT/name).write_text(json.dumps(x,indent=2),encoding='utf8')
def controlled(label,args,mem,cpu,deadline,env=None):
 unit='dr-h1-'+label+'-20261117';start=time.monotonic();stop=None;samples=[]
 cmd=['systemd-run','--user','--wait','--pipe','--unit='+unit,'-p','CPUQuota='+str(cpu*100)+'%','-p','MemoryMax='+mem,'-p','MemorySwapMax=0','-p','TasksMax=128','-p','RuntimeMaxSec='+str(deadline),'--working-directory='+str(WORK)]
 if env:cmd+=['--setenv='+k+'='+v for k,v in env.items()]
 with (OUT/(label+'.stdout.ndjson')).open('w') as stdout,(OUT/(label+'.stderr.log')).open('w') as stderr:
  p=subprocess.Popen(cmd+args,stdout=stdout,stderr=stderr)
  last_host=0;available=None
  try:
   while p.poll() is None:
    now=time.monotonic()
    if now-last_host>5:available=hostfree();last_host=now
    cg=subprocess.run(['systemctl','--user','show',unit,'--property=ControlGroup','--value'],capture_output=True,text=True).stdout.strip()
    sample={'seconds':now-start,'windowsAvailableBytes':available}
    if cg:
     root=Path('/sys/fs/cgroup'+cg)
     for key in ['memory.current','memory.peak','memory.events','memory.swap.current','cpu.stat','memory.stat']:
      try:sample[key]=(root/key).read_text()
      except FileNotFoundError:pass
    samples.append(sample)
    if available is not None and available<6*1024**3:stop='HOST_AVAILABLE';break
    if now-start>deadline+15:stop='DEADLINE';break
    if shutil.disk_usage(WORK).free<10*1024**3:stop='DISK';break
    if 'oom_kill 0' not in sample.get('memory.events','oom_kill 0'):stop='OOM';break
    time.sleep(.5)
  finally:
   if p.poll() is None:subprocess.run(['systemctl','--user','stop',unit],capture_output=True)
   p.wait(timeout=20)
 elapsed=time.monotonic()-start
 state=subprocess.run(['systemctl','--user','show',unit,'--property=ActiveState,MainPID,SubState'],capture_output=True,text=True).stdout
 result={'returncode':p.returncode,'stop':stop,'elapsedSeconds':elapsed,'memoryMax':mem,'cpuQuotaCores':cpu,'swapMax':0,'unitState':state}
 receipt(label+'-result.json',result);receipt(label+'-resources.json',samples)
 if p.returncode or stop:raise RuntimeError(label+' stopped '+str(result))
 return result
try:
 available=hostfree();receipt('preflight.json',{'windowsAvailableBytes':available,'diskFreeBytes':shutil.disk_usage(WORK).free,'node':subprocess.check_output([NODE,'--version'],text=True).strip(),'sourceSha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in SRC.iterdir() if p.is_file()}})
 if available<8*1024**3:raise RuntimeError('HOST_PREFLIGHT')
 (WORK/'src').mkdir();shutil.copy2(SRC/'main.rs',WORK/'src/main.rs')
 for name in ['Cargo.toml','Cargo.lock']:shutil.copy2(OLD/'tantivy-build-attempt2'/name,WORK/name);shutil.copy2(WORK/name,OUT/name)
 # Copy dependency artifacts instead of mutating the frozen project's target.
 shutil.copytree(OLD/'tantivy-build-attempt2/target',WORK/'target')
 subprocess.run([NODE,str(SRC/'fixture.mjs'),str(OUT/'fixture.json')],check=True)
 env={'CARGO_HOME':str(TC/'cargo'),'RUSTUP_HOME':str(TC/'rustup'),'RUSTUP_TOOLCHAIN':'1.90.0','CARGO_BUILD_JOBS':'2','PATH':str(TC/'cargo/bin')+':'+os.environ['PATH']}
 controlled('build',[str(TC/'cargo/bin/cargo'),'build','--release','--locked','--offline'],'2G',2,600,env)
 binary=WORK/'target/release/n1-tantivy-reader'
 receipt('binary.json',{'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'rust':'1.90.0','tantivy':'0.27.0','scope':'new isolated H1 binary, not N1 original'})
 controlled('cases',[str(binary),str(OUT/'fixture.json')],'512M',1,60)
 # G1 analysis decides candidate viability; diagnostic English screen is explicitly allowed even on Chinese mismatch.
 controlled('diagnostic',[str(binary),str(OUT/'fixture.json'),'bench'],'512M',1,180)
 receipt('execution.json',{'completed':True,'candidateQualified':False,'qualification':'see analysis; diagnostic execution is not pass of G1'})
except Exception as e:
 receipt('execution.json',{'completed':False,'error':str(e)});raise
