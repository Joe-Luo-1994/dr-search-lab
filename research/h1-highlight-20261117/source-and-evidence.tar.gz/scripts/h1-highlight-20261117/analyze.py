from pathlib import Path
import json,math,html,collections,hashlib
from html.parser import HTMLParser
ROOT=Path(__file__).resolve().parents[2]; E=ROOT/'evidence/h1-highlight-20261117'
load=lambda p:json.loads((E/p).read_text(encoding='utf8'))
fixture=load('fixture.json'); raw=[json.loads(x) for x in (E/'cases.stdout.ndjson').read_text(encoding='utf8').splitlines()]
assert len(raw)==len(fixture['cases'])==20
assert len({x['id'] for x in raw})==20
class SafeHTML(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.data=[];self.tags=[]
 def handle_starttag(self,tag,attrs):assert tag=='b' and not attrs;self.tags.append(tag)
 def handle_endtag(self,tag):assert self.tags.pop()==tag
 def handle_data(self,data):self.data.append(data)
out=[];doc=['# H1 案例對照','', '原文與查詢為合成資料。以下包含失敗，未修正期待值以配合結果。搜尋契約是AND詞項，不宣稱片語。完整原文見 fixture.json。','']
for c,r in zip(fixture['cases'],raw):
 assert c['id']==r['id'];checks=[];fail=[]
 if r['hit']!=c['expected']['hit']:fail.append('hit mismatch')
 if not r['hit']:assert r['fields']=={}
 for field,x in r['fields'].items():
  text=c[field];frag=x['fragment'];assert frag in text
  data=frag.encode();spans=[];previous=0
  for span in x['ranges']:
   a,b=span['start'],span['end'];assert 0<=a<b<=len(data) and a>=previous;previous=b
   assert data[a:b].decode('utf8')==span['text'];spans.append(span['text'].lower())
  parser=SafeHTML();parser.feed(x['html']);assert not parser.tags and ''.join(parser.data)==frag
  assert x['baseline']==text[:160]
  for term in c['expected'][field+'Terms']:
   if term.lower() not in spans:fail.append(field+':missing '+term)
  if not c['expected'][field+'Terms']:assert not spans
 out.append({'id':c['id'],'passed':not fail,'failures':fail,'hit':r['hit'],'safetyChecksPassed':True})
 doc+=['## '+c['id']+' — '+('PASS' if not fail else 'FAIL'),'', '查詢：`'+c['q']+'`；搜尋命中：'+str(r['hit'])+'。失敗：'+('；'.join(fail) or '無'),'', '原文（前300字；完整內容見fixture）：','```text',c['body'][:300], '```','']
 for field,x in r['fields'].items():
  doc += ['**'+field+'：現有前160字**','```text',x['baseline'],'```','**官方摘要／highlight**', '> '+(x['html'].replace('\n','<br>') or '（空）'),'']
bench=[json.loads(x) for x in (E/'diagnostic.stdout.ndjson').read_text(encoding='utf8').splitlines()]
assert [x for x in bench if x['kind']=='case']==raw
measure=[x for x in bench if x['kind']=='bench' and not x['warm']]
assert len(measure)==1200
groups=collections.defaultdict(list)
seen=set()
for r in measure:
 key=(r['block'],r['docBytes'],r['mode'],r['iteration']);assert key not in seen;seen.add(key)
 groups[key[:3]].append(r['ns']/1e6)
stats=[]
for (block,size,mode),values in sorted(groups.items()):
 assert len(values)==50;values.sort();stats.append({'block':block,'docBytes':size,'mode':mode,'batch':10,'n':50,'p50Ms':values[24],'p95Ms':values[47],'maxMs':values[-1]})
resources=load('diagnostic-resources.json')
summary={'caseCount':20,'passedCases':sum(x['passed'] for x in out),'cases':out,'candidateHighlightQualified':all(x['passed'] for x in out),'searchMembershipPassed':all(r['hit']==c['expected']['hit'] for r,c in zip(raw,fixture['cases'])),'utf8OriginalTextHtmlSafetyPassed':True,'benchMeasuredBatches':len(measure),'benchWarmBatches':len([x for x in bench if x['kind']=='bench' and x['warm']]),'bench':stats,'diagnosticBudgetMs':100,'diagnosticBudgetAllPassed':all(x['p95Ms']<=100 for x in stats if x['mode']=='highlight'),'sampledMemoryPeakBytes':max(int(x.get('memory.peak',0)) for x in resources),'windowsMinSampledAvailableBytes':min(x['windowsAvailableBytes'] for x in resources),'scope':'native resident English batch snippet cost; no HTTP/full search/storage/real auth capacity'}
(E/'analysis.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
(E/'CASES.md').write_text('\n'.join(doc),encoding='utf8')
print(json.dumps({k:v for k,v in summary.items() if k not in ['cases','bench']},ensure_ascii=False))
for size in sorted({x['docBytes'] for x in stats}):
 vals=[x['p95Ms'] for x in stats if x['docBytes']==size and x['mode']=='highlight'];base=[x['p95Ms'] for x in stats if x['docBytes']==size and x['mode']=='baseline'];print(size,'highlight p95',min(vals),max(vals),'baseline',min(base),max(base))
