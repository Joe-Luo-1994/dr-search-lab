import {writeFileSync} from 'node:fs';
const segmenter=new Intl.Segmenter('zh-Hant',{granularity:'word'});
const normalize=text=>text.replace(/\p{Script=Han}+/gu,run=>[...segmenter.segment(run)].map(x=>x.segment).join(' '));
const tokens=text=>(normalize(text).match(/[\p{L}\p{N}\p{M}]+/gu)??[]).map(t=>t.toLowerCase());
// Expectations authored before observing snippets. Terms need appear in highlighted spans, not exact chosen sentence.
const rows=[
 ['english','Guide','Daily backup protects documents.','backup',true,[],['backup']],
 ['case','Guide','BACKUP and Backup are important.','backup',true,[],['backup']],
 ['punctuation','Guide','backup, restore; verify!','backup restore',true,[],['backup','restore']],
 ['zh-word','指南','每天執行備份並驗證文件。','備份',true,[],['備份']],
 ['zh-title','備份操作指南','這份文件提供操作說明。','備份',true,['備份'],[]],
 ['zh-mixed','Guide','系統使用MinIO保存備份資料。','備份',true,[],['備份']],
 ['english-title','Backup guide','This explains operating procedures.','backup',true,['backup'],[]],
 ['middle','Guide','Introduction. '.repeat(60)+' backup protects documents. '+'Conclusion. '.repeat(60),'backup',true,[],['backup']],
 ['end','Guide','Introduction. '.repeat(100)+' Final backup instructions.','backup',true,[],['backup']],
 ['multi','Guide','backup recovery procedures are documented here.','backup recovery',true,[],['backup','recovery']],
 ['phrase-caveat','Guide','backup is separate from recovery in this paragraph.','backup recovery',true,[],['backup','recovery']],
 ['pdf-lines','Guide','The disaster\nrecovery plan explains\nbackup procedures.','backup',true,[],['backup']],
 ['pdf-hyphen','Guide','The back-\nup procedure is described.','backup',false,[],[]],
 ['html','Guide','<script>alert("x")</script> backup & restore <img src=x onerror=alert(1)>','backup',true,[],['backup']],
 ['emoji','Guide','✅ backup protects café and documents 😀.','backup',true,[],['backup']],
 ['accent','Guide','The café keeps a backup.','café',true,[],['café']],
 ['combining','Guide','The cafe\u0301 keeps a backup.','cafe\u0301',true,[],['cafe\u0301']],
 ['missing','Guide','Only recovery instructions.','backup',false,[],[]],
 ['denied','Guide','SECRET backup instructions.','backup',false,[],[],true],
 ['repeated','Guide','backup recovery daily. '.repeat(200),'backup',true,[],['backup']],
];
const cases=rows.map(([id,title,body,q,hit,titleTerms,bodyTerms,denied=false])=>({id,title,body,q,expected:{hit,titleTerms,bodyTerms},denied,titleTokens:tokens(title),bodyTokens:tokens(body),queryTokens:tokens(q)}));
writeFileSync(process.argv[2],JSON.stringify({node:process.version,icu:process.versions.icu,cases},null,2));
